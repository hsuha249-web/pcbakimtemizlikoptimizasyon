using System.Runtime.InteropServices;
using System.Text.Json;

namespace DiskGuardSpace;

/// <summary>
/// Physical-space accounting helpers. Logical file length is not equal to allocated NTFS bytes
/// for sparse/compressed files. These probes are advisory/accounting only; cleanup authorization
/// never depends on a path-based allocation measurement.
/// </summary>
internal static class NtfsAllocationProbe
{
    public static long GetAllocatedBytesOrLogical(string path, long logicalBytes, out bool measured)
    {
        measured = false;
        logicalBytes = Math.Max(0, logicalBytes);
        if (!OperatingSystem.IsWindows() || string.IsNullOrWhiteSpace(path)) return logicalBytes;
        try
        {
            uint high;
            Marshal.SetLastPInvokeError(0);
            var low = GetCompressedFileSizeW(path, out high);
            var err = Marshal.GetLastPInvokeError();
            if (low == 0xFFFFFFFF && err != 0) return logicalBytes;
            var value = ((long)high << 32) | low;
            if (value < 0) return logicalBytes;
            measured = true;
            return value;
        }
        catch
        {
            return logicalBytes;
        }
    }

    internal static long NormalizeForTests(long logicalBytes, long? measuredBytes)
    {
        var logical = Math.Max(0, logicalBytes);
        if (measuredBytes is null || measuredBytes < 0) return logical;
        return measuredBytes.Value;
    }

    [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    private static extern uint GetCompressedFileSizeW(string lpFileName, out uint lpFileSizeHigh);
}

internal static class SpacePressurePolicy
{
    public static string Classify(long freeBytes, long totalBytes)
    {
        if (totalBytes <= 0 || freeBytes < 0 || freeBytes > totalBytes) return "UNKNOWN";
        var p = freeBytes * 100.0 / totalBytes;
        if (freeBytes < 1L * 1024 * 1024 * 1024 || p < 2.0) return "EMERGENCY";
        if (freeBytes < 2L * 1024 * 1024 * 1024 || p < 5.0) return "CRITICAL";
        if (p < 10.0) return "LOW";
        if (p < 20.0) return "WATCH";
        return "HEALTHY";
    }
}

internal sealed class MaintenanceCooldownState
{
    public string SchemaVersion { get; set; } = "1.0";
    public Dictionary<string, DateTime> LastSuccessUtc { get; set; } = new(StringComparer.OrdinalIgnoreCase);
}

/// <summary>
/// Avoids repeatedly running heavy write maintenance. Corrupt/future state never authorizes a
/// heavy operation: it causes that heavy stage to be skipped while space scanning/cleanup remains available.
/// </summary>
internal static class MaintenanceCooldownJournal
{
    private static string StatePath => Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "DiskGuardSpace", "State", "maintenance-cooldowns.json");

    public static bool ShouldSkip(string key, TimeSpan cooldown, bool bypassForCriticalSpace, string spacePressure, out string detail)
    {
        detail = "no previous successful run";
        if (bypassForCriticalSpace && spacePressure is "EMERGENCY" or "CRITICAL" or "LOW")
        {
            detail = "low-space bypass: reclaim-capable maintenance may run";
            return false;
        }

        try
        {
            if (!File.Exists(StatePath)) return false;
            var state = JsonSerializer.Deserialize<MaintenanceCooldownState>(File.ReadAllText(StatePath), Json.Options);
            if (state is null || state.SchemaVersion != "1.0")
            {
                detail = "cooldown state invalid; heavy stage fail-closed skipped";
                return true;
            }
            if (!state.LastSuccessUtc.TryGetValue(key, out var last)) return false;
            var now = DateTime.UtcNow;
            if (last > now.AddMinutes(5))
            {
                detail = $"future cooldown timestamp detected ({last:o}); heavy stage fail-closed skipped";
                return true;
            }
            var age = now - last;
            if (age < TimeSpan.Zero)
            {
                detail = "negative cooldown age; heavy stage fail-closed skipped";
                return true;
            }
            if (age < cooldown)
            {
                detail = $"last success {age.TotalHours:F1}h ago; cooldown={cooldown.TotalHours:F1}h";
                return true;
            }
            detail = $"cooldown expired; last success {age.TotalHours:F1}h ago";
            return false;
        }
        catch (Exception ex)
        {
            detail = "cooldown state unreadable; heavy stage fail-closed skipped: " + ex.Message;
            return true;
        }
    }

    public static void MarkSuccess(string key)
    {
        try
        {
            MaintenanceCooldownState state;
            if (File.Exists(StatePath))
            {
                try { state = JsonSerializer.Deserialize<MaintenanceCooldownState>(File.ReadAllText(StatePath), Json.Options) ?? new(); }
                catch { state = new(); }
            }
            else state = new();
            state.SchemaVersion = "1.0";
            state.LastSuccessUtc[key] = DateTime.UtcNow;
            AtomicFile.WriteAllText(StatePath, JsonSerializer.Serialize(state, Json.Options));
        }
        catch
        {
            // Failure to persist a cooldown must never turn a successful maintenance action into
            // permission for an unsafe follow-up action. Next run will simply have no trusted cooldown.
        }
    }

    internal static bool EvaluateTimestampForTests(DateTime nowUtc, DateTime? lastSuccessUtc, TimeSpan cooldown)
    {
        if (lastSuccessUtc is null) return false;
        if (lastSuccessUtc.Value > nowUtc.AddMinutes(5)) return true;
        var age = nowUtc - lastSuccessUtc.Value;
        return age < TimeSpan.Zero || age < cooldown;
    }
}

internal sealed class MaintenanceRunState
{
    public string SchemaVersion { get; set; } = "1.0";
    public string RunId { get; set; } = "";
    public string Status { get; set; } = "IN_PROGRESS";
    public string Stage { get; set; } = "START";
    public DateTime StartedUtc { get; set; } = DateTime.UtcNow;
    public DateTime UpdatedUtc { get; set; } = DateTime.UtcNow;
}

/// <summary>
/// Crash/interruption journal for auto-care. An unexpected process termination leaves IN_PROGRESS
/// on disk. The next run then enters recovery mode: per-file safe cleanup may still proceed, but
/// heavy Windows maintenance is skipped for that one recovery run. A normally completed or cleanly
/// failed run closes the journal explicitly.
/// </summary>
internal static class MaintenanceRunJournal
{
    private static string StatePath => Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "DiskGuardSpace", "State", "last-auto-care-run.json");

    public static bool ShouldEnterRecoveryMode(out string detail)
    {
        detail = "no interrupted prior run";
        try
        {
            if (!File.Exists(StatePath)) return false;
            var state = JsonSerializer.Deserialize<MaintenanceRunState>(File.ReadAllText(StatePath), Json.Options);
            if (state is null || state.SchemaVersion != "1.0" || !Guid.TryParseExact(state.RunId, "N", out _))
            {
                detail = "run journal invalid/untrusted; heavy stages fail-closed for this recovery run";
                return true;
            }
            var now = DateTime.UtcNow;
            if (state.UpdatedUtc > now.AddMinutes(5) || state.StartedUtc > now.AddMinutes(5))
            {
                detail = "run journal contains future timestamps; heavy stages fail-closed for this recovery run";
                return true;
            }
            if (state.Status.Equals("IN_PROGRESS", StringComparison.OrdinalIgnoreCase))
            {
                detail = $"prior run {state.RunId} ended while stage={state.Stage}; heavy stages deferred for one recovery run";
                return true;
            }
            if (!state.Status.Equals("COMPLETED", StringComparison.OrdinalIgnoreCase) &&
                !state.Status.Equals("FAILED", StringComparison.OrdinalIgnoreCase))
            {
                detail = $"unknown prior run status {state.Status}; heavy stages fail-closed for this recovery run";
                return true;
            }
            return false;
        }
        catch (Exception ex)
        {
            detail = "run journal unreadable; heavy stages fail-closed for this recovery run: " + ex.Message;
            return true;
        }
    }

    public static void Begin(string runId)
    {
        Write(new MaintenanceRunState
        {
            RunId = runId,
            Status = "IN_PROGRESS",
            Stage = "START",
            StartedUtc = DateTime.UtcNow,
            UpdatedUtc = DateTime.UtcNow
        });
    }

    public static void MarkStage(string runId, string stage)
    {
        MaintenanceRunState state;
        try
        {
            state = File.Exists(StatePath)
                ? JsonSerializer.Deserialize<MaintenanceRunState>(File.ReadAllText(StatePath), Json.Options) ?? new MaintenanceRunState()
                : new MaintenanceRunState();
        }
        catch { state = new MaintenanceRunState(); }
        if (!string.Equals(state.RunId, runId, StringComparison.Ordinal))
            state.StartedUtc = DateTime.UtcNow;
        state.SchemaVersion = "1.0";
        state.RunId = runId;
        state.Status = "IN_PROGRESS";
        state.Stage = string.IsNullOrWhiteSpace(stage) ? "UNKNOWN" : stage;
        state.UpdatedUtc = DateTime.UtcNow;
        Write(state);
    }

    public static void Complete(string runId, bool success)
    {
        Write(new MaintenanceRunState
        {
            RunId = runId,
            Status = success ? "COMPLETED" : "FAILED",
            Stage = "FINALIZED",
            StartedUtc = DateTime.UtcNow,
            UpdatedUtc = DateTime.UtcNow
        });
    }

    private static void Write(MaintenanceRunState state)
        => AtomicFile.WriteAllText(StatePath, JsonSerializer.Serialize(state, Json.Options));

    internal static bool EvaluateStateForTests(string schema, string runId, string status, DateTime startedUtc, DateTime updatedUtc, DateTime nowUtc)
    {
        if (schema != "1.0" || !Guid.TryParseExact(runId, "N", out _)) return true;
        if (updatedUtc > nowUtc.AddMinutes(5) || startedUtc > nowUtc.AddMinutes(5)) return true;
        if (status.Equals("IN_PROGRESS", StringComparison.OrdinalIgnoreCase)) return true;
        return !status.Equals("COMPLETED", StringComparison.OrdinalIgnoreCase) &&
               !status.Equals("FAILED", StringComparison.OrdinalIgnoreCase);
    }
}

internal static class CleanupBlastRadiusPolicy
{
    private const long GiB = 1024L * 1024L * 1024L;
    public const int MaxFilesPerRun = 200_000;
    public const int MaxFilesPerCategory = 50_000;

    public static long GetSystemRunBudgetBytes()
    {
        try
        {
            var snap = DiskSnapshot.CaptureSystemDrive();
            return ComputeBudgetBytes(snap.TotalBytes, snap.FreeBytes);
        }
        catch
        {
            return 8L * GiB;
        }
    }

    internal static long ComputeBudgetBytes(long totalBytes, long freeBytes)
    {
        if (totalBytes <= 0 || freeBytes < 0 || freeBytes > totalBytes) return 8L * GiB;
        var pressure = SpacePressurePolicy.Classify(freeBytes, totalBytes);
        var fraction = pressure is "EMERGENCY" or "CRITICAL" ? 0.75 : pressure == "LOW" ? 0.60 : 0.40;
        var computed = (long)Math.Floor(totalBytes * fraction);
        return Math.Clamp(computed, 8L * GiB, 128L * GiB);
    }

    internal static long ComputeCategoryBudgetBytes(long runBudgetBytes)
    {
        if (runBudgetBytes <= 0) return 2L * GiB;
        // A single cache family may consume at most half of the total automatic-cleanup budget.
        // This prevents one incorrectly classified category from dominating the blast radius.
        return Math.Clamp(runBudgetBytes / 2, 2L * GiB, 32L * GiB);
    }
}

internal static class FreeSpaceProofPolicy
{
    private const long MiB = 1024L * 1024L;

    public static string Classify(long expectedAllocatedReclaimBytes, long observedFreeGainBytes)
    {
        if (expectedAllocatedReclaimBytes < 0) return "UNTRUSTED_EXPECTATION";
        if (expectedAllocatedReclaimBytes == 0)
            return observedFreeGainBytes == 0 ? "NO_FILE_RECLAIM" : "EXTERNAL_VOLUME_ACTIVITY";
        if (observedFreeGainBytes <= 0) return "INCONSISTENT_NO_OBSERVED_GAIN";

        var tolerance = Math.Max(256L * MiB, expectedAllocatedReclaimBytes / 4);
        var absoluteDelta = observedFreeGainBytes >= expectedAllocatedReclaimBytes
            ? observedFreeGainBytes - expectedAllocatedReclaimBytes
            : expectedAllocatedReclaimBytes - observedFreeGainBytes;
        return absoluteDelta <= tolerance ? "CONSISTENT" : "CONCURRENT_VOLUME_ACTIVITY";
    }
}
