# DiskGuardSpace v0.6 Changes

## Space accuracy
- Added NTFS physical-allocation measurement for deep analysis and cleanup evidence.
- Added handle-bound allocation query before deletion.
- Duplicate opportunity scoring now has physical-allocation savings.
- Compression estimates skip already compressed/sparse/encrypted files and are capped by allocated bytes.

## Space discovery
- Added WSL/Docker virtual-disk review-only signals.
- Added Maven, Cargo, Go, Yarn and pnpm rebuildable-cache measurements.
- Added WER Temp and additional Chromium/Electron rebuildable cache roots.

## Maintenance/performance
- Added space-pressure tiers.
- Added fail-closed cooldown journal for heavy maintenance.
- Added memory-pressure gate for drive optimization.
- Added read-only active power scheme, VSS shadow-storage and defrag-analysis diagnostics.

## Negative controls
- Reject NTFS ADS and Win32 device/UNC-style paths from automatic cleanup.
- Self-protect DiskGuardSpace persistent evidence/state tree.
- Verify physical allocation evidence and duplicate physical-savings arithmetic.
- Reject future cooldown timestamps.
- Reject direct VHDX cleanup authority.
- Reject VSS mutation and defrag write modes in read-only diagnostics.

## Executable provenance / filesystem health
- Removed PATH-based `fsutil.exe` resolution from PC health diagnostics.
- Added canonical `%WINDIR%\System32` provenance gates for maintenance/read-only diagnostic executables.
- Added read-only system-volume dirty-bit reporting.
- Added negative controls for bare executable names and `System32_evil` lookalike paths.
