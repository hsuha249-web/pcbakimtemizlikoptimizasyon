# DiskGuardSpace v1.1 changelog

## Double-click runtime fix

The v1.0 packaged EXE was primarily a command-line executable. Launching it with no arguments printed help and exited, which made a valid binary look non-functional when double-clicked from Explorer.

v1.1 changes the no-argument path to a native Win32 **DiskGuardSpace Runtime Controller**. The console window is hidden for controller mode, while all existing CLI commands remain available for proof/build/startup automation.

## Native proof controller

The controller has a real Windows button: **Run Read-Only Verification**. It runs the packaged EXE again as child processes and verifies:

1. packaged EXE self-test,
2. adversarial/negative tests,
3. real-PC read-only safe scan,
4. independent scan-report verification,
5. PC-specific `auto-care` dry run,
6. independent auto-care-report verification,
7. packaged EXE SHA-256 identity,
8. adjacent release-proof identity when a final `RELEASE_PROOF.json` is present.

The controller writes `CONTROLLER_PROOF.json`. The proof directory is restricted to canonical LocalAppData tree (including its normal Temp subtree) and rejects unsafe path syntax/reparse redirection.

The controller does not call `clean-safe`, `windows-maintenance`, or `auto-care --apply`. Its verification action does not perform cleanup/write maintenance. Isolated self/negative tests may create and remove their own temporary test artifacts, and the controller writes its own evidence files.

## CSV Cleaner-style native UI verification

`VERIFY_CONTROLLER.ps1` implements a dependency-free Windows UI Automation proof similar to the supplied CSV Cleaner verifier:

- starts the packaged EXE,
- confirms the native controller window is actually visible,
- finds the real `Run Read-Only Verification` Windows button,
- invokes that button through Windows UI Automation,
- waits for `CONTROLLER_PROOF.json`,
- verifies its schema, version, read-only maintenance claim and EXE SHA-256,
- verifies the native window reaches `STATUS: PASS`,
- writes `CONTROLLER_AUTOMATION_PROOF.json`.

No `pywinauto` or Python GUI dependency is required on the target PC.

## Release pipeline hardening

The controlled release pipeline is now 11 gates. A binary is not promoted unless the native controller UI passes on the staging packaged EXE. After atomic promotion and release-proof creation, the final EXE is launched again and the controller proof is rerun with adjacent `RELEASE_PROOF.json` identity required.

A controller failure therefore withdraws the newly promoted binary and triggers the existing transactional release rollback path.

## New negative tests

- controller proof output outside canonical LocalAppData is rejected,
- controller proof path with ADS syntax is rejected,
- unknown controller CLI switches are rejected.
