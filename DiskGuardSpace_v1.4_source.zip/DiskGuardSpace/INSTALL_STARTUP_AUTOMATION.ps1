param(
    [string]$ExePath = "",
    [string]$ProofPath = "",
    [string]$SourceManifestPath = "",
    [string]$VerifyReleasePath = ""
)
$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
if (-not $ExePath) { $ExePath = Join-Path $Root "dist\DiskGuardSpace.exe" }
if (-not $ProofPath) { $ProofPath = Join-Path $Root "dist\RELEASE_PROOF.json" }
if (-not $SourceManifestPath) { $SourceManifestPath = Join-Path $Root "SOURCE_MANIFEST.sha256" }
if (-not $VerifyReleasePath) { $VerifyReleasePath = Join-Path $Root "VERIFY_RELEASE.ps1" }

$TaskPath = "\"
$TaskName = "DiskGuardSpace_StartupMaintenance"
$InstallRoot = Join-Path $env:ProgramFiles "DiskGuardSpace"
$BackgroundSource = Join-Path $Root "BACKGROUND_MAINTENANCE.ps1"
$StartupVerifierSource = Join-Path $Root "VERIFY_STARTUP_AUTOMATION.ps1"
$ControllerVerifierSource = Join-Path $Root "VERIFY_CONTROLLER.ps1"
$UninstallSource = Join-Path $Root "UNINSTALL_STARTUP_AUTOMATION.ps1"
$CanonicalPowerShell = Join-Path $env:SystemRoot "System32\WindowsPowerShell\v1.0\powershell.exe"

function Test-Administrator {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    $p = New-Object Security.Principal.WindowsPrincipal($id)
    return $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}
function Get-Sha256([string]$Path) { return (Get-FileHash $Path -Algorithm SHA256).Hash.ToLowerInvariant() }
function Test-Reparse([string]$Path) {
    if (-not (Test-Path $Path)) { return $false }
    return (((Get-Item $Path -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0)
}
function Promote-File([string]$Source, [string]$Destination, [string]$StageDir) {
    if (-not (Test-Path $Source -PathType Leaf)) { throw "Required install source missing: $Source" }
    $pending = Join-Path $StageDir ([IO.Path]::GetFileName($Destination) + ".pending")
    $existed = Test-Path $Destination -PathType Leaf
    $backup = Join-Path $StageDir ([IO.Path]::GetFileName($Destination) + ".previous")
    Copy-Item $Source $pending -Force
    if ((Get-Sha256 $Source) -ne (Get-Sha256 $pending)) { throw "Staged file hash mismatch: $Source" }
    if ($existed) {
        [IO.File]::Replace($pending, $Destination, $backup, $true)
        if ((Get-Sha256 $Source) -ne (Get-Sha256 $Destination)) {
            if (Test-Path $backup) { Copy-Item $backup $Destination -Force }
            throw "Installed file hash mismatch after atomic replace: $Destination"
        }
    } else {
        Move-Item $pending $Destination -Force
    }
    return [pscustomobject]@{ Destination=$Destination; Backup=$backup; Existed=$existed }
}
function Restore-Files($Entries) {
    $items = @($Entries)
    [array]::Reverse($items)
    foreach ($entry in $items) {
        try {
            if ($entry.Existed) {
                if (Test-Path $entry.Backup -PathType Leaf) { Copy-Item $entry.Backup $entry.Destination -Force }
            } else {
                Remove-Item $entry.Destination -Force -ErrorAction SilentlyContinue
            }
        } catch { }
    }
}

if (-not (Test-Administrator)) { throw "Administrator permission is required to install the verified background startup task." }
if (-not (Test-Path $CanonicalPowerShell -PathType Leaf)) { throw "Canonical Windows PowerShell executable missing: $CanonicalPowerShell" }
foreach ($required in @($ExePath,$ProofPath,$SourceManifestPath,$VerifyReleasePath,$BackgroundSource,$StartupVerifierSource,$ControllerVerifierSource,$UninstallSource)) {
    if (-not (Test-Path $required -PathType Leaf)) { throw "Required startup-automation file missing: $required" }
}

& $VerifyReleasePath -ExePath $ExePath -ProofPath $ProofPath
if ($LASTEXITCODE -ne 0) { throw "Release verification failed; startup automation was not installed." }

$existing = Get-ScheduledTask -TaskPath $TaskPath -TaskName $TaskName -ErrorAction SilentlyContinue
if ($existing -and $existing.State -eq 'Running') { throw "Existing DiskGuardSpace startup maintenance is currently running. FAIL-CLOSED: retry after it finishes." }
$existingTaskXml = if ($existing) { Export-ScheduledTask -TaskPath $TaskPath -TaskName $TaskName } else { $null }

if (-not (Test-Path $InstallRoot)) { New-Item -ItemType Directory -Path $InstallRoot -Force | Out-Null }
if (Test-Reparse $InstallRoot) { throw "Install root is a reparse point; refusing startup installation." }
$installFull = [IO.Path]::GetFullPath($InstallRoot).TrimEnd('\')
$programFilesFull = [IO.Path]::GetFullPath($env:ProgramFiles).TrimEnd('\')
if (-not $installFull.StartsWith($programFilesFull + '\', [StringComparison]::OrdinalIgnoreCase)) { throw "Install root escaped Program Files." }

$stage = Join-Path $InstallRoot (".install-staging-" + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $stage -Force | Out-Null
$rollbackEntries = @()
try {
    $map = [ordered]@{
        "DiskGuardSpace.exe" = $ExePath
        "RELEASE_PROOF.json" = $ProofPath
        "SOURCE_MANIFEST.sha256" = $SourceManifestPath
        "VERIFY_RELEASE.ps1" = $VerifyReleasePath
        "BACKGROUND_MAINTENANCE.ps1" = $BackgroundSource
        "VERIFY_STARTUP_AUTOMATION.ps1" = $StartupVerifierSource
        "VERIFY_CONTROLLER.ps1" = $ControllerVerifierSource
        "UNINSTALL_STARTUP_AUTOMATION.ps1" = $UninstallSource
    }
    foreach ($name in $map.Keys) { $rollbackEntries += Promote-File $map[$name] (Join-Path $InstallRoot $name) $stage }

    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $userSid = $identity.User.Value
    $userName = $identity.Name
    $backgroundInstalled = Join-Path $InstallRoot "BACKGROUND_MAINTENANCE.ps1"
    $actionArgs = "-NoLogo -NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$backgroundInstalled`""

    $files = @()
    foreach ($name in $map.Keys) {
        $ip = Join-Path $InstallRoot $name
        $files += [ordered]@{ name=$name; sha256=(Get-Sha256 $ip); sizeBytes=(Get-Item $ip).Length }
    }
    $installManifest = [ordered]@{
        schema = "DiskGuardSpace.StartupInstall.v1"
        product = "DiskGuardSpace"
        version = "1.4"
        installedUtc = [DateTime]::UtcNow.ToString('o')
        expectedUserSid = $userSid
        expectedUserName = $userName
        taskPath = $TaskPath
        taskName = $TaskName
        trigger = "AT_LOGON_DELAY_PT5M"
        canonicalPowerShell = $CanonicalPowerShell
        actionArguments = $actionArgs
        installRoot = $InstallRoot
        files = $files
    }
    $manifestPath = Join-Path $InstallRoot "INSTALL_MANIFEST.json"
    $manifestPending = Join-Path $stage "INSTALL_MANIFEST.pending.json"
    $manifestExisted = Test-Path $manifestPath -PathType Leaf
    $manifestBackup = Join-Path $stage "INSTALL_MANIFEST.previous.json"
    $installManifest | ConvertTo-Json -Depth 8 | Set-Content -Encoding UTF8 $manifestPending
    if ($manifestExisted) {
        [IO.File]::Replace($manifestPending, $manifestPath, $manifestBackup, $true)
    } else { Move-Item $manifestPending $manifestPath -Force }
    $rollbackEntries += [pscustomobject]@{ Destination=$manifestPath; Backup=$manifestBackup; Existed=$manifestExisted }

    $action = New-ScheduledTaskAction -Execute $CanonicalPowerShell -Argument $actionArgs -WorkingDirectory $InstallRoot
    $trigger = New-ScheduledTaskTrigger -AtLogOn -User $userSid
    $trigger.Delay = 'PT5M'
    $principal = New-ScheduledTaskPrincipal -UserId $userSid -LogonType Interactive -RunLevel Highest
    $settings = New-ScheduledTaskSettingsSet -Hidden -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -MultipleInstances IgnoreNew -ExecutionTimeLimit (New-TimeSpan -Hours 2)
    $task = New-ScheduledTask -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Description "DiskGuardSpace verified fail-closed background maintenance after user logon."
    Register-ScheduledTask -TaskName $TaskName -TaskPath $TaskPath -InputObject $task -Force | Out-Null

    $installedVerifier = Join-Path $InstallRoot "VERIFY_STARTUP_AUTOMATION.ps1"
    & $installedVerifier -InstallRoot $InstallRoot
    if ($LASTEXITCODE -ne 0) { throw "Startup task post-registration verification failed." }

    Write-Host "STARTUP AUTOMATION INSTALL: VERIFIED_PASS" -ForegroundColor Green
    Write-Host "Task: $TaskPath$TaskName"
    Write-Host "Trigger: user logon + 5 minute delay (hidden/background)"
    Write-Host "Install root: $InstallRoot"
    exit 0
}
catch {
    $reason = $_.Exception.Message
    try {
        if ($existingTaskXml) {
            Register-ScheduledTask -TaskName $TaskName -TaskPath $TaskPath -Xml $existingTaskXml -Force | Out-Null
        } else {
            Unregister-ScheduledTask -TaskName $TaskName -TaskPath $TaskPath -Confirm:$false -ErrorAction SilentlyContinue
        }
    } catch { }
    Restore-Files $rollbackEntries
    Write-Host "STARTUP AUTOMATION INSTALL: FAIL-CLOSED - $reason" -ForegroundColor Red
    exit 2
}
finally {
    try { if (Test-Path $stage) { Remove-Item $stage -Recurse -Force -ErrorAction SilentlyContinue } } catch { }
}
