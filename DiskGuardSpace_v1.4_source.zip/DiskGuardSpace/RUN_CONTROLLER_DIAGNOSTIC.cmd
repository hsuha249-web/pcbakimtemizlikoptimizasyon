@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title DiskGuardSpace v1.4 - Controller Diagnostic Launcher
if not exist "%~dp0logs" mkdir "%~dp0logs" >nul 2>&1
set "LOG=%~dp0logs\CONTROLLER_LAST.log"
set "EXE=%~dp0dist\DiskGuardSpace.exe"
if not exist "%EXE%" (
  echo [FAIL] %EXE% bulunamadi.
  echo Once BUILD_VERIFIED_EXE.cmd calistirin.
  pause
  exit /b 2
)
echo EXE baslatiliyor: %EXE%
echo CLI stderr/stdout log: %LOG%
"%EXE%" 1>"%LOG%" 2>&1
set "EC=%ERRORLEVEL%"
echo.
echo Controller process exit code: %EC%
if not "%EC%"=="0" (
  echo [FAIL-CLOSED] EXE hata ile kapandi.
  echo --- CONTROLLER_LAST.log ---
  type "%LOG%"
  echo.
  echo Ayrica %%LOCALAPPDATA%%\DiskGuardSpace\Logs altindaki en yeni crash-*.json dosyasina bakin.
) else (
  echo Controller normal olarak kapandi.
)
pause
exit /b %EC%
