using System.Diagnostics;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace DiskGuardSpace;

internal sealed record ControllerActionResult(bool Success, string Title, string Detail, string? Folder = null);

internal static class ControllerMaintenanceActions
{
    private const int LongTimeoutMs = 2 * 60 * 60 * 1000;
    private static string? _latestPlanPath;
    private static string? _latestFolder;

    public static string? LatestFolder => _latestFolder;

    public static ControllerActionResult AnalyzePc()
    {
        var run = NewRunDirectory("analyze");
        var report = Path.Combine(run, "auto-care-dry.json");
        var work = Path.Combine(run, "work");
        var exe = CurrentExe();
        var r = RunCaptured(exe, new[] { "auto-care", "--report", report, "--work-dir", work, "--min-age-days", "7", "--min-size-mib", "500", "--duplicate-min-mib", "10", "--top", "150" }, LongTimeoutMs);
        if (r.ExitCode != 0 || r.TimedOut || !File.Exists(report))
            return Fail("Analyze PC", run, r, "Read-only PC analysis did not complete successfully.");
        var verify = RunCaptured(exe, new[] { "verify-auto-care", report }, 10 * 60 * 1000);
        if (verify.ExitCode != 0 || verify.TimedOut)
            return Fail("Analyze PC", run, verify, "Independent auto-care report verification failed.");

        var ar = JsonSerializer.Deserialize<AutoCareReport>(File.ReadAllText(report), Json.Options);
        if (ar is null) return new(false, "Analyze PC", "Analysis report could not be parsed.", run);
        _latestFolder = run;
        return new(true, "Analyze PC — PASS",
            $"Space pressure: {ar.SpacePressure}\r\nMemory: {ar.PerformanceSnapshot?.Assessment ?? "UNKNOWN"}\r\nRemaining safe/review opportunity: {Fmt(ar.RemainingEstimatedOpportunityBytes)}\r\nNext focus: {ar.NextCriticalFocus}\r\nNo write maintenance was performed.", run);
    }

    public static ControllerActionResult SafeCleanup()
    {
        VerifyControlledReleaseForWrite();
        var run = NewRunDirectory("safe-cleanup");
        var report = Path.Combine(run, "safe-cleanup.json");
        var r = RunElevated(CurrentExe(), new[] { "clean-safe", "--yes", "--min-age-days", "7", "--report", report }, LongTimeoutMs);
        if (r.ExitCode != 0 || r.TimedOut || !File.Exists(report))
            return Fail("Safe Cleanup", run, r, "Elevated safe cleanup did not complete with verified evidence.");
        var verify = RunCaptured(CurrentExe(), new[] { "verify-report", report }, 10 * 60 * 1000);
        if (verify.ExitCode != 0) return Fail("Safe Cleanup", run, verify, "Independent cleanup evidence verification failed.");
        var ev = JsonSerializer.Deserialize<EvidenceReport>(File.ReadAllText(report), Json.Options);
        if (ev is null || !ev.VerificationStatus.StartsWith("VERIFIED_PASS", StringComparison.Ordinal))
            return new(false, "Safe Cleanup", "Cleanup evidence did not reach VERIFIED_PASS/BOUNDED.", run);
        _latestFolder = run;
        return new(true, "Safe Cleanup — VERIFIED",
            $"Verified observed free-space gain: {Fmt(ev.VerifiedFreeGainBytes)}\r\nVerified source allocation removed: {Fmt(ev.SourceAllocatedBytesRemoved)}\r\nSucceeded: {ev.SucceededActions:N0}\r\nPreserved/skipped: {ev.BlockedActions + ev.FailedActions:N0}\r\nStatus: {ev.VerificationStatus}", run);
    }

    public static ControllerActionResult FullAutoCare()
    {
        VerifyControlledReleaseForWrite();
        var run = NewRunDirectory("full-auto-care");
        var report = Path.Combine(run, "auto-care.json");
        var r = RunElevated(CurrentExe(), new[] { "auto-care", "--apply", "--deep-health", "--report", report, "--work-dir", run, "--min-age-days", "7", "--min-size-mib", "500", "--duplicate-min-mib", "10", "--top", "150" }, LongTimeoutMs);
        if (r.ExitCode != 0 || r.TimedOut || !File.Exists(report))
            return Fail("Full Auto-Care", run, r, "Full fail-closed auto-care did not complete successfully.");
        var verify = RunCaptured(CurrentExe(), new[] { "verify-auto-care", report }, 10 * 60 * 1000);
        if (verify.ExitCode != 0) return Fail("Full Auto-Care", run, verify, "Independent master-report verification failed.");
        return AutoCareSummary("Full Auto-Care", run, report);
    }

    public static ControllerActionResult PerformanceCare()
    {
        VerifyControlledReleaseForWrite();
        var run = NewRunDirectory("performance-care");
        var report = Path.Combine(run, "auto-care.json");
        var r = RunElevated(CurrentExe(), new[] { "auto-care", "--apply", "--skip-component-cleanup", "--skip-delivery-optimization", "--skip-deep-analysis", "--report", report, "--work-dir", run, "--min-age-days", "7", "--top", "80" }, LongTimeoutMs);
        if (r.ExitCode != 0 || r.TimedOut || !File.Exists(report))
            return Fail("Performance Care", run, r, "Performance-focused maintenance did not complete successfully.");
        var verify = RunCaptured(CurrentExe(), new[] { "verify-auto-care", report }, 10 * 60 * 1000);
        if (verify.ExitCode != 0) return Fail("Performance Care", run, verify, "Independent performance-care report verification failed.");
        return AutoCareSummary("Performance Care", run, report);
    }

    public static ControllerActionResult CreateSpaceRecoveryPlan()
    {
        var run = NewRunDirectory("space-plan");
        var plan = Path.Combine(run, "space-plan-40g.json");
        var r = RunCaptured(CurrentExe(), new[] { "plan-space", "--target-gib", "40", "--min-age-days", "7", "--report", plan }, LongTimeoutMs);
        if (r.ExitCode != 0 || r.TimedOut || !File.Exists(plan))
            return Fail("40 GiB Space Recovery Plan", run, r, "Fail-closed allowlist plan generation failed.");
        var sp = JsonSerializer.Deserialize<SpacePlanReport>(File.ReadAllText(plan), Json.Options);
        if (sp is null) return new(false, "40 GiB Space Recovery Plan", "Plan JSON could not be parsed.", run);
        _latestPlanPath = plan;
        _latestFolder = run;
        return new(true, "40 GiB Space Recovery Plan — READY",
            $"Target: {Fmt(sp.TargetBytes)}\r\nHash-bound SAFE_AUTO candidates: {sp.Candidates.Count:N0}\r\nProven allocated opportunity: {Fmt(sp.SafeAllocatedBytes)}\r\nStatus: {sp.Status}\r\nNo candidate was deleted. Use Apply Space Plan only if you want the unchanged allowlisted manifest applied.", run);
    }

    public static ControllerActionResult ApplyLatestSpacePlan()
    {
        VerifyControlledReleaseForWrite();
        var plan = ResolveLatestPlan();
        if (string.IsNullOrWhiteSpace(plan) || !File.Exists(plan))
            return new(false, "Apply Space Plan", "No current 40 GiB space-plan manifest exists. Generate a plan first.", _latestFolder);
        var run = NewRunDirectory("apply-space-plan");
        var report = Path.Combine(run, "apply-space-plan.json");
        var r = RunElevated(CurrentExe(), new[] { "apply-space-plan", "--manifest", plan, "--yes", "--confirm", "SPACE_PLAN_APPLY", "--report", report }, LongTimeoutMs);
        if (r.ExitCode != 0 || r.TimedOut || !File.Exists(report))
            return Fail("Apply Space Plan", run, r, "The manifest was changed, no longer safe, or cleanup could not be proven.");
        var verify = RunCaptured(CurrentExe(), new[] { "verify-report", report }, 10 * 60 * 1000);
        if (verify.ExitCode != 0) return Fail("Apply Space Plan", run, verify, "Independent plan-application evidence verification failed.");
        var ev = JsonSerializer.Deserialize<EvidenceReport>(File.ReadAllText(report), Json.Options);
        if (ev is null || !ev.VerificationStatus.StartsWith("VERIFIED_PASS", StringComparison.Ordinal))
            return new(false, "Apply Space Plan", "Plan cleanup did not reach a verified pass status.", run);
        _latestFolder = run;
        return new(true, "Apply Space Plan — VERIFIED",
            $"Verified free-space gain: {Fmt(ev.VerifiedFreeGainBytes)}\r\nVerified source allocation removed: {Fmt(ev.SourceAllocatedBytesRemoved)}\r\nStatus: {ev.VerificationStatus}", run);
    }

    public static ControllerActionResult EnableStartupMaintenance()
    {
        VerifyControlledReleaseForWrite();
        var script = LocateSourceFile("INSTALL_STARTUP_AUTOMATION.ps1")
            ?? throw new FileNotFoundException("INSTALL_STARTUP_AUTOMATION.ps1 was not found next to the source package. Run this button from the verified dist EXE inside the DiskGuardSpace source folder.");
        var root = Path.GetDirectoryName(script)!;
        var manifest = Path.Combine(root, "SOURCE_MANIFEST.sha256");
        var verifyRelease = Path.Combine(root, "VERIFY_RELEASE.ps1");
        var proof = Path.Combine(Path.GetDirectoryName(CurrentExe())!, "RELEASE_PROOF.json");
        if (!File.Exists(manifest) || !File.Exists(verifyRelease) || !File.Exists(proof))
            throw new FileNotFoundException("Startup-install verification inputs are incomplete.");
        var ps = CanonicalPowerShell();
        var r = RunElevated(ps, new[] { "-NoLogo", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", script, "-ExePath", CurrentExe(), "-ProofPath", proof, "-SourceManifestPath", manifest, "-VerifyReleasePath", verifyRelease }, 20 * 60 * 1000);
        if (r.ExitCode != 0 || r.TimedOut)
            return Fail("Enable Startup Maintenance", root, r, "Verified startup-task installation failed or UAC was cancelled.");
        _latestFolder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "DiskGuardSpace", "Background");
        return new(true, "Startup Maintenance — ENABLED",
            "Verified task installed with Highest run level and a 5-minute logon delay.\r\nEvery boot: safe allowlisted cleanup + lightweight diagnostics.\r\nDelivery Optimization: max 1 day. Deep analysis: max 3 days. Drive /O: max 7 days. DISM component cleanup: max 14 days. Deep SFC/CHKDSK health: max 14 days. Full self/negative verification: every 7 days or EXE change.", _latestFolder);
    }

    public static void OpenLatestFolder()
    {
        var folder = _latestFolder;
        if (string.IsNullOrWhiteSpace(folder) || !Directory.Exists(folder))
            folder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "DiskGuardSpace");
        Directory.CreateDirectory(folder);
        Process.Start(new ProcessStartInfo("explorer.exe", folder) { UseShellExecute = true });
    }

    private static ControllerActionResult AutoCareSummary(string title, string run, string report)
    {
        var ar = JsonSerializer.Deserialize<AutoCareReport>(File.ReadAllText(report), Json.Options);
        if (ar is null) return new(false, title, "Auto-care report could not be parsed.", run);
        _latestFolder = run;
        var drive = ar.DriveOptimization is null ? "not due/skipped" : (ar.DriveOptimization.Succeeded ? "verified success" : "failed");
        return new(ar.OverallStatus == "VERIFIED_PASS", title + " — " + ar.OverallStatus,
            $"Observed net free-space change: {FmtSigned(ar.NetObservedFreeGainBytes)}\r\nSafe cleanup verified gain: {Fmt(ar.VerifiedSafeCleanupGainBytes)}\r\nDelivery Optimization gain: {Fmt(ar.VerifiedDeliveryOptimizationGainBytes)}\r\nComponent cleanup gain: {Fmt(ar.VerifiedComponentCleanupGainBytes)}\r\nDrive optimization: {drive}\r\nNext focus: {ar.NextCriticalFocus}\r\nStatus: {ar.OverallStatus}", run);
    }

    private static string ResolveLatestPlan()
    {
        if (!string.IsNullOrWhiteSpace(_latestPlanPath) && File.Exists(_latestPlanPath)) return _latestPlanPath;
        var root = GuiRoot();
        if (!Directory.Exists(root)) return "";
        return Directory.EnumerateFiles(root, "space-plan-40g.json", SearchOption.AllDirectories)
            .Select(p => new FileInfo(p)).OrderByDescending(x => x.LastWriteTimeUtc).Select(x => x.FullName).FirstOrDefault() ?? "";
    }

    private static string NewRunDirectory(string label)
    {
        var root = GuiRoot();
        if (!ControllerPathPolicy.IsAllowedProofDirectory(root)) throw new IOException("FAIL-CLOSED: GUI run root is outside canonical LocalAppData.");
        Directory.CreateDirectory(root);
        if (SafetyPolicy.IsReparsePoint(root)) throw new IOException("FAIL-CLOSED: GUI run root is a reparse point.");
        var dir = Path.Combine(root, DateTime.UtcNow.ToString("yyyyMMdd-HHmmss") + "-" + label + "-" + Guid.NewGuid().ToString("N")[..8]);
        if (Directory.Exists(dir) || File.Exists(dir)) throw new IOException("FAIL-CLOSED: GUI run directory collision.");
        Directory.CreateDirectory(dir);
        _latestFolder = dir;
        return dir;
    }

    private static string GuiRoot() => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "DiskGuardSpace", "GuiRuns");
    private static string CurrentExe() => Path.GetFullPath(Environment.ProcessPath ?? throw new InvalidOperationException("Running EXE path unavailable."));

    private static void VerifyControlledReleaseForWrite()
    {
        var exe = CurrentExe();
        var proofPath = Path.Combine(Path.GetDirectoryName(exe)!, "RELEASE_PROOF.json");
        if (!File.Exists(proofPath)) throw new InvalidOperationException("FAIL-CLOSED: write maintenance requires adjacent RELEASE_PROOF.json from BUILD_VERIFIED_EXE.");
        using var doc = JsonDocument.Parse(File.ReadAllText(proofPath));
        var r = doc.RootElement;
        var hash = Sha256(exe);
        bool ok = r.TryGetProperty("schema", out var schema) && schema.GetString() == "DiskGuardSpace.ReleaseProof.v1"
            && r.TryGetProperty("product", out var product) && product.GetString() == "DiskGuardSpace"
            && r.TryGetProperty("version", out var version) && version.GetString() == "1.4"
            && r.TryGetProperty("result", out var result) && result.GetString() == "VERIFIED_PASS"
            && r.TryGetProperty("exeSha256", out var expectedHash) && string.Equals(expectedHash.GetString(), hash, StringComparison.OrdinalIgnoreCase)
            && r.TryGetProperty("exeSizeBytes", out var size) && size.GetInt64() == new FileInfo(exe).Length;
        if (!ok) throw new InvalidOperationException("FAIL-CLOSED: running EXE does not match its verified v1.4 release proof.");
    }

    private static string? LocateSourceFile(string name)
    {
        var exeDir = Path.GetDirectoryName(CurrentExe())!;
        foreach (var dir in new[] { exeDir, Directory.GetParent(exeDir)?.FullName, AppContext.BaseDirectory })
        {
            if (string.IsNullOrWhiteSpace(dir)) continue;
            var p = Path.Combine(dir, name);
            if (File.Exists(p) && !SafetyPolicy.IsReparsePoint(p)) return Path.GetFullPath(p);
        }
        return null;
    }

    private static string CanonicalPowerShell()
    {
        var windows = Environment.GetFolderPath(Environment.SpecialFolder.Windows);
        var p = Path.Combine(windows, "System32", "WindowsPowerShell", "v1.0", "powershell.exe");
        if (!File.Exists(p)) throw new FileNotFoundException("Canonical Windows PowerShell not found.", p);
        return p;
    }

    private static ControllerCommandResult RunCaptured(string file, IEnumerable<string> args, int timeoutMs)
    {
        var psi = new ProcessStartInfo(file) { UseShellExecute = false, RedirectStandardOutput = true, RedirectStandardError = true, CreateNoWindow = true };
        foreach (var a in args) psi.ArgumentList.Add(a);
        using var p = Process.Start(psi) ?? throw new InvalidOperationException("Child process could not be started.");
        var stdout = p.StandardOutput.ReadToEndAsync();
        var stderr = p.StandardError.ReadToEndAsync();
        if (!p.WaitForExit(timeoutMs))
        {
            try { p.Kill(entireProcessTree: true); } catch { }
            return new(-1, stdout.IsCompletedSuccessfully ? stdout.Result : "", stderr.IsCompletedSuccessfully ? stderr.Result : "", true);
        }
        Task.WaitAll(new Task[] { stdout, stderr }, 10000);
        return new(p.ExitCode, stdout.Result, stderr.Result, false);
    }

    private static ControllerCommandResult RunElevated(string file, IEnumerable<string> args, int timeoutMs)
    {
        try
        {
            var psi = new ProcessStartInfo(file) { UseShellExecute = true, Verb = "runas", WindowStyle = ProcessWindowStyle.Hidden, WorkingDirectory = Path.GetDirectoryName(file) ?? Environment.CurrentDirectory };
            foreach (var a in args) psi.ArgumentList.Add(a);
            using var p = Process.Start(psi) ?? throw new InvalidOperationException("Elevated process could not be started.");
            if (!p.WaitForExit(timeoutMs))
            {
                try { p.Kill(entireProcessTree: true); } catch { }
                return new(-1, "", "Elevated process timed out.", true);
            }
            return new(p.ExitCode, "", "", false);
        }
        catch (Exception ex)
        {
            return new(1223, "", ex.Message, false);
        }
    }

    private static ControllerActionResult Fail(string title, string folder, ControllerCommandResult r, string prefix)
    {
        _latestFolder = folder;
        var detail = prefix + $"\r\nExit: {r.ExitCode}; timeout: {r.TimedOut}";
        if (!string.IsNullOrWhiteSpace(r.StdErr)) detail += "\r\n" + Trim(r.StdErr);
        if (!string.IsNullOrWhiteSpace(r.StdOut)) detail += "\r\n" + Trim(r.StdOut);
        return new(false, title + " — FAIL-CLOSED", detail, folder);
    }

    private static string Trim(string text)
    {
        var s = (text ?? "").Replace('\r', ' ').Replace('\n', ' ').Trim();
        return s.Length <= 800 ? s : s[..800] + "…";
    }

    private static string Sha256(string path)
    {
        using var fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read);
        return Convert.ToHexString(SHA256.HashData(fs)).ToLowerInvariant();
    }

    private static string Fmt(long b) => b >= 1024L * 1024L * 1024L ? $"{b / 1073741824d:0.00} GiB" : $"{b / 1048576d:0.00} MiB";
    private static string FmtSigned(long b) => (b < 0 ? "-" : "+") + Fmt(Math.Abs(b));
}
