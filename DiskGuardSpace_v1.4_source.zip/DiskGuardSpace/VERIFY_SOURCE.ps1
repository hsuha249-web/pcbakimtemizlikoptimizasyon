$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Manifest = Join-Path $Root "SOURCE_MANIFEST.sha256"
if (-not (Test-Path $Manifest -PathType Leaf)) { throw "SOURCE_MANIFEST.sha256 missing" }

$fail = 0
$pass = 0
$listed = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
Get-Content $Manifest | ForEach-Object {
    if ([string]::IsNullOrWhiteSpace($_)) { return }
    if ($_ -notmatch '^([0-9a-fA-F]{64})\s{2}(.+)$') {
        Write-Host "FAIL malformed manifest line: $_" -ForegroundColor Red
        $script:fail++
        return
    }
    $expected = $Matches[1].ToUpperInvariant()
    $name = $Matches[2]
    if ($name -match '(^|[\\/])\.\.?([\\/]|$)' -or [IO.Path]::IsPathRooted($name)) {
        Write-Host "FAIL unsafe manifest path: $name" -ForegroundColor Red
        $script:fail++
        return
    }
    [void]$listed.Add($name)
    $path = Join-Path $Root $name
    $full = [IO.Path]::GetFullPath($path)
    $rootPrefix = [IO.Path]::GetFullPath($Root).TrimEnd('\') + '\'
    if (-not $full.StartsWith($rootPrefix, [StringComparison]::OrdinalIgnoreCase)) {
        Write-Host "FAIL manifest path escapes source root: $name" -ForegroundColor Red
        $script:fail++
        return
    }
    if (-not (Test-Path $full -PathType Leaf)) {
        Write-Host "FAIL missing: $name" -ForegroundColor Red
        $script:fail++
        return
    }
    $actual = (Get-FileHash $full -Algorithm SHA256).Hash.ToUpperInvariant()
    if ($actual -ne $expected) {
        Write-Host "FAIL hash mismatch: $name" -ForegroundColor Red
        $script:fail++
    } else {
        $script:pass++
    }
}

# Fail closed if a build-affecting or release-control file exists but is not locked by the manifest.
$trackedExtensions = @('.cs','.csproj','.ps1','.py','.md','.cmd')
$unexpected = @(Get-ChildItem $Root -File | Where-Object {
    $_.Name -ne 'SOURCE_MANIFEST.sha256' -and
    $trackedExtensions -contains $_.Extension.ToLowerInvariant() -and
    -not $listed.Contains($_.Name)
})
foreach ($u in $unexpected) {
    Write-Host "FAIL unmanifested tracked source/control file: $($u.Name)" -ForegroundColor Red
    $fail++
}

if ($fail -ne 0) {
    Write-Host "SOURCE MANIFEST: FAIL ($pass pass / $fail fail)" -ForegroundColor Red
    exit 2
}
Write-Host "SOURCE MANIFEST: VERIFIED_PASS ($pass files; strict coverage)" -ForegroundColor Green
exit 0
