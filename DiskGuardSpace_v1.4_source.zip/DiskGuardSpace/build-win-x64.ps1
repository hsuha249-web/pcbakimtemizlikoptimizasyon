$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $Root

Write-Host "DEVELOPER BUILD ONLY - this output is NOT a verified release artifact." -ForegroundColor Yellow
Write-Host "Use .\\BUILD_VERIFIED_EXE.ps1 for the controlled releasable EXE." -ForegroundColor Yellow

Write-Host "[1/4] dotnet information" -ForegroundColor Cyan
dotnet --info
Write-Host "[2/4] restore" -ForegroundColor Cyan
dotnet restore .\DiskGuardSpace.csproj --nologo
Write-Host "[3/4] publish win-x64 self-contained single-file" -ForegroundColor Cyan
dotnet publish .\DiskGuardSpace.csproj -c Release -r win-x64 --self-contained true --nologo --no-restore `
  -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true `
  -p:DebugType=None -p:DebugSymbols=false -p:Deterministic=true -p:ContinuousIntegrationBuild=true -p:PublishReadyToRun=false

$Exe = Join-Path $Root "bin\Release\net8.0\win-x64\publish\DiskGuardSpace.exe"
if (-not (Test-Path $Exe)) { throw "Published EXE not found: $Exe" }
Write-Host "[4/4] developer binary evidence" -ForegroundColor Cyan
Get-FileHash $Exe -Algorithm SHA256 | Format-Table -AutoSize
Write-Host "DEVELOPER BUILD COMPLETE - UNVERIFIED FOR RELEASE" -ForegroundColor Yellow
