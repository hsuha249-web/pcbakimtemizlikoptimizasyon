# DiskGuardSpace v1.2 changelog

## Controller startup reliability

- Fixed a parent-console visibility bug in v1.1. Controller mode no longer calls `ShowWindow(GetConsoleWindow(), SW_HIDE)`, which could hide a CMD/PowerShell window shared with the child process.
- Controller mode now detaches only the DiskGuardSpace process from an inherited console with `FreeConsole()`.
- Top-level controller startup failures are persisted under `%LOCALAPPDATA%\DiskGuardSpace\Logs\crash-*.json` before exit.
- Fatal GUI startup failures show a native Windows error dialog containing the persistent crash-log path.

## Never-vanish launchers

- `BUILD_VERIFIED_EXE.cmd` now writes `logs\BUILD_LAST.log`, prints the saved log back to screen, and always pauses on PASS or FAIL.
- Added `FIRST_RUN.cmd`; it writes `logs\FIRST_RUN_LAST.log` and never auto-closes before the user can read the result.
- Added `RUN_CONTROLLER_DIAGNOSTIC.cmd`; it launches the final release EXE, preserves stdout/stderr and keeps the diagnostic terminal open if the controller exits with an error.

## Release/controller proof

The existing controller proof remains mandatory. v1.2 adds explicit static gates for:

- crash-proof persistence,
- parent-console preservation,
- persistent launcher logs,
- pause-on-failure behavior,
- controller product-version identity.
