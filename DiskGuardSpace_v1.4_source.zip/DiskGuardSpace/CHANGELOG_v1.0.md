# DiskGuardSpace v1.0 changelog

## Verified automatic startup maintenance

- Installs the certified EXE/proof/runtime scripts under `%ProgramFiles%\DiskGuardSpace`.
- Registers a hidden per-user Task Scheduler logon trigger with a 3-minute delay.
- Uses canonical Windows PowerShell and exact task/action identity verification.
- Adds installed-file SHA-256/size manifest verification.
- Adds once-per-Windows-boot execution guard.
- Adds weekly-or-EXE-change packaged self-test + negative/regression revalidation.
- Adds explicit `--startup-background` evidence mode to the auto-care master report.
- Keeps disk-space recovery as priority #1 while retaining heavy-maintenance cooldown, AC, health and reboot gates.
- Bounded retention keeps only the newest 30 DiskGuardSpace background session directories.
- Adds startup automation verification and fail-closed uninstall scripts.
- Product/assembly/controlled-release version advanced to 1.0.0 / 1.0.

## v1.1 planned/implemented safety surfaces

- Adds hash-bound `plan-space` and confirmation-bound `apply-space-plan` commands.
- Adds opt-in administrator-only `update-guard` with boot plus twelve-hour Task Scheduler checks.
- Update Guard limits cleanup to old `SoftwareDistribution\\Download` files and restores owned service/policy state on disable.
- Codex sessions, personal folders, virtual disks, archives, installers, databases and `bugbounty-platform` source/evidence remain protected.
