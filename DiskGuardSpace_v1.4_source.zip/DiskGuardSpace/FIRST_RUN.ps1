$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $Root

Write-Host "DiskGuardSpace v1.4 first run" -ForegroundColor Cyan
Write-Host "Controlled chain: source lock -> staged single EXE -> packaged tests -> read-only PC proof -> native controller GUI proof -> atomic release -> final controller proof -> verified startup task -> first auto-care." -ForegroundColor Yellow
Write-Host "It may request Windows UAC Administrator permission once. After install, future startup maintenance runs hidden without repeated UAC prompts." -ForegroundColor Yellow
& .\INSTALL_AND_RUN.ps1
exit $LASTEXITCODE
