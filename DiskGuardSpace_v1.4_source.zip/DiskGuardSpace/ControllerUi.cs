using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace DiskGuardSpace;

internal sealed record ControllerCheck(string Name, string Status, string Detail, bool Required = true);
internal sealed record ControllerCommandResult(int ExitCode, string StdOut, string StdErr, bool TimedOut);

internal sealed class ControllerProof
{
    public string Schema { get; init; } = "DiskGuardSpace.ControllerProof.v1";
    public string Product { get; init; } = "DiskGuardSpace";
    public string Version { get; init; } = "1.4";
    public string CreatedUtc { get; init; } = DateTime.UtcNow.ToString("O");
    public string Overall { get; set; } = "FAIL";
    public bool WritesPerformed { get; init; } = false;
    public string Executable { get; init; } = "";
    public string ExeSha256 { get; init; } = "";
    public long ExeSizeBytes { get; init; }
    public string ReleaseProofIdentity { get; set; } = "NOT_PRESENT";
    public string ProofDirectory { get; init; } = "";
    public List<ControllerCheck> Checks { get; init; } = new();
    public Dictionary<string, string> ArtifactSha256 { get; init; } = new(StringComparer.OrdinalIgnoreCase);
}

internal sealed record ControllerOptions(string ProofDirectory)
{
    public static ControllerOptions Parse(string[] args)
    {
        string? requested = null;
        for (int i = 0; i < args.Length; i++)
        {
            if (args[i] == "--proof-dir")
            {
                if (++i >= args.Length) throw new ArgumentException("--proof-dir için değer gerekir.");
                requested = args[i];
            }
            else
            {
                throw new ArgumentException($"Controller için bilinmeyen seçenek: {args[i]}");
            }
        }

        var root = string.IsNullOrWhiteSpace(requested)
            ? Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "DiskGuardSpace", "ControllerProof", DateTime.UtcNow.ToString("yyyyMMdd-HHmmss") + "-" + Guid.NewGuid().ToString("N")[..8])
            : requested;

        var full = Path.GetFullPath(root);
        if (!ControllerPathPolicy.IsAllowedProofDirectory(full))
            throw new InvalidOperationException("FAIL-CLOSED: controller proof directory is outside canonical LocalAppData or crosses an unsafe path boundary.");
        return new ControllerOptions(full);
    }
}

internal static class ControllerPathPolicy
{
    public static bool IsAllowedProofDirectory(string path)
    {
        try
        {
            if (!OperatingSystem.IsWindows() || string.IsNullOrWhiteSpace(path) || SafetyPolicy.HasUnsafePathSyntax(path)) return false;
            var full = SafetyPolicy.Normalize(path);
            var local = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            if (string.IsNullOrWhiteSpace(local)) return false;

            bool UnderOrEqual(string candidate, string root)
            {
                var r = SafetyPolicy.Normalize(root);
                return candidate.Equals(r, StringComparison.OrdinalIgnoreCase) || SafetyPolicy.IsUnderRoot(candidate, r);
            }

            if (!UnderOrEqual(full, local)) return false;
            var allowedRoot = SafetyPolicy.Normalize(local);

            // Existing reparse ancestors could redirect proof writes outside the intended tree.
            var current = full;
            while (!current.Equals(allowedRoot, StringComparison.OrdinalIgnoreCase))
            {
                if (Directory.Exists(current) && SafetyPolicy.IsReparsePoint(current)) return false;
                var parent = Path.GetDirectoryName(current);
                if (string.IsNullOrWhiteSpace(parent) || parent.Equals(current, StringComparison.OrdinalIgnoreCase)) return false;
                current = SafetyPolicy.Normalize(parent);
                if (!UnderOrEqual(current, allowedRoot)) return false;
            }
            return !SafetyPolicy.IsReparsePoint(allowedRoot);
        }
        catch { return false; }
    }
}

internal static class ControllerVerifier
{
    private const int CommandTimeoutMs = 10 * 60 * 1000;

    public static ControllerProof Run(ControllerOptions options)
    {
        if (!OperatingSystem.IsWindows()) throw new PlatformNotSupportedException("Controller yalnızca Windows üzerinde çalışır.");
        if (!ControllerPathPolicy.IsAllowedProofDirectory(options.ProofDirectory))
            throw new InvalidOperationException("FAIL-CLOSED: controller proof directory validation failed at execution time.");

        Directory.CreateDirectory(options.ProofDirectory);
        if (SafetyPolicy.IsReparsePoint(options.ProofDirectory))
            throw new IOException("FAIL-CLOSED: controller proof directory became a reparse point.");

        var exe = Environment.ProcessPath ?? throw new InvalidOperationException("Current EXE path could not be resolved.");
        exe = Path.GetFullPath(exe);
        var proofPath = Path.Combine(options.ProofDirectory, "CONTROLLER_PROOF.json");
        var scanReport = Path.Combine(options.ProofDirectory, "controller-scan.json");
        var autoReport = Path.Combine(options.ProofDirectory, "controller-auto-care-dry.json");
        var autoWork = Path.Combine(options.ProofDirectory, "auto-care-dry-work");

        if (File.Exists(proofPath) || File.Exists(scanReport) || File.Exists(autoReport) || Directory.Exists(autoWork))
            throw new IOException("FAIL-CLOSED: controller proof directory is not clean; refusing to overwrite pre-existing evidence/work artifacts.");

        var result = new ControllerProof
        {
            Executable = exe,
            ExeSha256 = ComputeSha256(exe),
            ExeSizeBytes = new FileInfo(exe).Length,
            ProofDirectory = options.ProofDirectory
        };

        Add(result, "controller_process_identity", File.Exists(exe), exe);
        Add(result, "proof_absent_before_action", !File.Exists(proofPath) && !File.Exists(scanReport) && !File.Exists(autoReport),
            "No controller result artifacts existed before the verification action.");

        VerifyReleaseProofIfPresent(result, exe);

        RunGate(result, "packaged_self_test", exe, new[] { "self-test" });
        RunGate(result, "packaged_negative_tests", exe, new[] { "negative-tests" });
        RunGate(result, "read_only_safe_scan", exe, new[] { "scan", "--min-age-days", "7", "--report", scanReport });
        Add(result, "scan_report_created", File.Exists(scanReport), scanReport);
        if (File.Exists(scanReport))
            RunGate(result, "independent_scan_report_verify", exe, new[] { "verify-report", scanReport });
        else
            Add(result, "independent_scan_report_verify", false, "scan report missing");

        RunGate(result, "pc_specific_auto_care_dry_run", exe,
            new[] { "auto-care", "--report", autoReport, "--work-dir", autoWork, "--min-age-days", "7", "--min-size-mib", "500", "--duplicate-min-mib", "10", "--top", "100" });
        Add(result, "auto_care_dry_report_created", File.Exists(autoReport), autoReport);
        if (File.Exists(autoReport))
            RunGate(result, "independent_auto_care_verify", exe, new[] { "verify-auto-care", autoReport });
        else
            Add(result, "independent_auto_care_verify", false, "auto-care dry-run report missing");

        foreach (var p in new[] { scanReport, autoReport })
        {
            if (File.Exists(p)) result.ArtifactSha256[Path.GetFileName(p)] = ComputeSha256(p);
        }

        result.Overall = result.Checks.Where(c => c.Required).All(c => c.Status == "PASS") ? "PASS" : "FAIL";
        AtomicWriteJson(proofPath, result);
        result.ArtifactSha256[Path.GetFileName(proofPath)] = ComputeSha256(proofPath);
        return result;
    }

    private static void VerifyReleaseProofIfPresent(ControllerProof result, string exe)
    {
        var releaseProof = Path.Combine(Path.GetDirectoryName(exe) ?? AppContext.BaseDirectory, "RELEASE_PROOF.json");
        if (!File.Exists(releaseProof))
        {
            result.ReleaseProofIdentity = "NOT_PRESENT";
            result.Checks.Add(new ControllerCheck("release_proof_identity", "SKIP", "RELEASE_PROOF.json is not adjacent to this staging/dev EXE.", Required: false));
            return;
        }

        try
        {
            using var doc = JsonDocument.Parse(File.ReadAllText(releaseProof));
            var root = doc.RootElement;
            bool ok = root.TryGetProperty("schema", out var schema) && schema.GetString() == "DiskGuardSpace.ReleaseProof.v1"
                && root.TryGetProperty("product", out var product) && product.GetString() == "DiskGuardSpace"
                && root.TryGetProperty("version", out var version) && version.GetString() == "1.4"
                && root.TryGetProperty("result", out var status) && status.GetString() == "VERIFIED_PASS"
                && root.TryGetProperty("exeSha256", out var hash) && string.Equals(hash.GetString(), result.ExeSha256, StringComparison.OrdinalIgnoreCase)
                && root.TryGetProperty("exeSizeBytes", out var size) && size.TryGetInt64(out var expectedSize) && expectedSize == result.ExeSizeBytes;
            result.ReleaseProofIdentity = ok ? "PASS" : "FAIL";
            Add(result, "release_proof_identity", ok, releaseProof);
        }
        catch (Exception ex)
        {
            result.ReleaseProofIdentity = "FAIL";
            Add(result, "release_proof_identity", false, $"{ex.GetType().Name}: {ex.Message}");
        }
    }

    private static void RunGate(ControllerProof proof, string name, string exe, IReadOnlyList<string> args)
    {
        try
        {
            var r = RunChild(exe, args, CommandTimeoutMs);
            var detail = r.TimedOut
                ? "timeout"
                : $"exit={r.ExitCode}; stdout={Trim(r.StdOut)}; stderr={Trim(r.StdErr)}";
            Add(proof, name, !r.TimedOut && r.ExitCode == 0, detail);
        }
        catch (Exception ex)
        {
            Add(proof, name, false, $"{ex.GetType().Name}: {ex.Message}");
        }
    }

    private static ControllerCommandResult RunChild(string exe, IReadOnlyList<string> args, int timeoutMs)
    {
        var psi = new ProcessStartInfo(exe)
        {
            UseShellExecute = false,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            CreateNoWindow = true,
            WorkingDirectory = Path.GetDirectoryName(exe) ?? AppContext.BaseDirectory
        };
        foreach (var a in args) psi.ArgumentList.Add(a);
        using var p = Process.Start(psi) ?? throw new IOException("Child process could not be started.");
        var outTask = p.StandardOutput.ReadToEndAsync();
        var errTask = p.StandardError.ReadToEndAsync();
        if (!p.WaitForExit(timeoutMs))
        {
            try { p.Kill(entireProcessTree: true); } catch { }
            try { Task.WaitAll(new Task[] { outTask, errTask }, 5000); } catch { }
            return new ControllerCommandResult(-1, SafeTaskResult(outTask), SafeTaskResult(errTask), true);
        }
        try { Task.WaitAll(new Task[] { outTask, errTask }, 10000); } catch { }
        return new ControllerCommandResult(p.ExitCode, SafeTaskResult(outTask), SafeTaskResult(errTask), false);
    }

    private static string SafeTaskResult(Task<string> task)
        => task.IsCompletedSuccessfully ? task.Result : "";

    private static string Trim(string s)
    {
        s = (s ?? "").Replace('\r', ' ').Replace('\n', ' ').Trim();
        return s.Length <= 360 ? s : s[..360] + "…";
    }

    private static void Add(ControllerProof proof, string name, bool ok, string detail)
        => proof.Checks.Add(new ControllerCheck(name, ok ? "PASS" : "FAIL", detail));

    private static string ComputeSha256(string path)
    {
        using var fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read);
        return Convert.ToHexString(SHA256.HashData(fs)).ToLowerInvariant();
    }

    private static void AtomicWriteJson(string path, object value)
    {
        var dir = Path.GetDirectoryName(path) ?? throw new InvalidOperationException("Proof path has no directory.");
        Directory.CreateDirectory(dir);
        var tmp = path + ".tmp-" + Guid.NewGuid().ToString("N");
        try
        {
            var bytes = Encoding.UTF8.GetBytes(JsonSerializer.Serialize(value, Json.Options));
            using (var fs = new FileStream(tmp, FileMode.CreateNew, FileAccess.Write, FileShare.None, 4096, FileOptions.WriteThrough))
            {
                fs.Write(bytes, 0, bytes.Length);
                fs.Flush(flushToDisk: true);
            }
            if (File.Exists(path)) File.Move(tmp, path, overwrite: true);
            else File.Move(tmp, path);
        }
        finally
        {
            try { if (File.Exists(tmp)) File.Delete(tmp); } catch { }
        }
    }
}

internal static class ControllerUi
{
    private const string WindowClass = "DiskGuardSpaceControllerWindow_v14";
    private const string BaseTitle = "DiskGuardSpace Controller v1.4";
    private const int IdRun = 1001;
    private const int IdOpen = 1002;
    private const int IdExit = 1003;
    private const int IdAnalyze = 1010;
    private const int IdSafeCleanup = 1011;
    private const int IdFullCare = 1012;
    private const int IdPerformance = 1013;
    private const int IdSpacePlan = 1014;
    private const int IdApplyPlan = 1015;
    private const int IdStartup = 1016;
    private const int IdOpenLatest = 1017;
    private const uint WmDestroy = 0x0002;
    private const uint WmClose = 0x0010;
    private const uint WmCommand = 0x0111;
    private const uint WmSetFont = 0x0030;
    private const uint WmAppResult = 0x8001;
    private const uint WmAppActionResult = 0x8002;
    private const uint WsVisible = 0x10000000;
    private const uint WsChild = 0x40000000;
    private const uint WsBorder = 0x00800000;
    private const uint WsVScroll = 0x00200000;
    private const uint WsTabStop = 0x00010000;
    private const uint WsOverlappedWindow = 0x00CF0000;
    private const uint EsMultiline = 0x0004;
    private const uint EsAutoVScroll = 0x0040;
    private const uint EsReadOnly = 0x0800;
    private const int SwShow = 5;
    private const int SwHide = 0;
    private const int ColorWindow = 5;
    private const int DefaultGuiFont = 17;
    private const uint MbIconWarning = 0x00000030;
    private const uint MbIconQuestion = 0x00000020;
    private const uint MbYesNo = 0x00000004;
    private const int IdYes = 6;

    private static readonly WndProcDelegate WndProc = WindowProc;
    private static nint _window;
    private static nint _status;
    private static nint _log;
    private static nint _runButton;
    private static readonly List<nint> ActionButtons = new();
    private static ControllerOptions? _options;
    private static Task? _worker;
    private static ControllerProof? _lastProof;
    private static ControllerActionResult? _lastAction;
    private static string _activeActionName = "";

    public static int Run(string[] args)
    {
        if (!OperatingSystem.IsWindows()) throw new PlatformNotSupportedException("Controller yalnızca Windows üzerinde çalışır.");
        _options = ControllerOptions.Parse(args);
        return RunCore();
    }

    private static int RunCore()
    {
        HideConsoleWindow();

        var instance = GetModuleHandleW(null);
        var cls = new WndClassEx
        {
            cbSize = (uint)Marshal.SizeOf<WndClassEx>(),
            lpfnWndProc = Marshal.GetFunctionPointerForDelegate(WndProc),
            hInstance = instance,
            hCursor = LoadCursorW(0, (nint)32512),
            hbrBackground = (nint)(ColorWindow + 1),
            lpszClassName = WindowClass
        };
        if (RegisterClassExW(ref cls) == 0)
        {
            var err = Marshal.GetLastWin32Error();
            // ERROR_CLASS_ALREADY_EXISTS is harmless for re-entry in the same process image.
            if (err != 1410) throw new InvalidOperationException($"Controller window class registration failed: {err}");
        }

        _window = CreateWindowExW(0, WindowClass, BaseTitle + " | STATUS: READY", WsOverlappedWindow,
            80, 40, 1040, 790, 0, 0, instance, 0);
        if (_window == 0) throw new InvalidOperationException($"Controller window creation failed: {Marshal.GetLastWin32Error()}");

        ShowWindow(_window, SwShow);
        UpdateWindow(_window);
        while (GetMessageW(out var msg, 0, 0, 0) > 0)
        {
            TranslateMessage(ref msg);
            DispatchMessageW(ref msg);
        }
        return 0;
    }

    private static nint WindowProc(nint hwnd, uint msg, nint wParam, nint lParam)
    {
        if (msg == 0x0001) // WM_CREATE
        {
            BuildControls(hwnd);
            return 0;
        }
        if (msg == WmCommand)
        {
            var id = (int)(wParam.ToInt64() & 0xFFFF);
            if (id == IdRun) { StartVerification(); return 0; }
            if (id == IdOpen) { OpenProofDirectory(); return 0; }
            if (id == IdAnalyze) { StartAction("Analyze PC", false, ControllerMaintenanceActions.AnalyzePc); return 0; }
            if (id == IdSafeCleanup) { StartAction("Safe Cleanup", true, ControllerMaintenanceActions.SafeCleanup, "Only verified allowlisted temp/cache candidates will be removed. Changed, locked, hard-linked, read-only or unverifiable files are preserved. Continue with UAC elevation?"); return 0; }
            if (id == IdFullCare) { StartAction("Full Auto-Care", true, ControllerMaintenanceActions.FullAutoCare, "Run fail-closed safe cleanup + supported Windows maintenance + performance care + deep read-only health checks now? UAC elevation is required."); return 0; }
            if (id == IdPerformance) { StartAction("Performance Care", true, ControllerMaintenanceActions.PerformanceCare, "Run performance-focused fail-closed maintenance now? Registry/service tweak hacks are not used. UAC elevation is required."); return 0; }
            if (id == IdSpacePlan) { StartAction("40 GiB Space Recovery Plan", false, ControllerMaintenanceActions.CreateSpaceRecoveryPlan); return 0; }
            if (id == IdApplyPlan) { StartAction("Apply Space Plan", true, ControllerMaintenanceActions.ApplyLatestSpacePlan, "Apply only the unchanged SHA-256-bound SAFE_AUTO candidates from the latest 40 GiB plan? Any changed or unsafe candidate causes fail-closed refusal."); return 0; }
            if (id == IdStartup) { StartAction("Enable Startup Maintenance", true, ControllerMaintenanceActions.EnableStartupMaintenance, "Install/update verified automatic maintenance for every Windows logon, 5 minutes after sign-in, at Highest run level? Heavy stages remain cadence-gated."); return 0; }
            if (id == IdOpenLatest) { try { ControllerMaintenanceActions.OpenLatestFolder(); } catch (Exception ex) { MessageBoxW(_window, ex.Message, BaseTitle, MbIconWarning); } return 0; }
            if (id == IdExit) { SendMessageW(hwnd, WmClose, 0, 0); return 0; }
        }
        if (msg == WmAppResult)
        {
            FinishVerification();
            return 0;
        }
        if (msg == WmAppActionResult)
        {
            FinishAction();
            return 0;
        }
        if (msg == WmClose)
        {
            if (_worker is { IsCompleted: false })
            {
                MessageBoxW(hwnd, "A DiskGuardSpace verification/maintenance action is still running. Wait for PASS/FAIL before closing the controller.", BaseTitle, MbIconWarning);
                return 0;
            }
            DestroyWindow(hwnd);
            return 0;
        }
        if (msg == WmDestroy)
        {
            PostQuitMessage(0);
            return 0;
        }
        return DefWindowProcW(hwnd, msg, wParam, lParam);
    }

    private static void BuildControls(nint hwnd)
    {
        var font = GetStockObject(DefaultGuiFont);
        var title = Create("STATIC", "DiskGuardSpace — Verified Maintenance Controller", WsChild | WsVisible, 24, 18, 900, 28, hwnd, 0);
        var sub = Create("STATIC", "Disk space is priority #1. Write actions require the verified release proof and UAC; unsafe/changed candidates are preserved fail-closed.", WsChild | WsVisible, 24, 48, 950, 42, hwnd, 0);
        _status = Create("STATIC", "STATUS: READY — choose an analysis, cleanup, maintenance or verification action", WsChild | WsVisible, 24, 92, 950, 24, hwnd, 0);

        _runButton = Create("BUTTON", "Run Read-Only Verification", WsChild | WsVisible | WsTabStop, 24, 128, 220, 36, hwnd, IdRun);
        var analyze = Create("BUTTON", "Analyze PC", WsChild | WsVisible | WsTabStop, 254, 128, 150, 36, hwnd, IdAnalyze);
        var safe = Create("BUTTON", "Safe Cleanup", WsChild | WsVisible | WsTabStop, 414, 128, 150, 36, hwnd, IdSafeCleanup);
        var full = Create("BUTTON", "Full Auto-Care", WsChild | WsVisible | WsTabStop, 574, 128, 150, 36, hwnd, IdFullCare);
        var performance = Create("BUTTON", "Performance Care", WsChild | WsVisible | WsTabStop, 734, 128, 170, 36, hwnd, IdPerformance);

        var plan = Create("BUTTON", "40 GiB Space Plan", WsChild | WsVisible | WsTabStop, 24, 174, 180, 36, hwnd, IdSpacePlan);
        var applyPlan = Create("BUTTON", "Apply Space Plan", WsChild | WsVisible | WsTabStop, 214, 174, 170, 36, hwnd, IdApplyPlan);
        var startup = Create("BUTTON", "Enable Startup Maintenance", WsChild | WsVisible | WsTabStop, 394, 174, 220, 36, hwnd, IdStartup);
        var openLatest = Create("BUTTON", "View Candidates / Runs", WsChild | WsVisible | WsTabStop, 624, 174, 150, 36, hwnd, IdOpenLatest);
        var open = Create("BUTTON", "Open Proof Folder", WsChild | WsVisible | WsTabStop, 784, 174, 160, 36, hwnd, IdOpen);
        var exit = Create("BUTTON", "Close", WsChild | WsVisible | WsTabStop, 844, 220, 100, 34, hwnd, IdExit);

        var policy = Create("STATIC", "Automatic policy: every boot +5 min safe cleanup/light diagnostics | Delivery Optimization ≤24h | deep analysis ≤3d | drive /O ≤7d | DISM component cleanup ≤14d | SFC verify + CHKDSK scan ≤14d | full self/negative verification ≤7d or EXE change", WsChild | WsVisible, 24, 220, 800, 52, hwnd, 0);
        _log = Create("EDIT", "Controller loaded.\r\n\r\nRecommended first use: Analyze PC → Safe Cleanup or Full Auto-Care → Enable Startup Maintenance.\r\n\r\n40 GiB Space Plan is a fail-closed target, not a promise: it only manifests allowlisted reproducible/cache/update candidates. Apply Space Plan re-hashes every unchanged candidate before deletion.\r\n\r\nThe original Run Read-Only Verification button remains the release-controller proof gate and performs no write maintenance.",
            WsChild | WsVisible | WsBorder | WsVScroll | EsMultiline | EsAutoVScroll | EsReadOnly,
            24, 282, 920, 440, hwnd, 0);
        ActionButtons.Clear();
        ActionButtons.AddRange(new[] { _runButton, analyze, safe, full, performance, plan, applyPlan, startup, openLatest, open, exit });
        foreach (var h in new[] { title, sub, _status, policy, _log }.Concat(ActionButtons)) SendMessageW(h, WmSetFont, font, (nint)1);
    }

    private static nint Create(string cls, string text, uint style, int x, int y, int w, int h, nint parent, int id)
    {
        var handle = CreateWindowExW(0, cls, text, style, x, y, w, h, parent, (nint)id, GetModuleHandleW(null), 0);
        if (handle == 0) throw new InvalidOperationException($"Controller child control creation failed: {cls}");
        return handle;
    }

    private static void StartVerification()
    {
        if (_worker is { IsCompleted: false } || _options is null) return;
        SetActionButtonsEnabled(false);
        SetWindowTextW(_window, BaseTitle + " | STATUS: RUNNING");
        SetWindowTextW(_status, "STATUS: RUNNING — packaged EXE is being verified read-only");
        SetWindowTextW(_log, "Verification running…\r\nThis may take several minutes on a large or busy PC.\r\nNo cleanup/write maintenance is performed by this controller proof.");
        _lastProof = null;
        _worker = Task.Run(() =>
        {
            try
            {
                _lastProof = ControllerVerifier.Run(_options);
            }
            catch (Exception ex)
            {
                _lastProof = new ControllerProof
                {
                    Executable = Environment.ProcessPath ?? "",
                    ProofDirectory = _options.ProofDirectory,
                    Overall = "FAIL",
                    Checks = new List<ControllerCheck> { new("controller_unhandled_failure", "FAIL", $"{ex.GetType().Name}: {ex.Message}") }
                };
            }
            PostMessageW(_window, WmAppResult, 0, 0);
        });
    }

    private static void FinishVerification()
    {
        SetActionButtonsEnabled(true);
        var proof = _lastProof;
        if (proof is null)
        {
            SetWindowTextW(_window, BaseTitle + " | STATUS: FAIL");
            SetWindowTextW(_status, "STATUS: FAIL — controller produced no result");
            return;
        }
        var pass = proof.Overall == "PASS";
        SetWindowTextW(_window, BaseTitle + (pass ? " | STATUS: PASS" : " | STATUS: FAIL"));
        SetWindowTextW(_status, pass
            ? "STATUS: PASS — packaged EXE and read-only proof gates passed"
            : "STATUS: FAIL — at least one required proof gate failed");

        var sb = new StringBuilder();
        sb.AppendLine($"Overall: {proof.Overall}");
        sb.AppendLine($"EXE SHA-256: {proof.ExeSha256}");
        sb.AppendLine($"Release proof identity: {proof.ReleaseProofIdentity}");
        sb.AppendLine($"Proof directory: {proof.ProofDirectory}");
        sb.AppendLine();
        foreach (var c in proof.Checks)
            sb.AppendLine($"[{c.Status}] {c.Name} — {c.Detail}");
        sb.AppendLine();
        sb.AppendLine("CONTROLLER_PROOF.json is the machine-readable evidence artifact.");
        SetWindowTextW(_log, sb.ToString().Replace("\n", "\r\n"));
    }

    private static void StartAction(string name, bool confirmationRequired, Func<ControllerActionResult> action, string confirmationText = "")
    {
        if (_worker is { IsCompleted: false }) return;
        if (confirmationRequired)
        {
            var answer = MessageBoxW(_window, confirmationText, BaseTitle + " — " + name, MbYesNo | MbIconQuestion);
            if (answer != IdYes) return;
        }
        _activeActionName = name;
        _lastAction = null;
        SetActionButtonsEnabled(false);
        SetWindowTextW(_window, BaseTitle + " | STATUS: RUNNING");
        SetWindowTextW(_status, "STATUS: RUNNING — " + name);
        SetWindowTextW(_log, (name + " is running…\r\nFail-closed safety gates remain active. Do not power off the PC during elevated write stages.").Replace("\n", "\r\n"));
        _worker = Task.Run(() =>
        {
            try { _lastAction = action(); }
            catch (Exception ex) { _lastAction = new ControllerActionResult(false, name + " — FAIL-CLOSED", ex.GetType().Name + ": " + ex.Message, ControllerMaintenanceActions.LatestFolder); }
            PostMessageW(_window, WmAppActionResult, 0, 0);
        });
    }

    private static void FinishAction()
    {
        SetActionButtonsEnabled(true);
        var r = _lastAction;
        if (r is null)
        {
            SetWindowTextW(_window, BaseTitle + " | STATUS: FAIL");
            SetWindowTextW(_status, "STATUS: FAIL — " + _activeActionName + " returned no result");
            return;
        }
        SetWindowTextW(_window, BaseTitle + (r.Success ? " | STATUS: PASS" : " | STATUS: FAIL"));
        SetWindowTextW(_status, (r.Success ? "STATUS: PASS — " : "STATUS: FAIL — ") + r.Title);
        var text = r.Title + "\r\n\r\n" + r.Detail;
        if (!string.IsNullOrWhiteSpace(r.Folder)) text += "\r\n\r\nEvidence/run folder:\r\n" + r.Folder;
        SetWindowTextW(_log, text);
    }

    private static void SetActionButtonsEnabled(bool enabled)
    {
        foreach (var h in ActionButtons) if (h != 0) EnableWindow(h, enabled);
    }

    private static void OpenProofDirectory()
    {
        if (_options is null) return;
        try
        {
            Directory.CreateDirectory(_options.ProofDirectory);
            Process.Start(new ProcessStartInfo("explorer.exe", _options.ProofDirectory) { UseShellExecute = true });
        }
        catch (Exception ex)
        {
            MessageBoxW(_window, ex.Message, BaseTitle, MbIconWarning);
        }
    }

    private static void HideConsoleWindow()
    {
        // Do NOT hide GetConsoleWindow() with ShowWindow(SW_HIDE): when launched from
        // CMD/PowerShell that console can be shared with the parent. Hiding it makes
        // the parent terminal appear to disappear. Detach only this process instead.
        try { FreeConsole(); } catch { }
    }

    private delegate nint WndProcDelegate(nint hwnd, uint msg, nint wParam, nint lParam);

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    private struct WndClassEx
    {
        public uint cbSize;
        public uint style;
        public nint lpfnWndProc;
        public int cbClsExtra;
        public int cbWndExtra;
        public nint hInstance;
        public nint hIcon;
        public nint hCursor;
        public nint hbrBackground;
        [MarshalAs(UnmanagedType.LPWStr)] public string? lpszMenuName;
        [MarshalAs(UnmanagedType.LPWStr)] public string? lpszClassName;
        public nint hIconSm;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct Msg
    {
        public nint hwnd;
        public uint message;
        public nuint wParam;
        public nint lParam;
        public uint time;
        public int ptX;
        public int ptY;
        public uint lPrivate;
    }

    [DllImport("kernel32.dll", CharSet = CharSet.Unicode)] private static extern nint GetModuleHandleW(string? lpModuleName);
    [DllImport("kernel32.dll")] private static extern nint GetConsoleWindow();
    [DllImport("kernel32.dll")] private static extern bool FreeConsole();
    [DllImport("user32.dll", CharSet = CharSet.Unicode, SetLastError = true)] private static extern ushort RegisterClassExW(ref WndClassEx lpwcx);
    [DllImport("user32.dll", CharSet = CharSet.Unicode, SetLastError = true)] private static extern nint CreateWindowExW(uint exStyle, string cls, string name, uint style, int x, int y, int w, int h, nint parent, nint menu, nint instance, nint param);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] private static extern nint DefWindowProcW(nint hwnd, uint msg, nint wParam, nint lParam);
    [DllImport("user32.dll")] private static extern bool ShowWindow(nint hwnd, int cmdShow);
    [DllImport("user32.dll")] private static extern bool UpdateWindow(nint hwnd);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] private static extern int GetMessageW(out Msg msg, nint hwnd, uint min, uint max);
    [DllImport("user32.dll")] private static extern bool TranslateMessage(ref Msg msg);
    [DllImport("user32.dll")] private static extern nint DispatchMessageW(ref Msg msg);
    [DllImport("user32.dll")] private static extern void PostQuitMessage(int exitCode);
    [DllImport("user32.dll")] private static extern bool DestroyWindow(nint hwnd);
    [DllImport("user32.dll")] private static extern bool EnableWindow(nint hwnd, bool enable);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] private static extern bool SetWindowTextW(nint hwnd, string text);
    [DllImport("user32.dll")] private static extern nint SendMessageW(nint hwnd, uint msg, nint wParam, nint lParam);
    [DllImport("user32.dll")] private static extern bool PostMessageW(nint hwnd, uint msg, nint wParam, nint lParam);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] private static extern int MessageBoxW(nint hwnd, string text, string caption, uint type);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] private static extern nint LoadCursorW(nint instance, nint cursorName);
    [DllImport("gdi32.dll")] private static extern nint GetStockObject(int objectId);
}
