using System.Diagnostics;
using System.Security.Cryptography;
using System.Security.Principal;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace DiskGuardSpace;

internal static class Program
{
    private const long MiB = 1024L * 1024L;
    private const long GiB = 1024L * 1024L * 1024L;

    [STAThread]
    static int Main(string[] args)
    {
        Console.OutputEncoding = Encoding.UTF8;
        try
        {
            if (args.Length == 0)
                return ControllerUi.Run(Array.Empty<string>());

            if (args[0] is "-h" or "--help" or "help")
            {
                PrintHelp();
                return 0;
            }

            return args[0].ToLowerInvariant() switch
            {
                "controller" => ControllerUi.Run(args.Skip(1).ToArray()),
                "scan" => RunScan(args.Skip(1).ToArray()),
                "clean-safe" => RunCleanSafe(args.Skip(1).ToArray()),
                "analyze-deep" => RunAnalyzeDeep(args.Skip(1).ToArray()),
                "plan-space" => SpacePlanRunner.Plan(CliOptions.Parse(args.Skip(1).ToArray())),
                "apply-space-plan" => SpacePlanRunner.Apply(CliOptions.Parse(args.Skip(1).ToArray())),
                "update-guard" => UpdateGuardRunner.Run(args.Skip(1).ToArray()),
                "windows-maintenance" => RunWindowsMaintenance(args.Skip(1).ToArray()),
                "auto-care" => AutoCareRunner.Run(args.Skip(1).ToArray()),
                "verify-auto-care" => AutoCareRunner.Verify(args.Skip(1).ToArray()),
                "verify-report" => VerifyReport(args.Skip(1).ToArray()),
                "verify-analysis" => VerifyAnalysis(args.Skip(1).ToArray()),
                "self-test" => SelfTest(),
                "negative-tests" => NegativeTests.Run(),
                _ => Fail($"Bilinmeyen komut: {args[0]}")
            };
        }
        catch (Exception ex)
        {
            var guiLaunch = args.Length == 0 || (args.Length > 0 && args[0].Equals("controller", StringComparison.OrdinalIgnoreCase));
            var logPath = CrashDiagnostics.TryWrite(ex, guiLaunch ? "controller-startup" : "command", args);
            Console.Error.WriteLine($"FAIL-CLOSED: {ex.GetType().Name}: {ex.Message}");
            if (!string.IsNullOrWhiteSpace(logPath)) Console.Error.WriteLine($"CRASH LOG: {logPath}");
            if (guiLaunch) CrashDiagnostics.ShowFatalDialog(ex, logPath);
            return 20;
        }
    }

    private static int RunScan(string[] args)
    {
        EnsureWindows();
        var options = CliOptions.Parse(args);
        var roots = SafetyPolicy.GetApprovedCleanupRoots();
        var before = DiskSnapshot.CaptureSystemDrive();
        var result = Scanner.ScanApprovedRoots(roots, options.MinAgeDays);
        var report = EvidenceReport.FromScan("scan", before, DiskSnapshot.CaptureSystemDrive(), result);
        var path = ReportIO.WriteEvidence(report, options.ReportPath);
        PrintSummary(report, path);
        return report.FailClosedViolations == 0 ? 0 : 30;
    }

    private static int RunCleanSafe(string[] args)
    {
        EnsureWindows();
        var options = CliOptions.Parse(args);
        if (!options.Yes)
            return Fail("FAIL-CLOSED: clean-safe için bilinçli onay gerekir: --yes");

        var roots = SafetyPolicy.GetApprovedCleanupRoots();
        var before = DiskSnapshot.CaptureSystemDrive();
        var scan = Scanner.ScanApprovedRoots(roots, options.MinAgeDays);

        if (scan.FailClosedViolations > 0)
            return Fail("FAIL-CLOSED: tarama sırasında güvenlik ihlali görüldü; hiçbir dosya silinmedi.");

        var execution = Cleaner.ExecuteSafeCandidates(scan.Candidates, roots, options.QuarantinePath);
        var after = DiskSnapshot.CaptureSystemDrive();
        var report = EvidenceReport.FromExecution("clean-safe", before, after, scan, execution);
        var path = ReportIO.WriteEvidence(report, options.ReportPath);
        PrintSummary(report, path);

        return report.VerificationStatus.StartsWith("VERIFIED_PASS", StringComparison.Ordinal) ? 0 : 40;
    }

    private static int RunAnalyzeDeep(string[] args)
    {
        EnsureWindows();
        var options = CliOptions.Parse(args);
        var before = DiskSnapshot.CaptureSystemDrive();
        var analysis = OpportunityAnalyzer.Analyze(options);
        var after = DiskSnapshot.CaptureSystemDrive();
        var report = AnalysisReport.Create(before, after, analysis, options);
        var path = ReportIO.WriteAnalysis(report, options.ReportPath);
        PrintAnalysisSummary(report, path);
        return report.FailClosedViolations == 0 ? 0 : 31;
    }

    private static int RunWindowsMaintenance(string[] args)
    {
        EnsureWindows();
        var options = CliOptions.Parse(args);
        if (!options.Yes)
            return Fail("FAIL-CLOSED: windows-maintenance için bilinçli onay gerekir: --yes");
        if (!WindowsMaintenance.IsAdministrator())
            return Fail("FAIL-CLOSED: Windows component cleanup için PowerShell/Terminal yönetici olarak açılmalı.");

        var before = DiskSnapshot.CaptureSystemDrive();
        var execution = WindowsMaintenance.RunStartComponentCleanup();
        var after = DiskSnapshot.CaptureSystemDrive();
        var report = EvidenceReport.FromMaintenance(before, after, execution);
        var path = ReportIO.WriteEvidence(report, options.ReportPath);
        PrintSummary(report, path);
        return report.VerificationStatus.StartsWith("VERIFIED_PASS", StringComparison.Ordinal) ? 0 : 41;
    }

    private static int VerifyReport(string[] args)
    {
        if (args.Length < 1) return Fail("Kullanım: verify-report <report.json>");
        var report = JsonSerializer.Deserialize<EvidenceReport>(File.ReadAllText(args[0]), Json.Options)
                     ?? throw new InvalidDataException("Rapor okunamadı.");
        var recomputed = EvidenceVerifier.Verify(report);
        Console.WriteLine(JsonSerializer.Serialize(recomputed, Json.Options));
        return recomputed.Status == "VERIFIED_PASS" ? 0 : 50;
    }

    private static int VerifyAnalysis(string[] args)
    {
        if (args.Length < 1) return Fail("Kullanım: verify-analysis <analysis.json>");
        var report = JsonSerializer.Deserialize<AnalysisReport>(File.ReadAllText(args[0]), Json.Options)
                     ?? throw new InvalidDataException("Analiz raporu okunamadı.");
        var recomputed = AnalysisVerifier.Verify(report);
        Console.WriteLine(JsonSerializer.Serialize(recomputed, Json.Options));
        return recomputed.Status == "VERIFIED_PASS" ? 0 : 51;
    }

    private static int SelfTest()
    {
        var failures = new List<string>();
        var tempBase = Path.Combine(Path.GetTempPath(), "DiskGuardSpace-SelfTest-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(tempBase);
        try
        {
            var allowed = Path.Combine(tempBase, "allowed");
            var blocked = Path.Combine(tempBase, "blocked");
            var dup = Path.Combine(tempBase, "dup");
            Directory.CreateDirectory(allowed);
            Directory.CreateDirectory(blocked);
            Directory.CreateDirectory(dup);

            var a = Path.Combine(allowed, "old.tmp");
            var b = Path.Combine(blocked, "keep.txt");
            var d1 = Path.Combine(dup, "copy1.bin");
            var d2 = Path.Combine(dup, "copy2.bin");
            var d3 = Path.Combine(dup, "different.bin");
            File.WriteAllBytes(a, new byte[64 * 1024]);
            File.WriteAllText(b, "KEEP");
            var duplicatePayload = Encoding.UTF8.GetBytes(new string('X', 2 * 1024 * 1024));
            File.WriteAllBytes(d1, duplicatePayload);
            File.WriteAllBytes(d2, duplicatePayload);
            File.WriteAllBytes(d3, Encoding.UTF8.GetBytes(new string('Y', 2 * 1024 * 1024)));
            File.SetLastWriteTimeUtc(a, DateTime.UtcNow.AddDays(-10));

            if (!SafetyPolicy.IsUnderRoot(a, allowed)) failures.Add("Allowed root containment failed");
            if (SafetyPolicy.IsUnderRoot(b, allowed)) failures.Add("Boundary escape accepted");
            if (!SafetyPolicy.IsOldEnough(a, 3)) failures.Add("Age rule failed");
            if (SafetyPolicy.IsOldEnough(b, 3)) failures.Add("Young file accepted");

            var h1 = Hashing.Sha256(a);
            var h2 = Hashing.Sha256(a);
            if (!CryptographicOperations.FixedTimeEquals(Convert.FromHexString(h1), Convert.FromHexString(h2)))
                failures.Add("SHA256 stability failed");

            var rootSpec = new ApprovedRoot(allowed, "SELF_TEST", 1);
            var fakeCandidate = new Candidate(a, new FileInfo(a).Length, File.GetLastWriteTimeUtc(a), "SELF_TEST", "SAFE", allowed);
            var exec = Cleaner.ExecuteSafeCandidates(new[] { fakeCandidate }, new[] { rootSpec }, quarantinePath: null);
            if (File.Exists(a)) failures.Add("Safe cleanup did not delete allowed test file");
            if (exec.Succeeded != 1 || exec.Failed != 0) failures.Add("Execution counters invalid");
            if (!File.Exists(b)) failures.Add("Blocked file was modified");

            var dupGroups = DuplicateFinder.Find(new[] { dup }, 1, 50, out var dupViolations);
            if (dupViolations != 0) failures.Add("Duplicate finder reported violation in sandbox");
            if (dupGroups.Count != 1 || dupGroups[0].Files.Count != 2) failures.Add("Duplicate grouping failed");
            if (dupGroups.Count == 1 && dupGroups[0].PotentialSavingsBytes != duplicatePayload.Length)
                failures.Add("Duplicate savings arithmetic failed");

            var compressibleText = Path.Combine(dup, "compressible.txt");
            File.WriteAllText(compressibleText, new string('A', 512 * 1024));
            var estimate = CompressionEstimator.Estimate(compressibleText, 256 * 1024);
            if (estimate.SampleBytes <= 0 || estimate.EstimatedSavingsBytes <= 0)
                failures.Add("Compression estimator failed on compressible sample");

            Console.WriteLine(failures.Count == 0 ? "SELF_TEST: VERIFIED_PASS" : "SELF_TEST: FAIL");
            foreach (var f in failures) Console.WriteLine(" - " + f);
            return failures.Count == 0 ? 0 : 60;
        }
        finally
        {
            try { Directory.Delete(tempBase, true); } catch { }
        }
    }

    private static void EnsureWindows()
    {
        if (!OperatingSystem.IsWindows())
            throw new PlatformNotSupportedException("Bu sürüm güvenlik politikaları nedeniyle yalnızca Windows üzerinde çalışır.");
    }

    internal static void EnsureWindowsForInternal() => EnsureWindows();
    internal static void PrintSummaryForInternal(EvidenceReport report, string path) => PrintSummary(report, path);

    private static void PrintSummary(EvidenceReport r, string reportPath)
    {
        Console.WriteLine();
        Console.WriteLine("=== DiskGuardSpace Evidence ===");
        Console.WriteLine($"Mode                 : {r.Mode}");
        Console.WriteLine($"Candidates           : {r.CandidateCount}");
        Console.WriteLine($"Candidate logical    : {Fmt(r.CandidateBytes)}");
        Console.WriteLine($"Candidate allocated  : {Fmt(r.CandidateAllocatedBytes)}");
        Console.WriteLine($"Successful actions   : {r.SucceededActions}");
        Console.WriteLine($"Blocked/skipped      : {r.BlockedActions}");
        Console.WriteLine($"Failed actions       : {r.FailedActions}");
        Console.WriteLine($"Read errors/skips    : {r.ReadErrors}");
        Console.WriteLine($"Free before          : {Fmt(r.FreeBytesBefore)}");
        Console.WriteLine($"Free after           : {Fmt(r.FreeBytesAfter)}");
        Console.WriteLine($"Verified free gain   : {FmtSigned(r.VerifiedFreeGainBytes)}");
        Console.WriteLine($"Source logical removed: {Fmt(r.SourceBytesRemoved)}");
        Console.WriteLine($"Source allocated removed: {Fmt(r.SourceAllocatedBytesRemoved)}");
        Console.WriteLine($"Fail-closed blocks   : {r.FailClosedViolations}");
        Console.WriteLine($"Verification         : {r.VerificationStatus}");
        Console.WriteLine($"Report               : {reportPath}");
    }

    private static void PrintAnalysisSummary(AnalysisReport r, string reportPath)
    {
        Console.WriteLine();
        Console.WriteLine("=== DiskGuardSpace Deep Analysis (READ-ONLY) ===");
        Console.WriteLine($"Large files          : {r.LargeFiles.Count} / {Fmt(r.LargeFiles.Sum(x => x.SizeBytes))}");
        Console.WriteLine($"Old installers       : {r.OldInstallers.Count} / {Fmt(r.OldInstallers.Sum(x => x.SizeBytes))}");
        Console.WriteLine($"Duplicate groups     : {r.DuplicateGroups.Count} / logical {Fmt(r.DuplicatePotentialSavingsBytes)} / physical {Fmt(r.DuplicatePhysicalPotentialSavingsBytes)}");
        Console.WriteLine($"Compression candidates: {r.CompressionOpportunities.Count} / estimated {Fmt(r.CompressionEstimatedSavingsBytes)}");
        Console.WriteLine($"Directory hotspots   : {r.DirectoryHotspots.Count} / largest {(r.DirectoryHotspots.Count > 0 ? Fmt(r.DirectoryHotspots[0].TotalBytes) : "0 MiB")}");
        Console.WriteLine($"Inventory coverage   : {r.InventoryFilesScanned:N0} files / logical {Fmt(r.InventoryBytesScanned)} / allocated {Fmt(r.InventoryAllocatedBytesScanned)}");
        Console.WriteLine($"Coverage limitations : read={r.ReadErrors}, allocation-fallback={r.AllocationMeasurementErrors}");
        Console.WriteLine($"Analysis bounded     : {r.AnalysisTruncated} {(string.IsNullOrWhiteSpace(r.AnalysisTruncationReason) ? "" : "(" + r.AnalysisTruncationReason + ")")}");
        Console.WriteLine($"Total opportunity*   : {Fmt(r.TotalEstimatedOpportunityBytes)}");
        Console.WriteLine($"Fail-closed blocks   : {r.FailClosedViolations}");
        Console.WriteLine($"Verification         : {r.VerificationStatus}");
        Console.WriteLine($"Report               : {reportPath}");
        Console.WriteLine("* Categories can overlap. The report also includes de-duplicated conservative totals.");
    }

    private static string Fmt(long bytes) => bytes >= GiB ? $"{bytes / (double)GiB:0.00} GiB" : $"{bytes / (double)MiB:0.00} MiB";
    private static string FmtSigned(long bytes) => (bytes < 0 ? "-" : "+") + Fmt(Math.Abs(bytes));
    private static int Fail(string s) { Console.Error.WriteLine(s); return 2; }

    private static void PrintHelp()
    {
        Console.WriteLine("""
DiskGuardSpace v1.4 - verified-controller + allocation-aware fail-closed Windows disk space recovery + multi-technique PC maintenance

Double-click / no arguments:
  Opens the native DiskGuardSpace Runtime Controller. The controller proves the packaged EXE
  using read-only Windows checks and writes CONTROLLER_PROOF.json.

Commands:
  controller [--proof-dir DIR]
      Opens the native verification controller explicitly. The proof directory is restricted
      to LocalAppData/TEMP and the verification performs no cleanup/write maintenance.

  scan [--min-age-days N] [--report FILE]
      Approved temp/crash/browser-cache roots are scanned. No changes are made.

  clean-safe --yes [--min-age-days N] [--quarantine DRIVE:\PATH] [--report FILE]
      Deletes only candidates under exact built-in approved cache/temp roots.
      If --quarantine is used, it MUST be on a different volume from the source.
      File hash is verified at the destination before the source is removed.

  analyze-deep [--min-age-days N] [--min-size-mib N] [--duplicate-min-mib N]
               [--top N] [--report FILE]
      READ-ONLY. Scans user data roots plus AppData\Local with bounded coverage for
      large files, directory hotspots, old installers/archives, exact duplicate groups
      and representative compression opportunities. Nothing is deleted.

  windows-maintenance --yes [--report FILE]
      Runs Microsoft's DISM StartComponentCleanup only. Requires Administrator.
      /ResetBase is NEVER used. Free space is measured before/after.

  auto-care [--apply] [--deep-health] [--startup-background] [--report FILE] [--work-dir DIR]
            [--skip-component-cleanup] [--skip-delivery-optimization] [--skip-performance] [--skip-deep-analysis]
      PC-specific fail-closed maintenance. Priority #1 is disk space.
      Performs negative preflight controls, safe cache/temp cleanup, supported Delivery
      Optimization cleanup, DISM component cleanup, media-aware drive optimization (/O),
      bounded deep space analysis, performance snapshot and maintenance diagnostics.
      --deep-health adds read-only SFC /verifyonly and CHKDSK /scan after space work.
      --startup-background records that the run came from the verified Windows startup task.
      --skip-deep-analysis defers the 120-second deep inventory stage for cadence-controlled startup runs.
      Running browsers/Electron apps are detected and only their cache categories are skipped.
      Without --apply this is read-only/dry-run.

  verify-auto-care AUTO-CARE.json
      Independently checks the master auto-care report arithmetic and safety-gate evidence.

  verify-report REPORT.json
      Recomputes evidence report consistency checks.

  verify-analysis ANALYSIS.json
      Recomputes deep-analysis arithmetic and duplicate integrity checks.

  self-test
      Runs isolated containment/hash/delete/duplicate/compression tests.

  negative-tests
      Tries path escape, poisoned TEMP, changed/locked files, hard links, read-only files,
      same-volume quarantine, quick-hash collision, forged category/age, interrupted-run
      recovery, blast-radius limits and evidence/release-tampering failure cases.

Defaults:
  --min-age-days 7
  --min-size-mib 500
  --duplicate-min-mib 10
  --top 100

Safety:
  No arbitrary path delete command exists.
  Automatic deletion is bound to a verified Windows file handle, not a re-resolved path.
  Hard-linked, read-only, system-attributed, changed, in-use or unverifiable files are preserved.
  No recursive directory deletion is used for cleanup.
  Large files / duplicates / installers are READ-ONLY findings, never auto-deleted.
  Reparse points/junctions/symlinks are not traversed.
  System32, WinSxS, Program Files and arbitrary user folders are never cleanup roots.

  plan-space [--target-gib N] [--min-age-days N] [--report FILE]
      READ-ONLY allowlist manifest for physical-space-safe candidates.

  apply-space-plan --manifest FILE --yes --confirm SPACE_PLAN_APPLY [--report FILE]
      Applies only an unchanged, hash-verified plan-space manifest.

  update-guard enable --interval-hours N --yes --confirm UPDATE_GUARD_RISK
  update-guard disable | status | run-once [--report FILE]
      Optional twice-daily Windows Update guard. Disabled by default.
""");
    }
}

internal sealed class CliOptions
{
    public int MinAgeDays { get; init; } = 7;
    public int MinSizeMiB { get; init; } = 500;
    public int DuplicateMinMiB { get; init; } = 10;
    public int Top { get; init; } = 100;
    public bool Yes { get; init; }
    public string? ReportPath { get; init; }
    public string? QuarantinePath { get; init; }
    public string? ManifestPath { get; init; }
    public string Confirm { get; init; } = "";
    public int TargetGiB { get; init; } = 50;

    public static CliOptions Parse(string[] args)
    {
        int days = 7;
        int minSizeMiB = 500;
        int duplicateMinMiB = 10;
        int top = 100;
        bool yes = false;
        string? report = null;
        string? quarantine = null;
        string? manifest = null;
        string confirm = "";
        int targetGiB = 50;

        for (int i = 0; i < args.Length; i++)
        {
            switch (args[i])
            {
                case "--yes": yes = true; break;
                case "--min-age-days":
                    days = ParseBoundedInt(args, ref i, "--min-age-days", 1, 3650); break;
                case "--min-size-mib":
                    minSizeMiB = ParseBoundedInt(args, ref i, "--min-size-mib", 1, 1024 * 1024); break;
                case "--duplicate-min-mib":
                    duplicateMinMiB = ParseBoundedInt(args, ref i, "--duplicate-min-mib", 1, 1024 * 1024); break;
                case "--top":
                    top = ParseBoundedInt(args, ref i, "--top", 1, 5000); break;
                case "--report":
                    if (++i >= args.Length) throw new ArgumentException("--report değer bekliyor.");
                    report = args[i];
                    break;
                case "--quarantine":
                    if (++i >= args.Length) throw new ArgumentException("--quarantine değer bekliyor.");
                    quarantine = args[i];
                    break;
                case "--manifest":
                    if (++i >= args.Length) throw new ArgumentException("--manifest değer bekliyor.");
                    manifest = args[i];
                    break;
                case "--confirm":
                    if (++i >= args.Length) throw new ArgumentException("--confirm değer bekliyor.");
                    confirm = args[i];
                    break;
                case "--target-gib":
                    targetGiB = ParseBoundedInt(args, ref i, "--target-gib", 1, 1000);
                    break;
                default:
                    throw new ArgumentException($"Bilinmeyen argüman: {args[i]}");
            }
        }
        return new CliOptions
        {
            MinAgeDays = days,
            MinSizeMiB = minSizeMiB,
            DuplicateMinMiB = duplicateMinMiB,
            Top = top,
            Yes = yes,
            ReportPath = report,
            QuarantinePath = quarantine
            ,ManifestPath = manifest
            ,Confirm = confirm
            ,TargetGiB = targetGiB
        };
    }

    private static int ParseBoundedInt(string[] args, ref int i, string name, int min, int max)
    {
        if (++i >= args.Length || !int.TryParse(args[i], out var value) || value < min || value > max)
            throw new ArgumentException($"{name} {min}..{max} olmalı.");
        return value;
    }
}

internal sealed record ApprovedRoot(string Path, string Category, int MinimumAgeDays);

internal static class SafetyPolicy
{
    public static ApprovedRoot[] GetApprovedCleanupRoots()
    {
        var roots = new List<ApprovedRoot>();

        // Never trust TEMP/TMP environment variables as cleanup authorities.
        // Only canonical Windows known-folder locations are admitted below.
        var local = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
        AddIfDirectory(roots, Path.Combine(local, "Temp"), "TEMP", 2);
        AddIfDirectory(roots, Path.Combine(local, "CrashDumps"), "CRASH_DUMP", 2);
        AddIfDirectory(roots, Path.Combine(local, "D3DSCache"), "DIRECTX_SHADER_CACHE", 3);
        AddIfDirectory(roots, Path.Combine(local, "NVIDIA", "DXCache"), "NVIDIA_SHADER_CACHE", 3);
        AddIfDirectory(roots, Path.Combine(local, "NVIDIA", "GLCache"), "NVIDIA_SHADER_CACHE", 3);
        AddIfDirectory(roots, Path.Combine(local, "NVIDIA", "ComputeCache"), "NVIDIA_SHADER_CACHE", 3);
        AddIfDirectory(roots, Path.Combine(local, "NVIDIA", "NV_Cache"), "NVIDIA_SHADER_CACHE", 3);
        AddIfDirectory(roots, Path.Combine(local, "AMD", "DxCache"), "AMD_SHADER_CACHE", 3);
        AddIfDirectory(roots, Path.Combine(local, "AMD", "GLCache"), "AMD_SHADER_CACHE", 3);
        AddIfDirectory(roots, Path.Combine(local, "AMD", "VkCache"), "AMD_SHADER_CACHE", 3);

        var windows = Environment.GetFolderPath(Environment.SpecialFolder.Windows);
        AddIfDirectory(roots, Path.Combine(windows, "Temp"), "WINDOWS_TEMP", 7);

        var programData = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData);
        AddIfDirectory(roots, Path.Combine(programData, "Microsoft", "Windows", "WER", "ReportArchive"), "WINDOWS_ERROR_REPORT", 14);
        AddIfDirectory(roots, Path.Combine(programData, "Microsoft", "Windows", "WER", "ReportQueue"), "WINDOWS_ERROR_REPORT", 14);
        AddIfDirectory(roots, Path.Combine(programData, "Microsoft", "Windows", "WER", "Temp"), "WINDOWS_ERROR_REPORT", 7);

        AddChromiumCacheRoots(roots, Path.Combine(local, "Google", "Chrome", "User Data"), "CHROME_CACHE");
        AddChromiumCacheRoots(roots, Path.Combine(local, "Microsoft", "Edge", "User Data"), "EDGE_CACHE");
        AddChromiumCacheRoots(roots, Path.Combine(local, "BraveSoftware", "Brave-Browser", "User Data"), "BRAVE_CACHE");
        AddChromiumCacheRoots(roots, Path.Combine(local, "Chromium", "User Data"), "CHROMIUM_CACHE");
        AddFirefoxCacheRoots(roots, Path.Combine(local, "Mozilla", "Firefox", "Profiles"));

        // Rebuildable Electron application caches. These are only eligible when their owning
        // application process is confirmed closed by AutoCarePreflight.
        var roaming = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
        AddElectronCacheRoots(roots, Path.Combine(roaming, "Code"), "VSCODE_CACHE");
        AddElectronCacheRoots(roots, Path.Combine(roaming, "Cursor"), "CURSOR_CACHE");
        AddElectronCacheRoots(roots, Path.Combine(roaming, "discord"), "DISCORD_CACHE");
        AddElectronCacheRoots(roots, Path.Combine(roaming, "Slack"), "SLACK_CACHE");

        return roots
            .GroupBy(r => Normalize(r.Path), StringComparer.OrdinalIgnoreCase)
            .Select(g => g.First() with { Path = Normalize(g.First().Path) })
            .ToArray();
    }

    public static string[] GetDeepAnalysisRoots()
    {
        var roots = new List<string>();
        AddSpecialFolder(roots, Environment.SpecialFolder.DesktopDirectory);
        AddSpecialFolder(roots, Environment.SpecialFolder.MyDocuments);
        AddSpecialFolder(roots, Environment.SpecialFolder.MyPictures);
        AddSpecialFolder(roots, Environment.SpecialFolder.MyMusic);
        AddSpecialFolder(roots, Environment.SpecialFolder.MyVideos);

        var profile = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
        AddPathIfDirectory(roots, Path.Combine(profile, "Downloads"));

        // AppData\Local is often one of the largest user-owned trees. It is read-only analysis only;
        // findings here are never auto-deleted merely because they are large/duplicate/compressible.
        AddSpecialFolder(roots, Environment.SpecialFolder.LocalApplicationData);

        return roots.Select(Normalize).Distinct(StringComparer.OrdinalIgnoreCase).ToArray();
    }

    private static void AddSpecialFolder(List<string> roots, Environment.SpecialFolder folder)
    {
        var path = Environment.GetFolderPath(folder);
        AddPathIfDirectory(roots, path);
    }

    private static void AddPathIfDirectory(List<string> roots, string path)
    {
        if (!string.IsNullOrWhiteSpace(path) && Directory.Exists(path)) roots.Add(path);
    }

    private static void AddIfDirectory(List<ApprovedRoot> roots, string path, string category, int minAge)
    {
        if (!string.IsNullOrWhiteSpace(path) && Directory.Exists(path) && IsOnSystemVolume(path))
            roots.Add(new ApprovedRoot(path, category, minAge));
    }

    public static bool IsOnSystemVolume(string path)
    {
        try
        {
            if (!OperatingSystem.IsWindows()) return false;
            var windows = Environment.GetFolderPath(Environment.SpecialFolder.Windows);
            return TryGetVolumeIdentity(windows, out var systemVolume)
                && TryGetVolumeIdentity(path, out var candidateVolume)
                && string.Equals(systemVolume, candidateVolume, StringComparison.OrdinalIgnoreCase);
        }
        catch { return false; }
    }

    public static bool TryAreSameVolume(string left, string right, out bool same)
    {
        same = false;
        try
        {
            if (!OperatingSystem.IsWindows()) return false;
            if (!TryGetVolumeIdentity(left, out var a) || !TryGetVolumeIdentity(right, out var b)) return false;
            same = string.Equals(a, b, StringComparison.OrdinalIgnoreCase);
            return true;
        }
        catch { return false; }
    }

    internal static bool TryGetVolumeIdentityForTests(string path, out string identity)
        => TryGetVolumeIdentity(path, out identity);

    private static bool TryGetVolumeIdentity(string path, out string identity)
    {
        identity = string.Empty;
        if (string.IsNullOrWhiteSpace(path) || !OperatingSystem.IsWindows()) return false;
        try
        {
            var full = Path.GetFullPath(path);
            var probe = Directory.Exists(full) || File.Exists(full)
                ? full
                : (Path.GetDirectoryName(full) ?? full);
            var volumePath = new StringBuilder(1024);
            if (!GetVolumePathNameW(probe, volumePath, volumePath.Capacity)) return false;
            var volumeName = new StringBuilder(1024);
            if (!GetVolumeNameForVolumeMountPointW(volumePath.ToString(), volumeName, volumeName.Capacity)) return false;
            var value = volumeName.ToString().Trim();
            if (!value.StartsWith("\\\\?\\Volume{", StringComparison.OrdinalIgnoreCase) || !value.EndsWith("}\\", StringComparison.Ordinal)) return false;
            identity = value;
            return true;
        }
        catch { return false; }
    }

    [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool GetVolumePathNameW(string lpszFileName, StringBuilder lpszVolumePathName, int cchBufferLength);

    [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool GetVolumeNameForVolumeMountPointW(string lpszVolumeMountPoint, StringBuilder lpszVolumeName, int cchBufferLength);

    private static void AddChromiumCacheRoots(List<ApprovedRoot> roots, string userData, string category)
    {
        if (!Directory.Exists(userData) || IsReparsePoint(userData)) return;
        AddIfDirectory(roots, Path.Combine(userData, "ShaderCache"), category, 3);
        AddIfDirectory(roots, Path.Combine(userData, "GraphiteDawnCache"), category, 3);
        IEnumerable<string> profiles;
        try { profiles = Directory.EnumerateDirectories(userData); }
        catch { return; }

        foreach (var profile in profiles)
        {
            if (IsReparsePoint(profile)) continue;
            AddIfDirectory(roots, Path.Combine(profile, "Cache"), category, 3);
            AddIfDirectory(roots, Path.Combine(profile, "Code Cache"), category, 3);
            AddIfDirectory(roots, Path.Combine(profile, "GPUCache"), category, 3);
            AddIfDirectory(roots, Path.Combine(profile, "DawnCache"), category, 3);
            AddIfDirectory(roots, Path.Combine(profile, "GrShaderCache"), category, 3);
        }
    }

    private static void AddElectronCacheRoots(List<ApprovedRoot> roots, string appRoot, string category)
    {
        if (!Directory.Exists(appRoot) || IsReparsePoint(appRoot)) return;
        foreach (var relative in new[] { "Cache", "Code Cache", "GPUCache", "DawnCache", "CachedData" })
            AddIfDirectory(roots, Path.Combine(appRoot, relative), category, 3);
    }

    private static void AddFirefoxCacheRoots(List<ApprovedRoot> roots, string profilesRoot)
    {
        if (!Directory.Exists(profilesRoot) || IsReparsePoint(profilesRoot)) return;
        IEnumerable<string> profiles;
        try { profiles = Directory.EnumerateDirectories(profilesRoot); }
        catch { return; }
        foreach (var profile in profiles)
        {
            if (IsReparsePoint(profile)) continue;
            AddIfDirectory(roots, Path.Combine(profile, "cache2"), "FIREFOX_CACHE", 3);
            AddIfDirectory(roots, Path.Combine(profile, "startupCache"), "FIREFOX_CACHE", 3);
        }
    }

    public static string Normalize(string path)
    {
        var full = Path.GetFullPath(path).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
        return full;
    }

    public static bool IsUnderRoot(string file, string root)
    {
        var f = Normalize(file);
        var r = Normalize(root) + Path.DirectorySeparatorChar;
        return f.StartsWith(r, StringComparison.OrdinalIgnoreCase);
    }

    public static bool IsOldEnough(string file, int days)
        => File.GetLastWriteTimeUtc(file) <= DateTime.UtcNow.AddDays(-days);

    public static bool IsApprovedFile(string file, IEnumerable<ApprovedRoot> roots)
        => roots.Any(r => IsUnderRoot(file, r.Path));

    public static bool IsReparsePoint(string path)
    {
        try { return (File.GetAttributes(path) & FileAttributes.ReparsePoint) != 0; }
        catch { return true; }
    }

    public static bool IsForbiddenCleanupRoot(string path)
    {
        var full = Normalize(path);
        var windows = Environment.GetFolderPath(Environment.SpecialFolder.Windows);
        var programFiles = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles);
        var programFilesX86 = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86);

        if (!string.IsNullOrWhiteSpace(windows))
        {
            var win = Normalize(windows);
            if (full.Equals(win, StringComparison.OrdinalIgnoreCase)) return true;
            foreach (var forbidden in new[] { "System32", "SysWOW64", "WinSxS", "servicing", "SystemApps" })
            {
                var f = Normalize(Path.Combine(win, forbidden));
                if (full.Equals(f, StringComparison.OrdinalIgnoreCase) || IsUnderRoot(full, f)) return true;
            }
        }
        if (!string.IsNullOrWhiteSpace(programFiles))
        {
            var p = Normalize(programFiles);
            if (full.Equals(p, StringComparison.OrdinalIgnoreCase) || IsUnderRoot(full, p)) return true;
        }
        if (!string.IsNullOrWhiteSpace(programFilesX86))
        {
            var p = Normalize(programFilesX86);
            if (full.Equals(p, StringComparison.OrdinalIgnoreCase) || IsUnderRoot(full, p)) return true;
        }
        return false;
    }

    public static bool HasUnsafePathSyntax(string path)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(path)) return true;
            if (path.StartsWith("\\\\?\\", StringComparison.Ordinal) || path.StartsWith("\\\\.\\", StringComparison.Ordinal) || path.StartsWith("\\\\", StringComparison.Ordinal))
                return true;
            var full = Path.GetFullPath(path);
            var root = Path.GetPathRoot(full) ?? "";
            var rest = full.Length >= root.Length ? full[root.Length..] : full;
            return rest.Contains(':'); // NTFS alternate-data-stream syntax after drive prefix.
        }
        catch { return true; }
    }

    public static bool IsRuntimeProtectedPath(string path)
    {
        try
        {
            var full = Normalize(path);
            var baseDir = Normalize(AppContext.BaseDirectory);
            var stateDir = Normalize(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "DiskGuardSpace"));
            return full.Equals(baseDir, StringComparison.OrdinalIgnoreCase) || IsUnderRoot(full, baseDir)
                || full.Equals(stateDir, StringComparison.OrdinalIgnoreCase) || IsUnderRoot(full, stateDir);
        }
        catch { return true; }
    }

    public static bool IsCanonicalApprovedRoot(ApprovedRoot root)
    {
        try
        {
            var full = Normalize(root.Path);
            var local = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            var windows = Environment.GetFolderPath(Environment.SpecialFolder.Windows);
            var programData = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData);

            bool UnderOrEqual(string path, string parent)
            {
                if (string.IsNullOrWhiteSpace(parent)) return false;
                var p = Normalize(parent);
                return path.Equals(p, StringComparison.OrdinalIgnoreCase) || IsUnderRoot(path, p);
            }

            return root.Category switch
            {
                "TEMP" or "CRASH_DUMP" or "DIRECTX_SHADER_CACHE" or "NVIDIA_SHADER_CACHE" or "AMD_SHADER_CACHE"
                    or "CHROME_CACHE" or "EDGE_CACHE" or "BRAVE_CACHE" or "CHROMIUM_CACHE" or "FIREFOX_CACHE"
                    => UnderOrEqual(full, local),
                "VSCODE_CACHE" or "CURSOR_CACHE" or "DISCORD_CACHE" or "SLACK_CACHE"
                    => UnderOrEqual(full, Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData)),
                "WINDOWS_TEMP" => full.Equals(Normalize(Path.Combine(windows, "Temp")), StringComparison.OrdinalIgnoreCase),
                "WINDOWS_ERROR_REPORT" => UnderOrEqual(full, Path.Combine(programData, "Microsoft", "Windows", "WER")),
                "SELF_TEST" => true,
                _ => false
            };
        }
        catch { return false; }
    }

    public static bool IsSensitivePath(string path)
    {
        var full = Normalize(path);
        var windows = Environment.GetFolderPath(Environment.SpecialFolder.Windows);
        var programFiles = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles);
        var programFilesX86 = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86);
        if (!string.IsNullOrWhiteSpace(windows) && (full.Equals(Normalize(windows), StringComparison.OrdinalIgnoreCase) || IsUnderRoot(full, windows))) return true;
        if (!string.IsNullOrWhiteSpace(programFiles) && (full.Equals(Normalize(programFiles), StringComparison.OrdinalIgnoreCase) || IsUnderRoot(full, programFiles))) return true;
        if (!string.IsNullOrWhiteSpace(programFilesX86) && (full.Equals(Normalize(programFilesX86), StringComparison.OrdinalIgnoreCase) || IsUnderRoot(full, programFilesX86))) return true;
        return false;
    }
}

internal record Candidate(string Path, long SizeBytes, DateTime LastWriteUtc, string Category, string Risk, string ApprovedRoot, long AllocatedBytes = -1);

internal sealed class ScanResult
{
    public List<Candidate> Candidates { get; } = new();
    public int FailClosedViolations { get; set; }
    public int ReadErrors { get; set; }
    public long CandidateBytes => Candidates.Sum(c => c.SizeBytes);
    public long CandidateAllocatedBytes => Candidates.Sum(c => c.AllocatedBytes >= 0 ? c.AllocatedBytes : c.SizeBytes);
}

internal static class Scanner
{
    public static ScanResult ScanApprovedRoots(IEnumerable<ApprovedRoot> roots, int userMinAgeDays)
    {
        var result = new ScanResult();
        foreach (var root in roots)
        {
            if (!Directory.Exists(root.Path)) continue;
            var effectiveMinAge = Math.Max(userMinAgeDays, root.MinimumAgeDays);
            Walk(root.Path, root, effectiveMinAge, result);
        }
        return result;
    }

    private static void Walk(string current, ApprovedRoot approvedRoot, int minAgeDays, ScanResult result)
    {
        if (SafetyPolicy.IsReparsePoint(current)) return;

        IEnumerable<string> files;
        try { files = Directory.EnumerateFiles(current); }
        catch { result.ReadErrors++; return; }

        foreach (var file in files)
        {
            try
            {
                if (SafetyPolicy.IsReparsePoint(file)) continue;
                if (SafetyPolicy.HasUnsafePathSyntax(file)) { result.FailClosedViolations++; continue; }
                if (SafetyPolicy.IsRuntimeProtectedPath(file)) continue;
                var attrs = File.GetAttributes(file);
                if ((attrs & (FileAttributes.ReadOnly | FileAttributes.System)) != 0) continue;
                if (!SafetyPolicy.IsUnderRoot(file, approvedRoot.Path)) { result.FailClosedViolations++; continue; }
                if (!SafetyPolicy.IsOldEnough(file, minAgeDays)) continue;

                var fi = new FileInfo(file);
                if (fi.Length <= 0) continue;
                var allocated = NtfsAllocationProbe.GetAllocatedBytesOrLogical(fi.FullName, fi.Length, out _);
                result.Candidates.Add(new Candidate(fi.FullName, fi.Length, fi.LastWriteTimeUtc, approvedRoot.Category, "SAFE", approvedRoot.Path, allocated));
            }
            catch { result.ReadErrors++; }
        }

        IEnumerable<string> dirs;
        try { dirs = Directory.EnumerateDirectories(current); }
        catch { result.ReadErrors++; return; }

        foreach (var dir in dirs)
        {
            try
            {
                if (SafetyPolicy.IsReparsePoint(dir)) continue;
                if (!SafetyPolicy.IsUnderRoot(Path.Combine(dir, "__probe__"), approvedRoot.Path)) { result.FailClosedViolations++; continue; }
                Walk(dir, approvedRoot, minAgeDays, result);
            }
            catch { result.ReadErrors++; }
        }
    }
}

internal sealed class ExecutionResult
{
    public int Succeeded { get; set; }
    public int Failed { get; set; }
    public int Blocked { get; set; }
    public long SourceBytesRemoved { get; set; }
    public long SourceAllocatedBytesRemoved { get; set; }
    public List<ActionEvidence> Actions { get; } = new();
}

internal record ActionEvidence(string Source, string? Destination, long SizeBytes, string Sha256, string Action, string Status, string? Error, long AllocatedBytes = -1);

internal static class Cleaner
{
    public static ExecutionResult ExecuteSafeCandidates(IEnumerable<Candidate> candidates, IEnumerable<ApprovedRoot> approvedRoots, string? quarantinePath)
    {
        var result = new ExecutionResult();
        var roots = approvedRoots.Select(r => r with { Path = SafetyPolicy.Normalize(r.Path) }).ToArray();

        string? quarantineRoot = null;
        if (!string.IsNullOrWhiteSpace(quarantinePath))
        {
            quarantineRoot = Path.GetFullPath(quarantinePath);
            Directory.CreateDirectory(quarantineRoot);
            if (SafetyPolicy.IsReparsePoint(quarantineRoot))
                throw new IOException("FAIL-CLOSED: quarantine root reparse point olamaz.");
        }

        var deletionBudgetBytes = CleanupBlastRadiusPolicy.GetSystemRunBudgetBytes();
        var categoryBudgetBytes = CleanupBlastRadiusPolicy.ComputeCategoryBudgetBytes(deletionBudgetBytes);
        var categoryAllocatedRemoved = new Dictionary<string, long>(StringComparer.OrdinalIgnoreCase);
        var categoryFilesRemoved = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
        var orderedCandidates = candidates
            .OrderByDescending(c => c.AllocatedBytes >= 0 ? c.AllocatedBytes : c.SizeBytes)
            .ThenBy(c => c.Path, StringComparer.OrdinalIgnoreCase)
            .ToArray();

        foreach (var c in orderedCandidates)
        {
            try
            {
                if (result.Succeeded >= CleanupBlastRadiusPolicy.MaxFilesPerRun)
                {
                    Block(result, c, "Per-run automatic cleanup file-count blast-radius budget reached");
                    continue;
                }
                categoryFilesRemoved.TryGetValue(c.Category, out var categoryFileCount);
                if (categoryFileCount >= CleanupBlastRadiusPolicy.MaxFilesPerCategory)
                {
                    Block(result, c, $"Per-category automatic cleanup file-count blast-radius budget reached for {c.Category}");
                    continue;
                }
                if (!File.Exists(c.Path) || c.Risk != "SAFE" || !SafetyPolicy.IsApprovedFile(c.Path, roots) || SafetyPolicy.IsReparsePoint(c.Path) || SafetyPolicy.HasUnsafePathSyntax(c.Path) || SafetyPolicy.IsRuntimeProtectedPath(c.Path))
                {
                    Block(result, c, "Path no longer satisfies safety policy");
                    continue;
                }

                var owningRoot = roots.FirstOrDefault(r => SafetyPolicy.IsUnderRoot(c.Path, r.Path));
                if (owningRoot is null || !string.Equals(SafetyPolicy.Normalize(owningRoot.Path), SafetyPolicy.Normalize(c.ApprovedRoot), StringComparison.OrdinalIgnoreCase))
                {
                    Block(result, c, "Approved root identity changed");
                    continue;
                }
                if (!string.Equals(owningRoot.Category, c.Category, StringComparison.OrdinalIgnoreCase))
                {
                    Block(result, c, "Candidate category does not match owning approved root");
                    continue;
                }
                if (!SafetyPolicy.IsOldEnough(c.Path, owningRoot.MinimumAgeDays))
                {
                    Block(result, c, "Candidate no longer satisfies approved-root age policy");
                    continue;
                }
                if (!RuntimeFeatureGuard.IsCategorySafeForWrite(c.Category, out var runtimeGuardDetail))
                {
                    Block(result, c, runtimeGuardDetail);
                    continue;
                }

                var cleanupAttrs = File.GetAttributes(c.Path);
                if ((cleanupAttrs & (FileAttributes.ReadOnly | FileAttributes.System)) != 0)
                {
                    Block(result, c, "ReadOnly/System attributes are not eligible for automatic cleanup");
                    continue;
                }

                var fi = new FileInfo(c.Path);
                if (fi.Length != c.SizeBytes || fi.LastWriteTimeUtc != c.LastWriteUtc)
                {
                    Block(result, c, "File changed since scan");
                    continue;
                }

                // v0.5: verification and deletion are bound to the same Windows kernel file handle.
                // The handle denies write/delete sharing, rejects hard links and risky attributes,
                // hashes the exact opened object, then marks that same object for deletion.
                using var locked = VerifiedWindowsFile.OpenAndVerify(c);
                var hash = locked.Sha256;
                categoryAllocatedRemoved.TryGetValue(c.Category, out var categoryBytes);
                if (locked.AllocationBytes < 0 || categoryBytes > categoryBudgetBytes - locked.AllocationBytes)
                {
                    Block(result, c, $"Per-category automatic cleanup physical-space blast-radius budget reached for {c.Category} ({categoryBudgetBytes} bytes)");
                    continue;
                }
                if (result.SourceAllocatedBytesRemoved > deletionBudgetBytes - locked.AllocationBytes)
                {
                    Block(result, c, $"Per-run automatic cleanup physical-space blast-radius budget reached ({deletionBudgetBytes} bytes)");
                    continue;
                }

                if (quarantineRoot is null)
                {
                    locked.MarkDelete();
                    result.SourceBytesRemoved += c.SizeBytes;
                    result.SourceAllocatedBytesRemoved += locked.AllocationBytes;
                    categoryAllocatedRemoved[c.Category] = categoryBytes + locked.AllocationBytes;
                    categoryFilesRemoved[c.Category] = categoryFileCount + 1;
                    result.Succeeded++;
                    result.Actions.Add(new ActionEvidence(c.Path, null, c.SizeBytes, hash, "DELETE_BY_VERIFIED_HANDLE", "VERIFIED", null, locked.AllocationBytes));
                }
                else
                {
                    var destRoot = Path.GetPathRoot(quarantineRoot) ?? throw new IOException("Quarantine volume unresolved");
                    if (!SafetyPolicy.TryAreSameVolume(c.Path, quarantineRoot, out var sameVolume))
                        throw new IOException("FAIL-CLOSED: source/quarantine volume identity could not be proven");
                    if (sameVolume)
                        throw new IOException("FAIL-CLOSED: quarantine must be on a different Windows volume identity to recover source disk space");

                    var destDrive = new DriveInfo(destRoot);
                    if (!destDrive.IsReady) throw new IOException("FAIL-CLOSED: quarantine destination volume is not ready");
                    var reserve = Math.Max(256L * 1024 * 1024, c.SizeBytes / 50); // 256 MiB or 2% reserve
                    if (destDrive.AvailableFreeSpace < c.SizeBytes + reserve)
                        throw new IOException("FAIL-CLOSED: quarantine destination lacks required free-space reserve");

                    var dest = BuildUniqueDestination(quarantineRoot, c.Path);
                    Directory.CreateDirectory(Path.GetDirectoryName(dest)!);
                    locked.Stream.Position = 0;
                    using (var output = new FileStream(dest, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                    {
                        locked.Stream.CopyTo(output);
                        output.Flush(flushToDisk: true);
                    }
                    var destHash = Hashing.Sha256(dest);
                    if (!hash.Equals(destHash, StringComparison.OrdinalIgnoreCase))
                    {
                        try { File.Delete(dest); } catch { }
                        throw new IOException("Quarantine hash verification failed");
                    }
                    locked.MarkDelete();
                    result.SourceBytesRemoved += c.SizeBytes;
                    result.SourceAllocatedBytesRemoved += locked.AllocationBytes;
                    categoryAllocatedRemoved[c.Category] = categoryBytes + locked.AllocationBytes;
                    categoryFilesRemoved[c.Category] = categoryFileCount + 1;
                    result.Succeeded++;
                    result.Actions.Add(new ActionEvidence(c.Path, dest, c.SizeBytes, hash, "QUARANTINE_OTHER_VOLUME_VERIFIED_HANDLE", "VERIFIED", null, locked.AllocationBytes));
                }
            }
            catch (SafetyBlockException ex)
            {
                Block(result, c, ex.Message);
            }
            catch (Exception ex)
            {
                result.Failed++;
                result.Actions.Add(new ActionEvidence(c.Path, null, c.SizeBytes, "", "NONE", "FAILED", ex.Message));
            }
        }
        return result;
    }

    private static void Block(ExecutionResult result, Candidate c, string reason)
    {
        result.Blocked++;
        result.Actions.Add(new ActionEvidence(c.Path, null, c.SizeBytes, "", "BLOCK", "FAIL_CLOSED", reason));
    }

    private static string BuildUniqueDestination(string quarantineRoot, string source)
    {
        var relative = source.Replace(':', '_').TrimStart(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
        var dest = Path.Combine(quarantineRoot, relative);
        if (!File.Exists(dest)) return dest;
        return dest + "." + Guid.NewGuid().ToString("N");
    }
}

internal sealed record FileFinding(string Path, long SizeBytes, DateTime LastWriteUtc, string Category, string Recommendation, string Sha256 = "", long AllocatedBytes = -1);
internal sealed record DuplicateGroup(string Sha256, long FileSizeBytes, List<string> Files, long PotentialSavingsBytes, List<long>? FileAllocatedBytes = null, long PhysicalPotentialSavingsBytes = -1);
internal sealed record CompressionOpportunity(string Path, long SizeBytes, long SampleBytes, long SampleCompressedBytes, double EstimatedRatio, long EstimatedSavingsBytes, long AllocatedBytes = -1);
internal sealed record DirectoryHotspot(string Path, long TotalBytes, long FileCount, string Category);

internal sealed class DeepAnalysisResult
{
    public List<FileFinding> LargeFiles { get; } = new();
    public List<FileFinding> OldInstallers { get; } = new();
    public List<DuplicateGroup> DuplicateGroups { get; } = new();
    public List<CompressionOpportunity> CompressionOpportunities { get; } = new();
    public List<DirectoryHotspot> DirectoryHotspots { get; } = new();
    public int FailClosedViolations { get; set; }
    public int ReadErrors { get; set; }
    public long InventoryFilesScanned { get; set; }
    public long InventoryBytesScanned { get; set; }
    public long InventoryAllocatedBytesScanned { get; set; }
    public int AllocationMeasurementErrors { get; set; }
    public bool AnalysisTruncated { get; set; }
    public string AnalysisTruncationReason { get; set; } = "";
}

internal static class OpportunityAnalyzer
{
    private static readonly HashSet<string> InstallerArchiveExtensions = new(StringComparer.OrdinalIgnoreCase)
    {
        ".exe", ".msi", ".msix", ".msixbundle", ".appx", ".appxbundle", ".iso", ".img", ".zip", ".7z", ".rar", ".tar", ".gz", ".bz2", ".xz"
    };

    public static DeepAnalysisResult Analyze(CliOptions options)
    {
        var result = new DeepAnalysisResult();
        var roots = SafetyPolicy.GetDeepAnalysisRoots();
        var inventory = InventoryFiles(roots, result);
        result.DirectoryHotspots.AddRange(BuildDirectoryHotspots(inventory, roots, Math.Min(options.Top, 100)));
        long minLarge = options.MinSizeMiB * 1024L * 1024L;
        var cutoff = DateTime.UtcNow.AddDays(-options.MinAgeDays);

        result.LargeFiles.AddRange(inventory
            .Where(f => f.SizeBytes >= minLarge)
            .OrderByDescending(f => f.SizeBytes)
            .Take(options.Top)
            .Select(f => new FileFinding(f.Path, f.SizeBytes, f.LastWriteUtc, "LARGE_FILE", "REVIEW_ONLY", "", f.AllocatedBytes)));

        result.OldInstallers.AddRange(inventory
            .Where(f => f.LastWriteUtc <= cutoff && InstallerArchiveExtensions.Contains(Path.GetExtension(f.Path)))
            .OrderByDescending(f => f.SizeBytes)
            .Take(options.Top)
            .Select(f => new FileFinding(f.Path, f.SizeBytes, f.LastWriteUtc, "OLD_INSTALLER_OR_ARCHIVE", "REVIEW_ONLY", "", f.AllocatedBytes)));

        var duplicateGroups = DuplicateFinder.FindFromInventory(inventory, options.DuplicateMinMiB, options.Top, out var duplicateViolations, out var duplicateBudgetTruncated);
        result.ReadErrors += duplicateViolations;
        if (duplicateBudgetTruncated)
        {
            result.AnalysisTruncated = true;
            result.AnalysisTruncationReason = AppendReason(result.AnalysisTruncationReason, "duplicate full-hash work budget reached");
        }
        result.DuplicateGroups.AddRange(duplicateGroups);

        var compressionCandidates = inventory
            .Where(f => f.SizeBytes >= 10L * 1024 * 1024)
            .Where(f => CompressionEstimator.IsWorthSampling(f.Path))
            .OrderByDescending(f => f.SizeBytes)
            .Take(Math.Min(options.Top * 3, 500))
            .ToList();

        foreach (var f in compressionCandidates)
        {
            try
            {
                if (SafetyPolicy.IsReparsePoint(f.Path)) continue;
                var estimate = CompressionEstimator.Estimate(f.Path, 1024 * 1024);
                var physicalSavings = Math.Min(estimate.EstimatedSavingsBytes, Math.Max(0, f.AllocatedBytes));
                if (physicalSavings >= 5L * 1024 * 1024 && estimate.EstimatedRatio <= 0.90)
                    result.CompressionOpportunities.Add(new CompressionOpportunity(f.Path, f.SizeBytes, estimate.SampleBytes, estimate.SampleCompressedBytes, estimate.EstimatedRatio, physicalSavings, f.AllocatedBytes));
            }
            catch { result.ReadErrors++; }
        }
        result.CompressionOpportunities.Sort((a, b) => b.EstimatedSavingsBytes.CompareTo(a.EstimatedSavingsBytes));
        if (result.CompressionOpportunities.Count > options.Top)
            result.CompressionOpportunities.RemoveRange(options.Top, result.CompressionOpportunities.Count - options.Top);

        return result;
    }

    private static string AppendReason(string current, string next)
        => string.IsNullOrWhiteSpace(current) ? next : current + "; " + next;

    private static List<DirectoryHotspot> BuildDirectoryHotspots(IEnumerable<InventoryEntry> inventory, string[] roots, int top)
    {
        var local = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
        var map = new Dictionary<string, (long Bytes, long Files)>(StringComparer.OrdinalIgnoreCase);

        foreach (var entry in inventory)
        {
            var root = roots
                .Where(r => SafetyPolicy.IsUnderRoot(entry.Path, r))
                .OrderByDescending(r => r.Length)
                .FirstOrDefault();
            if (string.IsNullOrWhiteSpace(root)) continue;

            string rel;
            try { rel = Path.GetRelativePath(root, entry.Path); }
            catch { continue; }
            var parts = rel.Split(new[] { Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar }, StringSplitOptions.RemoveEmptyEntries);
            if (parts.Length <= 1) continue;

            int depth = !string.IsNullOrWhiteSpace(local) && SafetyPolicy.Normalize(root).Equals(SafetyPolicy.Normalize(local), StringComparison.OrdinalIgnoreCase) ? 2 : 1;
            depth = Math.Min(depth, parts.Length - 1);
            if (depth <= 0) continue;
            var path = root;
            for (int i = 0; i < depth; i++) path = Path.Combine(path, parts[i]);

            var current = map.GetValueOrDefault(path);
            map[path] = (current.Bytes + Math.Max(0, entry.AllocatedBytes), current.Files + 1);
        }

        return map
            .OrderByDescending(kv => kv.Value.Bytes)
            .Take(Math.Max(1, top))
            .Select(kv => new DirectoryHotspot(kv.Key, kv.Value.Bytes, kv.Value.Files, "READ_ONLY_HOTSPOT"))
            .ToList();
    }

    private static List<InventoryEntry> InventoryFiles(IEnumerable<string> roots, DeepAnalysisResult result)
    {
        const long maxFiles = 300_000;
        var deadline = Stopwatch.GetTimestamp() + (long)(Stopwatch.Frequency * 120.0);
        var inventory = new List<InventoryEntry>();
        foreach (var root in roots)
        {
            if (BudgetExpired()) break;
            if (!Directory.Exists(root) || SafetyPolicy.IsSensitivePath(root)) continue;
            Walk(root, root, inventory, result, maxFiles, deadline);
        }
        result.InventoryFilesScanned = inventory.Count;
        result.InventoryBytesScanned = inventory.Sum(x => x.SizeBytes);
        result.InventoryAllocatedBytesScanned = inventory.Sum(x => x.AllocatedBytes);
        result.AllocationMeasurementErrors = inventory.Count(x => !x.AllocationMeasured);
        return inventory;

        bool BudgetExpired()
        {
            if (inventory.Count >= maxFiles)
            {
                result.AnalysisTruncated = true;
                result.AnalysisTruncationReason = $"file budget reached ({maxFiles:N0})";
                return true;
            }
            if (Stopwatch.GetTimestamp() >= deadline)
            {
                result.AnalysisTruncated = true;
                result.AnalysisTruncationReason = "time budget reached (120 seconds)";
                return true;
            }
            return false;
        }
    }

    private static void Walk(string current, string root, List<InventoryEntry> inventory, DeepAnalysisResult result, long maxFiles, long deadline)
    {
        if (inventory.Count >= maxFiles || Stopwatch.GetTimestamp() >= deadline)
        {
            result.AnalysisTruncated = true;
            if (string.IsNullOrWhiteSpace(result.AnalysisTruncationReason))
                result.AnalysisTruncationReason = inventory.Count >= maxFiles ? $"file budget reached ({maxFiles:N0})" : "time budget reached (120 seconds)";
            return;
        }
        if (SafetyPolicy.IsReparsePoint(current)) return;

        IEnumerable<string> files;
        try { files = Directory.EnumerateFiles(current); }
        catch { result.ReadErrors++; return; }

        foreach (var file in files)
        {
            if (inventory.Count >= maxFiles || Stopwatch.GetTimestamp() >= deadline)
            {
                result.AnalysisTruncated = true;
                if (string.IsNullOrWhiteSpace(result.AnalysisTruncationReason))
                    result.AnalysisTruncationReason = inventory.Count >= maxFiles ? $"file budget reached ({maxFiles:N0})" : "time budget reached (120 seconds)";
                return;
            }
            try
            {
                if (SafetyPolicy.IsReparsePoint(file)) continue;
                if (SafetyPolicy.HasUnsafePathSyntax(file)) { result.FailClosedViolations++; continue; }
                if (SafetyPolicy.IsRuntimeProtectedPath(file)) continue;
                if (!SafetyPolicy.IsUnderRoot(file, root)) { result.FailClosedViolations++; continue; }
                var fi = new FileInfo(file);
                var allocated = NtfsAllocationProbe.GetAllocatedBytesOrLogical(fi.FullName, fi.Length, out var allocationMeasured);
                inventory.Add(new InventoryEntry(fi.FullName, fi.Length, fi.LastWriteTimeUtc, allocated, allocationMeasured));
            }
            catch { result.ReadErrors++; }
        }

        IEnumerable<string> dirs;
        try { dirs = Directory.EnumerateDirectories(current); }
        catch { result.ReadErrors++; return; }
        foreach (var dir in dirs)
        {
            if (inventory.Count >= maxFiles || Stopwatch.GetTimestamp() >= deadline)
            {
                result.AnalysisTruncated = true;
                if (string.IsNullOrWhiteSpace(result.AnalysisTruncationReason))
                    result.AnalysisTruncationReason = inventory.Count >= maxFiles ? $"file budget reached ({maxFiles:N0})" : "time budget reached (120 seconds)";
                return;
            }
            try
            {
                if (SafetyPolicy.IsReparsePoint(dir)) continue;
                if (!SafetyPolicy.IsUnderRoot(Path.Combine(dir, "__probe__"), root)) { result.FailClosedViolations++; continue; }
                Walk(dir, root, inventory, result, maxFiles, deadline);
            }
            catch { result.ReadErrors++; }
        }
    }
}

internal sealed record InventoryEntry(string Path, long SizeBytes, DateTime LastWriteUtc, long AllocatedBytes = -1, bool AllocationMeasured = false);

internal static class DuplicateHashBudget
{
    public const long MaxFullHashBytes = 64L * 1024 * 1024 * 1024;
    public const int MaxFullHashFiles = 512;

    public static bool CanHash(long bytesAlreadyHashed, int filesAlreadyHashed, long nextFileBytes)
    {
        if (bytesAlreadyHashed < 0 || filesAlreadyHashed < 0 || nextFileBytes < 0) return false;
        if (filesAlreadyHashed >= MaxFullHashFiles) return false;
        if (nextFileBytes > MaxFullHashBytes) return false;
        return bytesAlreadyHashed <= MaxFullHashBytes - nextFileBytes;
    }
}

internal static class DuplicateFinder
{
    public static List<DuplicateGroup> Find(IEnumerable<string> roots, int duplicateMinMiB, int top, out int violations)
    {
        var list = new List<InventoryEntry>();
        violations = 0;
        foreach (var root in roots)
        {
            try
            {
                if (!Directory.Exists(root) || SafetyPolicy.IsReparsePoint(root)) continue;
                foreach (var file in Directory.EnumerateFiles(root, "*", SearchOption.TopDirectoryOnly))
                {
                    if (SafetyPolicy.IsReparsePoint(file)) continue;
                    var fi = new FileInfo(file);
                    var allocated = NtfsAllocationProbe.GetAllocatedBytesOrLogical(fi.FullName, fi.Length, out var measured);
                    list.Add(new InventoryEntry(fi.FullName, fi.Length, fi.LastWriteTimeUtc, allocated, measured));
                }
            }
            catch { violations++; }
        }
        var result = FindFromInventory(list, duplicateMinMiB, top, out var innerViolations, out _, violations);
        violations = innerViolations;
        return result;
    }

    public static List<DuplicateGroup> FindFromInventory(IEnumerable<InventoryEntry> inventory, int duplicateMinMiB, int top, out int violations)
        => FindFromInventory(inventory, duplicateMinMiB, top, out violations, out _, 0);

    public static List<DuplicateGroup> FindFromInventory(IEnumerable<InventoryEntry> inventory, int duplicateMinMiB, int top, out int violations, out bool budgetTruncated)
        => FindFromInventory(inventory, duplicateMinMiB, top, out violations, out budgetTruncated, 0);

    private static List<DuplicateGroup> FindFromInventory(IEnumerable<InventoryEntry> inventory, int duplicateMinMiB, int top, out int violations, out bool budgetTruncated, int initialViolations)
    {
        violations = initialViolations;
        budgetTruncated = false;
        long fullHashBytes = 0;
        int fullHashFiles = 0;
        long minBytes = duplicateMinMiB * 1024L * 1024L;
        var result = new List<DuplicateGroup>();
        var sizeGroups = inventory.Where(x => x.SizeBytes >= minBytes).GroupBy(x => x.SizeBytes).Where(g => g.Count() > 1);

        foreach (var sizeGroup in sizeGroups)
        {
            if (budgetTruncated) break;
            var quickGroups = new Dictionary<string, List<InventoryEntry>>(StringComparer.OrdinalIgnoreCase);
            foreach (var entry in sizeGroup)
            {
                try
                {
                    var quick = Hashing.QuickFingerprint(entry.Path, entry.SizeBytes);
                    if (!quickGroups.TryGetValue(quick, out var list)) quickGroups[quick] = list = new List<InventoryEntry>();
                    list.Add(entry);
                }
                catch { violations++; }
            }

            foreach (var quickGroup in quickGroups.Values.Where(g => g.Count > 1))
            {
                if (budgetTruncated) break;
                var fullHashGroups = new Dictionary<string, List<InventoryEntry>>(StringComparer.OrdinalIgnoreCase);
                foreach (var entry in quickGroup)
                {
                    if (!DuplicateHashBudget.CanHash(fullHashBytes, fullHashFiles, entry.SizeBytes))
                    {
                        budgetTruncated = true;
                        break;
                    }
                    try
                    {
                        var hash = Hashing.Sha256(entry.Path);
                        fullHashBytes += Math.Max(0, entry.SizeBytes);
                        fullHashFiles++;
                        if (!fullHashGroups.TryGetValue(hash, out var list)) fullHashGroups[hash] = list = new List<InventoryEntry>();
                        list.Add(entry);
                    }
                    catch { violations++; }
                }

                foreach (var kv in fullHashGroups.Where(kv => kv.Value.Count > 1))
                {
                    var ordered = kv.Value.OrderBy(v => v.Path, StringComparer.OrdinalIgnoreCase).ToList();
                    var files = ordered.Select(v => v.Path).ToList();
                    var size = ordered[0].SizeBytes;
                    var allocations = ordered.Select(v => v.AllocatedBytes >= 0 ? v.AllocatedBytes : v.SizeBytes).ToList();
                    var physicalPotential = allocations.Count > 1 ? allocations.Sum() - allocations.Min() : 0;
                    result.Add(new DuplicateGroup(kv.Key, size, files, size * (files.Count - 1L), allocations, Math.Max(0, physicalPotential)));
                }
            }
        }

        return result.OrderByDescending(g => g.PotentialSavingsBytes).Take(top).ToList();
    }
}

internal sealed record CompressionEstimate(long SampleBytes, long SampleCompressedBytes, double EstimatedRatio, long EstimatedSavingsBytes);

internal static class CompressionEstimator
{
    private static readonly HashSet<string> SkipExtensions = new(StringComparer.OrdinalIgnoreCase)
    {
        ".zip", ".7z", ".rar", ".gz", ".bz2", ".xz", ".jpg", ".jpeg", ".png", ".gif", ".webp", ".heic",
        ".mp3", ".aac", ".m4a", ".flac", ".ogg", ".mp4", ".mkv", ".avi", ".mov", ".webm",
        ".pdf", ".docx", ".xlsx", ".pptx", ".apk", ".msix", ".msixbundle", ".appx", ".appxbundle"
    };

    public static bool IsWorthSampling(string path)
    {
        var ext = Path.GetExtension(path);
        if (SkipExtensions.Contains(ext)) return false;
        try
        {
            if (File.Exists(path))
            {
                var attrs = File.GetAttributes(path);
                if ((attrs & (FileAttributes.Compressed | FileAttributes.SparseFile | FileAttributes.Encrypted)) != 0) return false;
            }
        }
        catch { return false; }
        return true;
    }

    public static CompressionEstimate Estimate(string path, int maxSampleBytes)
    {
        var fi = new FileInfo(path);
        if (!fi.Exists || fi.Length <= 0) return new CompressionEstimate(0, 0, 1.0, 0);
        int totalTarget = (int)Math.Min(fi.Length, maxSampleBytes);
        if (totalTarget <= 0) return new CompressionEstimate(0, 0, 1.0, 0);

        using var sample = new MemoryStream(totalTarget);
        using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete);
        if (fi.Length <= totalTarget)
        {
            CopyChunk(stream, sample, 0, totalTarget);
        }
        else
        {
            // Representative first/middle/last sampling avoids optimistic estimates based only on headers.
            int first = totalTarget / 3;
            int middle = totalTarget / 3;
            int last = totalTarget - first - middle;
            CopyChunk(stream, sample, 0, first);
            CopyChunk(stream, sample, Math.Max(0, fi.Length / 2 - middle / 2), middle);
            CopyChunk(stream, sample, Math.Max(0, fi.Length - last), last);
        }

        var buffer = sample.ToArray();
        if (buffer.Length == 0) return new CompressionEstimate(0, 0, 1.0, 0);
        using var output = new MemoryStream();
        using (var gzip = new System.IO.Compression.GZipStream(output, System.IO.Compression.CompressionLevel.Fastest, leaveOpen: true))
            gzip.Write(buffer, 0, buffer.Length);
        var compressed = output.Length;
        var ratio = Math.Min(1.0, compressed / (double)buffer.Length);
        var savings = (long)Math.Max(0, fi.Length * (1.0 - ratio));
        return new CompressionEstimate(buffer.Length, compressed, ratio, savings);
    }

    private static void CopyChunk(FileStream input, MemoryStream output, long offset, int count)
    {
        if (count <= 0) return;
        input.Position = Math.Min(offset, input.Length);
        var buffer = new byte[Math.Min(64 * 1024, count)];
        int remaining = count;
        while (remaining > 0)
        {
            int n = input.Read(buffer, 0, Math.Min(buffer.Length, remaining));
            if (n <= 0) break;
            output.Write(buffer, 0, n);
            remaining -= n;
        }
    }
}

internal static class Hashing
{
    public static string Sha256(string path)
    {
        using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read);
        return Sha256(stream);
    }

    public static string Sha256(Stream stream)
    {
        if (stream.CanSeek) stream.Position = 0;
        return Convert.ToHexString(SHA256.HashData(stream));
    }

    public static string QuickFingerprint(string path, long length)
    {
        const int chunk = 64 * 1024;
        using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read);
        using var sha = SHA256.Create();
        var header = BitConverter.GetBytes(length);
        sha.TransformBlock(header, 0, header.Length, null, 0);

        var first = new byte[Math.Min(chunk, (int)Math.Min(int.MaxValue, length))];
        var readFirst = stream.Read(first, 0, first.Length);
        sha.TransformBlock(first, 0, readFirst, null, 0);

        if (length > chunk)
        {
            stream.Seek(Math.Max(0, length - chunk), SeekOrigin.Begin);
            var last = new byte[(int)Math.Min(chunk, length)];
            var readLast = stream.Read(last, 0, last.Length);
            sha.TransformBlock(last, 0, readLast, null, 0);
        }
        sha.TransformFinalBlock(Array.Empty<byte>(), 0, 0);
        return Convert.ToHexString(sha.Hash!);
    }
}

internal sealed record DiskSnapshot(string DriveRoot, long TotalBytes, long FreeBytes)
{
    public static DiskSnapshot CaptureSystemDrive()
    {
        var windows = Environment.GetFolderPath(Environment.SpecialFolder.Windows);
        var root = Path.GetPathRoot(windows) ?? throw new IOException("System drive could not be determined");
        var d = new DriveInfo(root);
        return new DiskSnapshot(root, d.TotalSize, d.AvailableFreeSpace);
    }
}

internal sealed record MaintenanceExecution(bool Succeeded, int ExitCode, string StdOut, string StdErr, string CommandLine);

internal static class WindowsMaintenance
{
    public static bool IsAdministrator()
    {
        using var identity = WindowsIdentity.GetCurrent();
        var principal = new WindowsPrincipal(identity);
        return principal.IsInRole(WindowsBuiltInRole.Administrator);
    }

    public static MaintenanceExecution RunStartComponentCleanup()
    {
        var windows = Environment.GetFolderPath(Environment.SpecialFolder.Windows);
        var dism = Path.Combine(windows, "System32", "dism.exe");
        if (!File.Exists(dism)) throw new FileNotFoundException("DISM bulunamadı.", dism);

        const string args = "/Online /Cleanup-Image /StartComponentCleanup /NoRestart";
        var psi = new ProcessStartInfo(dism, args)
        {
            UseShellExecute = false,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            CreateNoWindow = true
        };
        using var p = Process.Start(psi) ?? throw new InvalidOperationException("DISM başlatılamadı.");
        var stdoutTask = p.StandardOutput.ReadToEndAsync();
        var stderrTask = p.StandardError.ReadToEndAsync();
        if (!p.WaitForExit(45 * 60 * 1000))
        {
            try { p.Kill(entireProcessTree: true); } catch { }
            throw new TimeoutException("FAIL-CLOSED: DISM component cleanup exceeded 45 minutes.");
        }
        var stdout = stdoutTask.GetAwaiter().GetResult();
        var stderr = stderrTask.GetAwaiter().GetResult();
        return new MaintenanceExecution(p.ExitCode == 0, p.ExitCode, TrimEvidence(stdout), TrimEvidence(stderr), $"{dism} {args}");
    }

    private static string TrimEvidence(string s)
    {
        const int max = 32_000;
        if (s.Length <= max) return s;
        return s[..max] + "\n...[truncated]";
    }
}

internal sealed class EvidenceReport
{
    public string SchemaVersion { get; set; } = "2.2";
    public string Mode { get; set; } = "";
    public DateTime CreatedUtc { get; set; } = DateTime.UtcNow;
    public string MachineName { get; set; } = Environment.MachineName;
    public string DriveRoot { get; set; } = "";
    public long FreeBytesBefore { get; set; }
    public long FreeBytesAfter { get; set; }
    public long VerifiedFreeGainBytes { get; set; }
    public int CandidateCount { get; set; }
    public long CandidateBytes { get; set; }
    public long CandidateAllocatedBytes { get; set; }
    public int SucceededActions { get; set; }
    public int FailedActions { get; set; }
    public int BlockedActions { get; set; }
    public int FailClosedViolations { get; set; }
    public int ReadErrors { get; set; }
    public long SourceBytesRemoved { get; set; }
    public long SourceAllocatedBytesRemoved { get; set; }
    public string FreeSpaceProofAssessment { get; set; } = "NOT_APPLICABLE";
    public string VerificationStatus { get; set; } = "NOT_MEASURED";
    public List<ActionEvidence> Actions { get; set; } = new();
    public MaintenanceExecution? Maintenance { get; set; }

    public static EvidenceReport FromScan(string mode, DiskSnapshot before, DiskSnapshot after, ScanResult scan)
        => new()
        {
            Mode = mode,
            DriveRoot = before.DriveRoot,
            FreeBytesBefore = before.FreeBytes,
            FreeBytesAfter = after.FreeBytes,
            VerifiedFreeGainBytes = after.FreeBytes - before.FreeBytes,
            CandidateCount = scan.Candidates.Count,
            CandidateBytes = scan.CandidateBytes,
            CandidateAllocatedBytes = scan.CandidateAllocatedBytes,
            FailClosedViolations = scan.FailClosedViolations,
            ReadErrors = scan.ReadErrors,
            FreeSpaceProofAssessment = "READ_ONLY_SCAN",
            VerificationStatus = scan.FailClosedViolations != 0 ? "FAIL_CLOSED" : (scan.ReadErrors > 0 ? "VERIFIED_SCAN_BOUNDED" : "VERIFIED_SCAN")
        };

    public static EvidenceReport FromExecution(string mode, DiskSnapshot before, DiskSnapshot after, ScanResult scan, ExecutionResult exec)
    {
        var gain = after.FreeBytes - before.FreeBytes;
        var measurableGainOk = exec.Succeeded == 0 || gain > 0;
        var proofAssessment = FreeSpaceProofPolicy.Classify(exec.SourceAllocatedBytesRemoved, gain);
        var proofIsBounded = proofAssessment is "CONCURRENT_VOLUME_ACTIVITY" or "EXTERNAL_VOLUME_ACTIVITY";
        var status = exec.Failed == 0 && scan.FailClosedViolations == 0 && measurableGainOk
            ? ((scan.ReadErrors > 0 || exec.Blocked > 0 || proofIsBounded) ? "VERIFIED_PASS_BOUNDED" : "VERIFIED_PASS") : "PARTIAL_OR_FAIL_CLOSED";
        return new EvidenceReport
        {
            Mode = mode,
            DriveRoot = before.DriveRoot,
            FreeBytesBefore = before.FreeBytes,
            FreeBytesAfter = after.FreeBytes,
            VerifiedFreeGainBytes = gain,
            CandidateCount = scan.Candidates.Count,
            CandidateBytes = scan.CandidateBytes,
            CandidateAllocatedBytes = scan.CandidateAllocatedBytes,
            SucceededActions = exec.Succeeded,
            FailedActions = exec.Failed,
            BlockedActions = exec.Blocked,
            FailClosedViolations = scan.FailClosedViolations,
            ReadErrors = scan.ReadErrors,
            SourceBytesRemoved = exec.SourceBytesRemoved,
            SourceAllocatedBytesRemoved = exec.SourceAllocatedBytesRemoved,
            FreeSpaceProofAssessment = proofAssessment,
            VerificationStatus = status,
            Actions = exec.Actions
        };
    }

    public static EvidenceReport FromMaintenance(DiskSnapshot before, DiskSnapshot after, MaintenanceExecution exec)
        => FromMaintenance("windows-component-cleanup", before, after, exec);

    public static EvidenceReport FromMaintenance(string mode, DiskSnapshot before, DiskSnapshot after, MaintenanceExecution exec)
    {
        var gain = after.FreeBytes - before.FreeBytes;
        return new EvidenceReport
        {
            Mode = mode,
            DriveRoot = before.DriveRoot,
            FreeBytesBefore = before.FreeBytes,
            FreeBytesAfter = after.FreeBytes,
            VerifiedFreeGainBytes = gain,
            CandidateCount = 1,
            CandidateBytes = 0,
            SucceededActions = exec.Succeeded ? 1 : 0,
            FailedActions = exec.Succeeded ? 0 : 1,
            FailClosedViolations = 0,
            SourceBytesRemoved = Math.Max(0, gain),
            SourceAllocatedBytesRemoved = Math.Max(0, gain),
            FreeSpaceProofAssessment = "MAINTENANCE_OBSERVED_GAIN",
            VerificationStatus = exec.Succeeded && gain >= 0 ? "VERIFIED_PASS" : "PARTIAL_OR_FAIL_CLOSED",
            Maintenance = exec
        };
    }
}

internal sealed class AnalysisReport
{
    public string SchemaVersion { get; set; } = "3.0";
    public string Mode { get; set; } = "analyze-deep";
    public DateTime CreatedUtc { get; set; } = DateTime.UtcNow;
    public string MachineName { get; set; } = Environment.MachineName;
    public string DriveRoot { get; set; } = "";
    public long FreeBytesBefore { get; set; }
    public long FreeBytesAfter { get; set; }
    public int MinAgeDays { get; set; }
    public int MinSizeMiB { get; set; }
    public int DuplicateMinMiB { get; set; }
    public List<FileFinding> LargeFiles { get; set; } = new();
    public List<FileFinding> OldInstallers { get; set; } = new();
    public List<DuplicateGroup> DuplicateGroups { get; set; } = new();
    public List<CompressionOpportunity> CompressionOpportunities { get; set; } = new();
    public List<DirectoryHotspot> DirectoryHotspots { get; set; } = new();
    public long DuplicatePotentialSavingsBytes { get; set; }
    public long DuplicatePhysicalPotentialSavingsBytes { get; set; }
    public long CompressionEstimatedSavingsBytes { get; set; }
    public long ReviewOnlyPotentialBytes { get; set; }
    public long TotalEstimatedOpportunityBytes { get; set; }
    public int FailClosedViolations { get; set; }
    public int ReadErrors { get; set; }
    public long InventoryFilesScanned { get; set; }
    public long InventoryBytesScanned { get; set; }
    public long InventoryAllocatedBytesScanned { get; set; }
    public int AllocationMeasurementErrors { get; set; }
    public bool AnalysisTruncated { get; set; }
    public string AnalysisTruncationReason { get; set; } = "";
    public string VerificationStatus { get; set; } = "NOT_MEASURED";

    public static AnalysisReport Create(DiskSnapshot before, DiskSnapshot after, DeepAnalysisResult r, CliOptions options)
    {
        var duplicate = r.DuplicateGroups.Sum(x => x.PotentialSavingsBytes);
        var duplicatePhysical = r.DuplicateGroups.Sum(x => x.PhysicalPotentialSavingsBytes >= 0 ? x.PhysicalPotentialSavingsBytes : x.PotentialSavingsBytes);
        var compression = r.CompressionOpportunities.Sum(x => Math.Min(x.EstimatedSavingsBytes, x.AllocatedBytes >= 0 ? x.AllocatedBytes : x.SizeBytes));
        var reviewOnlyDistinct = r.LargeFiles.Concat(r.OldInstallers)
            .GroupBy(x => x.Path, StringComparer.OrdinalIgnoreCase)
            .Sum(g => { var f = g.First(); return f.AllocatedBytes >= 0 ? f.AllocatedBytes : f.SizeBytes; });

        // Conservative non-overlap estimate: duplicate savings + best per-path review/compression opportunity.
        var duplicateFiles = new HashSet<string>(r.DuplicateGroups.SelectMany(g => g.Files.Skip(1)), StringComparer.OrdinalIgnoreCase);
        var perPath = new Dictionary<string, long>(StringComparer.OrdinalIgnoreCase);
        foreach (var f in r.LargeFiles.Concat(r.OldInstallers))
        {
            var physical = f.AllocatedBytes >= 0 ? f.AllocatedBytes : f.SizeBytes;
            if (!duplicateFiles.Contains(f.Path)) perPath[f.Path] = Math.Max(perPath.GetValueOrDefault(f.Path), physical);
        }
        foreach (var c in r.CompressionOpportunities)
        {
            var physicalSavings = Math.Min(c.EstimatedSavingsBytes, c.AllocatedBytes >= 0 ? c.AllocatedBytes : c.SizeBytes);
            if (!duplicateFiles.Contains(c.Path)) perPath[c.Path] = Math.Max(perPath.GetValueOrDefault(c.Path), physicalSavings);
        }
        var conservative = duplicatePhysical + perPath.Values.Sum();

        return new AnalysisReport
        {
            DriveRoot = before.DriveRoot,
            FreeBytesBefore = before.FreeBytes,
            FreeBytesAfter = after.FreeBytes,
            MinAgeDays = options.MinAgeDays,
            MinSizeMiB = options.MinSizeMiB,
            DuplicateMinMiB = options.DuplicateMinMiB,
            LargeFiles = r.LargeFiles,
            OldInstallers = r.OldInstallers,
            DuplicateGroups = r.DuplicateGroups,
            CompressionOpportunities = r.CompressionOpportunities,
            DirectoryHotspots = r.DirectoryHotspots,
            DuplicatePotentialSavingsBytes = duplicate,
            DuplicatePhysicalPotentialSavingsBytes = duplicatePhysical,
            CompressionEstimatedSavingsBytes = compression,
            ReviewOnlyPotentialBytes = reviewOnlyDistinct,
            TotalEstimatedOpportunityBytes = conservative,
            FailClosedViolations = r.FailClosedViolations,
            ReadErrors = r.ReadErrors,
            InventoryFilesScanned = r.InventoryFilesScanned,
            InventoryBytesScanned = r.InventoryBytesScanned,
            InventoryAllocatedBytesScanned = r.InventoryAllocatedBytesScanned,
            AllocationMeasurementErrors = r.AllocationMeasurementErrors,
            AnalysisTruncated = r.AnalysisTruncated,
            AnalysisTruncationReason = r.AnalysisTruncationReason,
            VerificationStatus = r.FailClosedViolations != 0 ? "PARTIAL_FAIL_CLOSED" :
                (r.AnalysisTruncated || r.ReadErrors > 0 || r.AllocationMeasurementErrors > 0 ? "VERIFIED_ANALYSIS_BOUNDED" : "VERIFIED_ANALYSIS")
        };
    }
}

internal sealed record VerificationResult(string Status, List<string> Checks);

internal static class EvidenceVerifier
{
    public static VerificationResult Verify(EvidenceReport r)
    {
        var checks = new List<string>();
        bool ok = true;
        void Check(bool condition, string name)
        {
            checks.Add((condition ? "PASS: " : "FAIL: ") + name);
            if (!condition) ok = false;
        }

        Check(r.FreeBytesAfter - r.FreeBytesBefore == r.VerifiedFreeGainBytes, "free-space arithmetic");
        Check(r.CandidateCount >= 0 && r.CandidateBytes >= 0 && r.CandidateAllocatedBytes >= 0, "candidate counters non-negative");
        Check(r.SucceededActions >= 0 && r.FailedActions >= 0 && r.BlockedActions >= 0 && r.FailClosedViolations >= 0 && r.ReadErrors >= 0, "action/read-error counters non-negative");
        Check(r.Actions.All(a => a.SizeBytes >= 0 && a.AllocatedBytes >= -1), "action logical/allocated sizes non-negative or unknown");
        Check(r.Actions.All(a => a.Status is "VERIFIED" or "FAILED" or "FAIL_CLOSED"), "action statuses bounded");
        Check(r.Actions.Where(a => a.Status == "VERIFIED").All(a => IsSha256(a.Sha256)), "verified actions have valid SHA-256");
        Check(r.Actions.Where(a => a.Status == "VERIFIED").Select(a => a.Source).Distinct(StringComparer.OrdinalIgnoreCase).Count() == r.Actions.Count(a => a.Status == "VERIFIED"), "verified sources are unique");
        if (r.Actions.Count > 0 || r.Mode is "clean-safe" or "auto-care-safe-cleanup")
        {
            Check(r.SourceBytesRemoved == r.Actions.Where(a => a.Status == "VERIFIED").Sum(a => a.SizeBytes), "source-bytes-removed matches verified action evidence");
            var allocatedEvidence = r.Actions.Where(a => a.Status == "VERIFIED" && a.AllocatedBytes >= 0).ToList();
            if (allocatedEvidence.Count > 0)
                Check(r.SourceAllocatedBytesRemoved == allocatedEvidence.Sum(a => a.AllocatedBytes), "physical source bytes removed match handle-bound allocation evidence");
        }
        Check(r.SucceededActions + r.FailedActions + r.BlockedActions <= r.CandidateCount, "action counters do not exceed candidates");
        Check(r.BlockedActions == r.Actions.Count(a => a.Status == "FAIL_CLOSED"), "blocked-action count matches fail-closed evidence rows");
        if (r.Mode == "clean-safe" || r.Mode == "auto-care-safe-cleanup")
        {
            Check(r.SucceededActions == r.Actions.Count(a => a.Status == "VERIFIED"), "success count matches evidence");
            Check(r.SucceededActions == 0 || r.VerifiedFreeGainBytes > 0, "successful cleanup produced measurable free-space gain");
            var expectedProof = FreeSpaceProofPolicy.Classify(r.SourceAllocatedBytesRemoved, r.VerifiedFreeGainBytes);
            Check(r.FreeSpaceProofAssessment == expectedProof, "free-space proof assessment matches physical reclaim evidence");
        }
        if (r.Maintenance is not null)
        {
            Check(!r.Maintenance.CommandLine.Contains("ResetBase", StringComparison.OrdinalIgnoreCase), "ResetBase not used");
            Check(r.Maintenance.Succeeded == (r.Maintenance.ExitCode == 0), "maintenance exit code consistency");
            if (r.VerificationStatus == "VERIFIED_PASS")
                Check(r.Maintenance.Succeeded && r.VerifiedFreeGainBytes >= 0, "maintenance verified-pass status is consistent");
        }
        if (r.Mode.Contains("scan", StringComparison.OrdinalIgnoreCase) && r.Actions.Count == 0)
        {
            var expectedScan = r.FailClosedViolations != 0 ? "FAIL_CLOSED" : (r.ReadErrors > 0 ? "VERIFIED_SCAN_BOUNDED" : "VERIFIED_SCAN");
            Check(r.VerificationStatus == expectedScan, "scan verification status consistent");
        }
        if (r.Mode is "clean-safe" or "auto-care-safe-cleanup" && r.VerificationStatus.StartsWith("VERIFIED_PASS", StringComparison.Ordinal))
        {
            Check(r.FailedActions == 0 && r.FailClosedViolations == 0 && (r.SucceededActions == 0 || r.VerifiedFreeGainBytes > 0), "cleanup verified-pass status is consistent");
            var proofBounded = r.FreeSpaceProofAssessment is "CONCURRENT_VOLUME_ACTIVITY" or "EXTERNAL_VOLUME_ACTIVITY";
            Check(r.VerificationStatus == ((r.ReadErrors > 0 || r.BlockedActions > 0 || proofBounded) ? "VERIFIED_PASS_BOUNDED" : "VERIFIED_PASS"), "cleanup bounded status matches skipped/read-error/proof-drift coverage");
        }

        return new VerificationResult(ok ? "VERIFIED_PASS" : "VERIFY_FAIL", checks);
    }

    private static bool IsSha256(string value)
    {
        if (value.Length != 64) return false;
        try { _ = Convert.FromHexString(value); return true; }
        catch { return false; }
    }
}

internal static class AnalysisVerifier
{
    public static VerificationResult Verify(AnalysisReport r)
    {
        var checks = new List<string>();
        bool ok = true;
        void Check(bool condition, string name)
        {
            checks.Add((condition ? "PASS: " : "FAIL: ") + name);
            if (!condition) ok = false;
        }

        Check(r.LargeFiles.All(f => f.SizeBytes >= 0), "large-file sizes non-negative");
        Check(r.OldInstallers.All(f => f.SizeBytes >= 0), "installer sizes non-negative");
        Check(r.DuplicateGroups.All(g => g.Files.Count >= 2 && g.Sha256.Length == 64), "duplicate groups contain >=2 files and SHA-256");
        Check(r.DuplicateGroups.All(g => g.PotentialSavingsBytes == g.FileSizeBytes * (g.Files.Count - 1L)), "duplicate logical savings arithmetic");
        Check(r.DuplicateGroups.All(g => g.FileAllocatedBytes is null || (g.FileAllocatedBytes.Count == g.Files.Count && g.FileAllocatedBytes.All(x => x >= 0))), "duplicate allocation vectors structurally valid");
        Check(r.DuplicateGroups.All(g => g.FileAllocatedBytes is null || g.PhysicalPotentialSavingsBytes == Math.Max(0, g.FileAllocatedBytes.Sum() - g.FileAllocatedBytes.Min())), "duplicate physical savings arithmetic");
        Check(r.DuplicatePotentialSavingsBytes == r.DuplicateGroups.Sum(g => g.PotentialSavingsBytes), "duplicate logical total arithmetic");
        Check(r.DuplicatePhysicalPotentialSavingsBytes == r.DuplicateGroups.Sum(g => g.PhysicalPotentialSavingsBytes >= 0 ? g.PhysicalPotentialSavingsBytes : g.PotentialSavingsBytes), "duplicate physical total arithmetic");
        Check(r.CompressionEstimatedSavingsBytes == r.CompressionOpportunities.Sum(c => Math.Min(c.EstimatedSavingsBytes, c.AllocatedBytes >= 0 ? c.AllocatedBytes : c.SizeBytes)), "compression physical total arithmetic");
        Check(r.CompressionOpportunities.All(c => c.EstimatedRatio >= 0 && c.EstimatedRatio <= 1.0 && c.EstimatedSavingsBytes >= 0), "compression estimates bounded");
        Check(r.TotalEstimatedOpportunityBytes >= r.DuplicatePhysicalPotentialSavingsBytes, "conservative opportunity includes physical duplicate floor");
        Check(r.FreeBytesAfter >= 0 && r.FreeBytesBefore >= 0, "free-space snapshots valid");
        Check(r.ReadErrors >= 0 && r.InventoryFilesScanned >= 0 && r.InventoryBytesScanned >= 0 && r.InventoryAllocatedBytesScanned >= 0 && r.AllocationMeasurementErrors >= 0, "analysis coverage/allocation counters non-negative");
        Check(r.FailClosedViolations == 0, "no containment safety violations in read-only analysis");
        Check(r.VerificationStatus is "VERIFIED_ANALYSIS" or "VERIFIED_ANALYSIS_BOUNDED", "analysis status is verified or verified-bounded");
        if (r.VerificationStatus == "VERIFIED_ANALYSIS_BOUNDED")
            Check(r.AnalysisTruncated || r.ReadErrors > 0 || r.AllocationMeasurementErrors > 0, "bounded analysis has an explicit coverage/allocation limitation");
        if (r.VerificationStatus == "VERIFIED_ANALYSIS")
            Check(!r.AnalysisTruncated && r.ReadErrors == 0 && r.AllocationMeasurementErrors == 0, "exact analysis status has no hidden coverage/allocation limitation");
        Check(r.DuplicateGroups.All(g => g.Files.Distinct(StringComparer.OrdinalIgnoreCase).Count() == g.Files.Count), "duplicate group paths are unique");
        Check(r.CompressionOpportunities.All(c => c.EstimatedSavingsBytes <= c.SizeBytes && c.EstimatedSavingsBytes <= (c.AllocatedBytes >= 0 ? c.AllocatedBytes : c.SizeBytes)), "compression savings do not exceed logical/allocated source size");
        Check(r.DirectoryHotspots.All(h => h.TotalBytes >= 0 && h.FileCount > 0 && !string.IsNullOrWhiteSpace(h.Path)), "directory hotspots are structurally valid");

        return new VerificationResult(ok ? "VERIFIED_PASS" : "VERIFY_FAIL", checks);
    }
}

internal static class ReportIO
{
    public static string WriteEvidence(EvidenceReport report, string? requested) => Write(report, requested, "Evidence");
    public static string WriteAnalysis(AnalysisReport report, string? requested) => Write(report, requested, "Analysis");
    public static string WriteSpacePlan(SpacePlanReport report, string? requested) => Write(report, requested, "SpacePlan");

    private static string Write<T>(T report, string? requested, string kind)
    {
        var dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "DiskGuardSpace", "Reports");
        Directory.CreateDirectory(dir);
        var path = string.IsNullOrWhiteSpace(requested)
            ? Path.Combine(dir, $"DiskGuardSpace-{kind}-{DateTime.Now:yyyyMMdd-HHmmss}.json")
            : Path.GetFullPath(requested);
        AtomicFile.WriteAllText(path, JsonSerializer.Serialize(report, Json.Options));
        return path;
    }
}

internal static class AtomicFile
{
    public static void WriteAllText(string path, string content)
    {
        var full = Path.GetFullPath(path);
        var dir = Path.GetDirectoryName(full) ?? throw new IOException("Report directory unresolved");
        Directory.CreateDirectory(dir);
        var temp = Path.Combine(dir, "." + Path.GetFileName(full) + "." + Guid.NewGuid().ToString("N") + ".tmp");
        try
        {
            using (var fs = new FileStream(temp, FileMode.CreateNew, FileAccess.Write, FileShare.None, 64 * 1024, FileOptions.WriteThrough))
            using (var sw = new StreamWriter(fs, new UTF8Encoding(encoderShouldEmitUTF8Identifier: false)))
            {
                sw.Write(content);
                sw.Flush();
                fs.Flush(flushToDisk: true);
            }
            File.Move(temp, full, overwrite: true);
        }
        finally
        {
            try { if (File.Exists(temp)) File.Delete(temp); } catch { }
        }
    }
}

internal static class Json
{
    public static readonly JsonSerializerOptions Options = new()
    {
        WriteIndented = true,
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        Converters = { new JsonStringEnumConverter() }
    };
}
