$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest
$InstallRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$Exe = Join-Path $InstallRoot "DiskGuardSpace.exe"
$Proof = Join-Path $InstallRoot "RELEASE_PROOF.json"
$VerifyRelease = Join-Path $InstallRoot "VERIFY_RELEASE.ps1"
$VerifyStartup = Join-Path $InstallRoot "VERIFY_STARTUP_AUTOMATION.ps1"
$InstallManifest = Join-Path $InstallRoot "INSTALL_MANIFEST.json"
$StateRoot = Join-Path $env:LOCALAPPDATA "DiskGuardSpace\Background"
$SessionRoot = Join-Path $StateRoot "Sessions"
$StatePath = Join-Path $StateRoot "startup-state.json"

function Get-Sha256([string]$Path) { return (Get-FileHash $Path -Algorithm SHA256).Hash.ToLowerInvariant() }
function Get-TextSha256([string]$Text) {
    $sha = [Security.Cryptography.SHA256]::Create()
    try {
        $bytes = [Text.Encoding]::UTF8.GetBytes($Text)
        $hash = $sha.ComputeHash($bytes)
        return (($hash | ForEach-Object { $_.ToString('x2') }) -join '')
    } finally { $sha.Dispose() }
}
function Write-AtomicJson([string]$Path, $Object) {
    $dir = Split-Path -Parent $Path
    New-Item -ItemType Directory -Force -Path $dir | Out-Null
    $pending = Join-Path $dir (([IO.Path]::GetFileName($Path)) + ".pending-" + [guid]::NewGuid().ToString('N'))
    $bytes = [Text.Encoding]::UTF8.GetBytes(($Object | ConvertTo-Json -Depth 8))
    $fs = New-Object IO.FileStream($pending,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None,4096,[IO.FileOptions]::WriteThrough)
    try { $fs.Write($bytes,0,$bytes.Length); $fs.Flush($true) } finally { $fs.Dispose() }
    if (Test-Path $Path -PathType Leaf) {
        $backup = Join-Path $dir (([IO.Path]::GetFileName($Path)) + ".previous")
        try { [IO.File]::Replace($pending,$Path,$backup,$true) } finally { Remove-Item $backup -Force -ErrorAction SilentlyContinue }
    } else { Move-Item $pending $Path -Force }
}
function Fail-Closed([string]$Reason, [string]$BootId = "") {
    try {
        if ($BootId) {
            $state = [ordered]@{ schema='DiskGuardSpace.StartupState.v1'; lastBootId=$BootId; lastAttemptUtc=[DateTime]::UtcNow.ToString('o'); status='FAIL_CLOSED'; reason=$Reason }
            Write-AtomicJson $StatePath $state
        }
    } catch { }
    exit 2
}
function Invoke-SessionRetention([string]$CurrentSession) {
    try {
        if (-not (Test-Path $SessionRoot -PathType Container)) { return }
        $dirs = @(Get-ChildItem $SessionRoot -Directory | Where-Object { $_.Name -match '^\d{8}-\d{6}-[0-9a-f]{8}$' } | Sort-Object LastWriteTimeUtc -Descending)
        foreach ($d in @($dirs | Select-Object -Skip 30)) {
            if ($d.FullName -ne $CurrentSession -and $d.FullName.StartsWith([IO.Path]::GetFullPath($SessionRoot).TrimEnd('\') + '\',[StringComparison]::OrdinalIgnoreCase)) {
                Remove-Item $d.FullName -Recurse -Force -ErrorAction SilentlyContinue
            }
        }
    } catch { }
}

try {
    foreach ($required in @($Exe,$Proof,$VerifyRelease,$VerifyStartup,$InstallManifest)) { if (-not (Test-Path $required -PathType Leaf)) { throw "Missing installed runtime file: $required" } }
    & $VerifyStartup -InstallRoot $InstallRoot -RequireCurrentUser
    if ($LASTEXITCODE -ne 0) { throw "Startup task/install identity verification failed." }
    & $VerifyRelease -ExePath $Exe -ProofPath $Proof
    if ($LASTEXITCODE -ne 0) { throw "Installed release verification failed." }

    try { $bootUtc = (Get-CimInstance Win32_OperatingSystem -ErrorAction Stop).LastBootUpTime.ToUniversalTime().ToString('o') } catch { throw "Windows boot identity could not be established." }
    $bootId = Get-TextSha256 $bootUtc
    New-Item -ItemType Directory -Force -Path $SessionRoot | Out-Null

    $prior = $null
    if (Test-Path $StatePath -PathType Leaf) {
        try { $prior = Get-Content $StatePath -Raw | ConvertFrom-Json } catch {
            $corrupt = Join-Path $StateRoot ("startup-state.corrupt-" + (Get-Date -Format 'yyyyMMdd-HHmmss') + ".json")
            Move-Item $StatePath $corrupt -Force -ErrorAction SilentlyContinue
            throw "Startup state was malformed; current boot skipped fail-closed."
        }
        if ($prior.schema -ne 'DiskGuardSpace.StartupState.v1') { throw "Unexpected startup-state schema; current boot skipped fail-closed." }
        if ([string]$prior.lastBootId -eq $bootId) { exit 0 }
    }

    $exeHash = Get-Sha256 $Exe
    $fullDue = $true
    $lastFullUtc = [DateTime]::MinValue
    if ($prior -and $prior.PSObject.Properties['lastFullVerificationUtc']) {
        [void][DateTime]::TryParse([string]$prior.lastFullVerificationUtc,[ref]$lastFullUtc)
    }
    if ($prior -and $prior.PSObject.Properties['lastFullExeSha256'] -and [string]$prior.lastFullExeSha256 -eq $exeHash -and $lastFullUtc -gt [DateTime]::UtcNow.AddDays(-7) -and $lastFullUtc -le [DateTime]::UtcNow.AddMinutes(5)) { $fullDue = $false }

    $deepAnalysisDue = $true
    $lastDeepAnalysisUtc = [DateTime]::MinValue
    if ($prior -and $prior.PSObject.Properties['lastDeepAnalysisUtc']) { [void][DateTime]::TryParse([string]$prior.lastDeepAnalysisUtc,[ref]$lastDeepAnalysisUtc) }
    if ($lastDeepAnalysisUtc -gt [DateTime]::UtcNow.AddDays(-3) -and $lastDeepAnalysisUtc -le [DateTime]::UtcNow.AddMinutes(5)) { $deepAnalysisDue = $false }

    $deepHealthDue = $true
    $lastDeepHealthUtc = [DateTime]::MinValue
    if ($prior -and $prior.PSObject.Properties['lastDeepHealthUtc']) { [void][DateTime]::TryParse([string]$prior.lastDeepHealthUtc,[ref]$lastDeepHealthUtc) }
    if ($lastDeepHealthUtc -gt [DateTime]::UtcNow.AddDays(-14) -and $lastDeepHealthUtc -le [DateTime]::UtcNow.AddMinutes(5)) { $deepHealthDue = $false }

    $lastFullVerificationText = ''
    $lastFullExeHashText = ''
    $lastDeepAnalysisText = ''
    $lastDeepHealthText = ''
    if ($prior -and $prior.PSObject.Properties['lastFullVerificationUtc']) { $lastFullVerificationText = [string]$prior.lastFullVerificationUtc }
    if ($prior -and $prior.PSObject.Properties['lastFullExeSha256']) { $lastFullExeHashText = [string]$prior.lastFullExeSha256 }
    if ($prior -and $prior.PSObject.Properties['lastDeepAnalysisUtc']) { $lastDeepAnalysisText = [string]$prior.lastDeepAnalysisUtc }
    if ($prior -and $prior.PSObject.Properties['lastDeepHealthUtc']) { $lastDeepHealthText = [string]$prior.lastDeepHealthUtc }
    $state = [ordered]@{
        schema='DiskGuardSpace.StartupState.v1'; lastBootId=$bootId; bootUtc=$bootUtc; lastAttemptUtc=[DateTime]::UtcNow.ToString('o'); status='IN_PROGRESS'; exeSha256=$exeHash
        lastFullVerificationUtc=$lastFullVerificationText
        lastFullExeSha256=$lastFullExeHashText
        lastDeepAnalysisUtc=$lastDeepAnalysisText
        lastDeepHealthUtc=$lastDeepHealthText
    }
    Write-AtomicJson $StatePath $state

    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    $session = Join-Path $SessionRoot ($stamp + '-' + $bootId.Substring(0,8))
    New-Item -ItemType Directory -Path $session -Force | Out-Null
    $master = Join-Path $session 'auto-care.json'
    $runtimeLog = Join-Path $session 'background-runtime.log'

    if ($fullDue) {
        & $Exe self-test *>> $runtimeLog
        if ($LASTEXITCODE -ne 0) { throw "Weekly/change-triggered packaged self-test failed." }
        & $Exe negative-tests *>> $runtimeLog
        if ($LASTEXITCODE -ne 0) { throw "Weekly/change-triggered negative/regression tests failed." }
        $state.lastFullVerificationUtc = [DateTime]::UtcNow.ToString('o')
        $state.lastFullExeSha256 = $exeHash
        Write-AtomicJson $StatePath $state
    }

    $careArgs = @('auto-care','--apply','--startup-background','--report',$master,'--work-dir',$session,'--min-age-days','7','--min-size-mib','500','--duplicate-min-mib','10','--top','150')
    if (-not $deepAnalysisDue) { $careArgs += '--skip-deep-analysis' }
    if ($deepHealthDue) { $careArgs += '--deep-health' }
    & $Exe @careArgs *>> $runtimeLog
    $autoExit = $LASTEXITCODE
    if (-not (Test-Path $master -PathType Leaf)) { throw "Background auto-care did not produce its master report." }
    & $Exe verify-auto-care $master *>> $runtimeLog
    $verifyExit = $LASTEXITCODE

    if ($autoExit -eq 0 -and $verifyExit -eq 0) {
        if ($deepAnalysisDue) { $state.lastDeepAnalysisUtc = [DateTime]::UtcNow.ToString('o') }
        if ($deepHealthDue) { $state.lastDeepHealthUtc = [DateTime]::UtcNow.ToString('o') }
    }

    $state.status = if ($autoExit -eq 0 -and $verifyExit -eq 0) { 'VERIFIED_PASS' } else { 'PARTIAL_OR_FAIL_CLOSED' }
    $state.lastCompleteUtc = [DateTime]::UtcNow.ToString('o')
    $state.lastSession = $session
    $state.autoCareExitCode = $autoExit
    $state.verifyExitCode = $verifyExit
    Write-AtomicJson $StatePath $state
    Invoke-SessionRetention $session
    if ($autoExit -eq 0 -and $verifyExit -eq 0) { exit 0 } else { exit 2 }
}
catch {
    try {
        $bootForFailure = ''
        try { $bootForFailure = Get-TextSha256 ((Get-CimInstance Win32_OperatingSystem).LastBootUpTime.ToUniversalTime().ToString('o')) } catch { }
        Fail-Closed $_.Exception.Message $bootForFailure
    } catch { exit 2 }
}
