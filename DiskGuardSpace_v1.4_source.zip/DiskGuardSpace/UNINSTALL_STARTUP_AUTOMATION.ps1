param([switch]$RemoveInstalledFiles)
$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest
$TaskPath = "\"
$TaskName = "DiskGuardSpace_StartupMaintenance"
$UpdateGuardTaskName = "DiskGuardSpace_UpdateGuard"
$InstallRoot = Join-Path $env:ProgramFiles "DiskGuardSpace"
function Test-Administrator {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    $p = New-Object Security.Principal.WindowsPrincipal($id)
    return $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}
if (-not (Test-Administrator)) { throw "Administrator permission is required to remove the startup task." }
$task = Get-ScheduledTask -TaskPath $TaskPath -TaskName $TaskName -ErrorAction SilentlyContinue
if ($task -and $task.State -eq 'Running') { throw "Startup maintenance is currently running. FAIL-CLOSED: do not terminate it mid-maintenance." }
if ($task) { Unregister-ScheduledTask -TaskName $TaskName -TaskPath $TaskPath -Confirm:$false }
$guardExe = Join-Path $InstallRoot "DiskGuardSpace.exe"
if (Test-Path $guardExe -PathType Leaf) {
    & $guardExe update-guard disable
    if ($LASTEXITCODE -notin @(0,2)) { throw "Update Guard disable failed; refusing uninstall." }
}
Get-ScheduledTask -TaskPath $TaskPath -TaskName $UpdateGuardTaskName -ErrorAction SilentlyContinue |
    Unregister-ScheduledTask -TaskName $UpdateGuardTaskName -TaskPath $TaskPath -Confirm:$false
if ($RemoveInstalledFiles -and (Test-Path $InstallRoot -PathType Container)) {
    if ((((Get-Item $InstallRoot -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0)) { throw "Install root is a reparse point; refusing recursive removal." }
    $expected = [IO.Path]::GetFullPath((Join-Path $env:ProgramFiles 'DiskGuardSpace')).TrimEnd('\')
    if ([IO.Path]::GetFullPath($InstallRoot).TrimEnd('\') -ne $expected) { throw "Unexpected install root." }
    Remove-Item $InstallRoot -Recurse -Force
}
Write-Host "STARTUP AUTOMATION UNINSTALL: PASS" -ForegroundColor Green
Write-Host "User maintenance reports under LocalAppData were preserved."
