using System.Diagnostics;
using System.Runtime.InteropServices;
using Microsoft.Win32.SafeHandles;

namespace DiskGuardSpace;

internal sealed class SafetyBlockException : IOException
{
    public SafetyBlockException(string message) : base(message) { }
}

/// <summary>
/// Opens the exact Windows file object with READ+DELETE access and with write/delete sharing denied.
/// Hashing, metadata verification and deletion are all bound to the same kernel handle, removing the
/// path-replacement race that exists in "hash path -> File.Delete(path)" designs.
/// </summary>
internal sealed class VerifiedWindowsFile : IDisposable
{
    private const uint GenericRead = 0x80000000;
    private const uint DeleteAccess = 0x00010000;
    private const uint FileShareRead = 0x00000001;
    private const uint OpenExisting = 3;
    private const uint FileFlagOpenReparsePoint = 0x00200000;
    private const uint FileFlagSequentialScan = 0x08000000;
    private const uint FileAttributeReadOnly = 0x00000001;
    private const uint FileAttributeSystem = 0x00000004;
    private const uint FileAttributeReparsePoint = 0x00000400;

    private readonly FileStream stream;
    private bool deleteMarked;

    public long Length { get; }
    public DateTime LastWriteUtc { get; }
    public uint LinkCount { get; }
    public long AllocationBytes { get; }
    public string Sha256 { get; }
    public Stream Stream => stream;

    private VerifiedWindowsFile(FileStream stream, long length, DateTime lastWriteUtc, uint linkCount, long allocationBytes, string sha256)
    {
        this.stream = stream;
        Length = length;
        LastWriteUtc = lastWriteUtc;
        LinkCount = linkCount;
        AllocationBytes = Math.Max(0, allocationBytes);
        Sha256 = sha256;
    }

    public static VerifiedWindowsFile OpenAndVerify(Candidate candidate)
    {
        if (!OperatingSystem.IsWindows()) throw new PlatformNotSupportedException();

        var handle = CreateFileW(
            candidate.Path,
            GenericRead | DeleteAccess,
            FileShareRead,
            IntPtr.Zero,
            OpenExisting,
            FileFlagOpenReparsePoint | FileFlagSequentialScan,
            IntPtr.Zero);

        if (handle.IsInvalid)
        {
            var err = Marshal.GetLastWin32Error();
            handle.Dispose();
            if (err is 5 or 32 or 33)
                throw new SafetyBlockException($"File is inaccessible/in-use; preserved; win32={err}");
            throw new IOException($"Verified handle open failed; win32={err}");
        }

        try
        {
            if (!GetFileInformationByHandle(handle, out var info))
                throw new IOException($"GetFileInformationByHandle failed; win32={Marshal.GetLastWin32Error()}");

            if ((info.FileAttributes & FileAttributeReparsePoint) != 0)
                throw new SafetyBlockException("Reparse-point file rejected by handle metadata");
            if ((info.FileAttributes & FileAttributeReadOnly) != 0)
                throw new SafetyBlockException("Read-only file rejected from automatic cleanup");
            if ((info.FileAttributes & FileAttributeSystem) != 0)
                throw new SafetyBlockException("System-attributed file rejected from automatic cleanup");
            if (info.NumberOfLinks != 1)
                throw new SafetyBlockException($"Hard-linked file rejected; linkCount={info.NumberOfLinks}");

            var length = ((long)info.FileSizeHigh << 32) | info.FileSizeLow;
            var writeUtc = DateTime.FromFileTimeUtc(((long)(uint)info.LastWriteTime.dwHighDateTime << 32) | (uint)info.LastWriteTime.dwLowDateTime);
            if (length != candidate.SizeBytes || writeUtc != candidate.LastWriteUtc)
                throw new SafetyBlockException("File identity/metadata changed before handle verification");

            // Query allocation from the exact same kernel object. This prevents sparse/compressed
            // files from inflating reclaimed-space evidence with logical length. Failure is not an
            // authorization failure; we fall back to the scan-time conservative value.
            long allocationBytes = candidate.AllocatedBytes >= 0 ? candidate.AllocatedBytes : candidate.SizeBytes;
            if (GetFileInformationByHandleEx(handle, FileInfoByHandleClass.FileStandardInfo, out FileStandardInfo standard, (uint)Marshal.SizeOf<FileStandardInfo>()))
                allocationBytes = Math.Max(0, standard.AllocationSize);

            var fs = new FileStream(handle, FileAccess.Read, 64 * 1024, isAsync: false);
            handle = null!; // ownership transferred to FileStream
            var hash = Hashing.Sha256(fs);
            if (fs.Length != candidate.SizeBytes)
            {
                fs.Dispose();
                throw new SafetyBlockException("File size changed during handle-bound hash verification");
            }
            fs.Position = 0;
            return new VerifiedWindowsFile(fs, length, writeUtc, info.NumberOfLinks, allocationBytes, hash);
        }
        catch
        {
            if (handle is not null) handle.Dispose();
            throw;
        }
    }

    public void MarkDelete()
    {
        if (deleteMarked) return;
        var disposition = new FileDispositionInfo { DeleteFile = true };
        if (!SetFileInformationByHandle(stream.SafeFileHandle, FileInfoByHandleClass.FileDispositionInfo, ref disposition, (uint)Marshal.SizeOf<FileDispositionInfo>()))
            throw new IOException($"Handle-bound delete failed; win32={Marshal.GetLastWin32Error()}");
        deleteMarked = true;
    }

    public void Dispose() => stream.Dispose();

    internal static bool TryCreateHardLinkForTests(string newLink, string existing)
        => OperatingSystem.IsWindows() && CreateHardLinkW(newLink, existing, IntPtr.Zero);

    [StructLayout(LayoutKind.Sequential)]
    private struct ByHandleFileInformation
    {
        public uint FileAttributes;
        public System.Runtime.InteropServices.ComTypes.FILETIME CreationTime;
        public System.Runtime.InteropServices.ComTypes.FILETIME LastAccessTime;
        public System.Runtime.InteropServices.ComTypes.FILETIME LastWriteTime;
        public uint VolumeSerialNumber;
        public uint FileSizeHigh;
        public uint FileSizeLow;
        public uint NumberOfLinks;
        public uint FileIndexHigh;
        public uint FileIndexLow;
    }


    [StructLayout(LayoutKind.Sequential)]
    private struct FileStandardInfo
    {
        public long AllocationSize;
        public long EndOfFile;
        public uint NumberOfLinks;
        [MarshalAs(UnmanagedType.U1)] public bool DeletePending;
        [MarshalAs(UnmanagedType.U1)] public bool Directory;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct FileDispositionInfo
    {
        [MarshalAs(UnmanagedType.U1)] public bool DeleteFile;
    }

    private enum FileInfoByHandleClass
    {
        FileBasicInfo = 0,
        FileStandardInfo = 1,
        FileNameInfo = 2,
        FileRenameInfo = 3,
        FileDispositionInfo = 4
    }

    [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    private static extern SafeFileHandle CreateFileW(string fileName, uint desiredAccess, uint shareMode, IntPtr securityAttributes, uint creationDisposition, uint flagsAndAttributes, IntPtr templateFile);

    [DllImport("kernel32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool GetFileInformationByHandle(SafeFileHandle file, out ByHandleFileInformation info);

    [DllImport("kernel32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool GetFileInformationByHandleEx(SafeFileHandle file, FileInfoByHandleClass fileInformationClass, out FileStandardInfo fileInformation, uint bufferSize);

    [DllImport("kernel32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool SetFileInformationByHandle(SafeFileHandle file, FileInfoByHandleClass fileInformationClass, ref FileDispositionInfo fileInformation, uint bufferSize);

    [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool CreateHardLinkW(string fileName, string existingFileName, IntPtr securityAttributes);
}

internal sealed record ProcessHotspot(string Name, int Id, long WorkingSetBytes, double TotalCpuSeconds);
internal sealed record PerformanceSnapshot(
    DateTime CapturedUtc,
    ulong TotalMemoryBytes,
    ulong AvailableMemoryBytes,
    uint MemoryLoadPercent,
    int ProcessCount,
    TimeSpan Uptime,
    List<ProcessHotspot> TopMemoryProcesses,
    string Assessment);

internal static class PerformanceDiagnostics
{
    public static PerformanceSnapshot Capture()
    {
        var m = new MemoryStatusEx { Length = (uint)Marshal.SizeOf<MemoryStatusEx>() };
        if (!GlobalMemoryStatusEx(ref m)) throw new IOException("GlobalMemoryStatusEx failed");
        var hot = new List<ProcessHotspot>();
        Process[] processes;
        try { processes = Process.GetProcesses(); } catch { processes = Array.Empty<Process>(); }
        foreach (var p in processes)
        {
            try { hot.Add(new ProcessHotspot(p.ProcessName, p.Id, Math.Max(0, p.WorkingSet64), Math.Max(0, p.TotalProcessorTime.TotalSeconds))); }
            catch { }
            finally { p.Dispose(); }
        }
        hot = hot.OrderByDescending(x => x.WorkingSetBytes).Take(12).ToList();
        var assessment = m.MemoryLoad >= 90 ? "CRITICAL_MEMORY_PRESSURE" : m.MemoryLoad >= 80 ? "HIGH_MEMORY_PRESSURE" : "NORMAL";
        return new PerformanceSnapshot(DateTime.UtcNow, m.TotalPhys, m.AvailPhys, m.MemoryLoad, processes.Length, TimeSpan.FromMilliseconds(Environment.TickCount64), hot, assessment);
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
    private struct MemoryStatusEx
    {
        public uint Length;
        public uint MemoryLoad;
        public ulong TotalPhys;
        public ulong AvailPhys;
        public ulong TotalPageFile;
        public ulong AvailPageFile;
        public ulong TotalVirtual;
        public ulong AvailVirtual;
        public ulong AvailExtendedVirtual;
    }

    [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool GlobalMemoryStatusEx(ref MemoryStatusEx lpBuffer);
}

internal sealed record SpaceOpportunity(string Name, string Path, long ObservedBytes, string Policy, string Rationale, bool MeasurementBounded);
internal sealed class AdvancedSpaceSnapshot
{
    public DateTime CapturedUtc { get; set; } = DateTime.UtcNow;
    public List<SpaceOpportunity> Opportunities { get; set; } = new();
    public long ReviewOnlyObservedBytes => Opportunities.Where(x => x.Policy != "DO_NOT_TOUCH").Sum(x => Math.Max(0, x.ObservedBytes));
}

internal static class AdvancedSpaceAnalyzer
{
    public static AdvancedSpaceSnapshot Capture()
    {
        var r = new AdvancedSpaceSnapshot();
        var windows = Environment.GetFolderPath(Environment.SpecialFolder.Windows);
        var root = Path.GetPathRoot(windows) ?? "C:\\";
        var profile = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
        var local = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);

        AddFile(r, "HIBERNATION_FILE", Path.Combine(root, "hiberfil.sys"), "REVIEW_ONLY_FEATURE_TRADEOFF", "Can be large, but disabling hibernation also affects Hibernate/Fast Startup; never automatic.");
        AddFile(r, "FULL_MEMORY_DUMP", Path.Combine(windows, "MEMORY.DMP"), "REVIEW_ONLY_DIAGNOSTIC", "Crash-dump evidence may be needed for diagnosis; never automatic.");
        AddDirectory(r, "WINDOWS_OLD", Path.Combine(root, "Windows.old"), "WINDOWS_SUPPORTED_CLEANUP_ONLY", "Previous Windows installation; inspect only and use supported Windows cleanup paths.");
        AddDirectory(r, "RECYCLE_BIN", Path.Combine(root, "$Recycle.Bin"), "REVIEW_ONLY_USER_RECOVERY", "Recycle Bin is user-recoverable data; never emptied automatically.");
        AddDirectory(r, "PIP_CACHE", Path.Combine(local, "pip", "Cache"), "REBUILDABLE_REVIEW", "Python package download/build cache; reclaimable but may require future downloads.");
        AddDirectory(r, "NPM_CACHE", Path.Combine(local, "npm-cache"), "REBUILDABLE_REVIEW", "npm cache; reclaimable but may require future downloads.");
        AddDirectory(r, "NUGET_PACKAGES", Path.Combine(profile, ".nuget", "packages"), "REBUILDABLE_REVIEW", "NuGet global packages can be restored, but deleting them can disrupt offline builds.");
        AddDirectory(r, "GRADLE_CACHE", Path.Combine(profile, ".gradle", "caches"), "REBUILDABLE_REVIEW", "Gradle cache is rebuildable but can be expensive to re-download/recompute.");
        AddDirectory(r, "MAVEN_REPOSITORY", Path.Combine(profile, ".m2", "repository"), "REBUILDABLE_REVIEW", "Maven local repository is rebuildable, but clearing it can disrupt offline builds and trigger large downloads.");
        AddDirectory(r, "CARGO_REGISTRY", Path.Combine(profile, ".cargo", "registry"), "REBUILDABLE_REVIEW", "Cargo registry/cache is rebuildable; review before cleanup to avoid unnecessary downloads.");
        AddDirectory(r, "GO_BUILD_CACHE", Path.Combine(local, "go-build"), "REBUILDABLE_REVIEW", "Go build cache is rebuildable; review-only because active toolchains may be using it.");
        AddDirectory(r, "YARN_CACHE", Path.Combine(local, "Yarn", "Cache"), "REBUILDABLE_REVIEW", "Yarn cache is rebuildable; review-only by default.");
        AddDirectory(r, "PNPM_STORE", Path.Combine(local, "pnpm", "store"), "REBUILDABLE_REVIEW", "pnpm store can be large and shared by projects; never auto-pruned without package-manager-aware policy.");

        // Virtual disks are frequently multi-GB but contain live filesystems. They are high-value
        // space signals only and are never deleted/compressed directly by DiskGuardSpace.
        AddFile(r, "DOCKER_WSL_DATA_VHDX", Path.Combine(local, "Docker", "wsl", "data", "ext4.vhdx"), "VIRTUAL_DISK_REVIEW_ONLY", "Docker Desktop data disk may contain images/volumes; use Docker-aware cleanup, never direct file deletion.");
        AddFile(r, "DOCKER_DATA_VHDX", Path.Combine(local, "Docker", "wsl", "disk", "docker_data.vhdx"), "VIRTUAL_DISK_REVIEW_ONLY", "Docker Desktop virtual disk may contain images/volumes; direct deletion is forbidden.");
        AddWslVirtualDisks(r, local);

        AddDirectory(r, "WINDOWS_UPDATE_DOWNLOAD", Path.Combine(windows, "SoftwareDistribution", "Download"), "DO_NOT_TOUCH", "Measured only. DiskGuardSpace never directly deletes Windows Update service data.");
        AddDirectory(r, "WINDOWS_INSTALLER", Path.Combine(windows, "Installer"), "DO_NOT_TOUCH", "Installer cache is measured only and is explicitly protected from cleanup.");
        return r;
    }

    private static void AddWslVirtualDisks(AdvancedSpaceSnapshot r, string local)
    {
        var packages = Path.Combine(local, "Packages");
        if (!Directory.Exists(packages) || SafetyPolicy.IsReparsePoint(packages)) return;
        try
        {
            int seen = 0;
            foreach (var pkg in Directory.EnumerateDirectories(packages))
            {
                if (++seen > 5000) break;
                if (SafetyPolicy.IsReparsePoint(pkg)) continue;
                var vhdx = Path.Combine(pkg, "LocalState", "ext4.vhdx");
                if (!File.Exists(vhdx) || SafetyPolicy.IsReparsePoint(vhdx)) continue;
                var name = "WSL_VHDX_" + Path.GetFileName(pkg);
                AddFile(r, name, vhdx, "VIRTUAL_DISK_REVIEW_ONLY", "WSL distribution virtual disk contains a live Linux filesystem; direct deletion/compression is forbidden.");
            }
        }
        catch { }
    }

    private static void AddFile(AdvancedSpaceSnapshot r, string name, string path, string policy, string rationale)
    {
        try
        {
            var fi = new FileInfo(path);
            if (fi.Exists && !SafetyPolicy.IsReparsePoint(path))
            {
                var allocated = NtfsAllocationProbe.GetAllocatedBytesOrLogical(path, fi.Length, out _);
                r.Opportunities.Add(new SpaceOpportunity(name, path, Math.Max(0, allocated), policy, rationale, false));
            }
        }
        catch { }
    }

    private static void AddDirectory(AdvancedSpaceSnapshot r, string name, string path, string policy, string rationale)
    {
        if (!Directory.Exists(path) || SafetyPolicy.IsReparsePoint(path)) return;
        var (bytes, _, bounded) = BoundedDirectorySizer.Measure(path, 100_000, TimeSpan.FromSeconds(8));
        r.Opportunities.Add(new SpaceOpportunity(name, path, bytes, policy, rationale, bounded));
    }
}

internal static class BoundedDirectorySizer
{
    public static (long Bytes, long Files, bool Bounded) Measure(string root, int maxFiles, TimeSpan maxTime)
    {
        long bytes = 0, files = 0;
        bool bounded = false;
        var sw = Stopwatch.StartNew();
        var stack = new Stack<string>();
        stack.Push(Path.GetFullPath(root));
        while (stack.Count > 0)
        {
            if (files >= maxFiles || sw.Elapsed > maxTime) { bounded = true; break; }
            var dir = stack.Pop();
            if (SafetyPolicy.IsReparsePoint(dir)) continue;
            try
            {
                foreach (var f in Directory.EnumerateFiles(dir))
                {
                    if (files >= maxFiles || sw.Elapsed > maxTime) { bounded = true; break; }
                    try
                    {
                        if (SafetyPolicy.IsReparsePoint(f)) continue;
                        var fi = new FileInfo(f);
                        bytes += Math.Max(0, NtfsAllocationProbe.GetAllocatedBytesOrLogical(f, fi.Length, out _));
                        files++;
                    }
                    catch { }
                }
                if (bounded) break;
                foreach (var d in Directory.EnumerateDirectories(dir))
                    if (!SafetyPolicy.IsReparsePoint(d)) stack.Push(d);
            }
            catch { bounded = true; }
        }
        return (bytes, files, bounded);
    }
}

internal sealed record DiagnosticCommandResult(string Name, bool Succeeded, int ExitCode, string CommandLine, string Output, string Error, bool ReadOnly);
internal sealed class MaintenanceDiagnosticsSnapshot
{
    public DateTime CapturedUtc { get; set; } = DateTime.UtcNow;
    public bool DeepHealthRequested { get; set; }
    public List<DiagnosticCommandResult> Commands { get; set; } = new();
}

internal static class ReadOnlyMaintenanceDiagnostics
{
    public static MaintenanceDiagnosticsSnapshot Capture(bool deepHealth)
    {
        var r = new MaintenanceDiagnosticsSnapshot { DeepHealthRequested = deepHealth };
        var windows = Environment.GetFolderPath(Environment.SpecialFolder.Windows);
        var dism = Path.Combine(windows, "System32", "dism.exe");
        var compact = Path.Combine(windows, "System32", "compact.exe");
        var powercfg = Path.Combine(windows, "System32", "powercfg.exe");
        var vssadmin = Path.Combine(windows, "System32", "vssadmin.exe");
        var defrag = Path.Combine(windows, "System32", "defrag.exe");
        if (File.Exists(dism))
        {
            r.Commands.Add(Run("DISM_CHECK_HEALTH", dism, "/Online /Cleanup-Image /CheckHealth", 10 * 60 * 1000));
            r.Commands.Add(Run("DISM_ANALYZE_COMPONENT_STORE", dism, "/Online /Cleanup-Image /AnalyzeComponentStore", 15 * 60 * 1000));
        }
        if (File.Exists(compact)) r.Commands.Add(Run("COMPACT_OS_QUERY", compact, "/CompactOS:query", 2 * 60 * 1000));
        if (File.Exists(powercfg))
        {
            r.Commands.Add(Run("POWER_CAPABILITIES", powercfg, "/a", 2 * 60 * 1000));
            r.Commands.Add(Run("POWER_ACTIVE_SCHEME", powercfg, "/getactivescheme", 2 * 60 * 1000));
        }
        if (File.Exists(vssadmin)) r.Commands.Add(Run("VSS_SHADOW_STORAGE", vssadmin, "list shadowstorage", 2 * 60 * 1000));
        if (File.Exists(defrag))
        {
            var drive = (Path.GetPathRoot(windows) ?? "C:\\").TrimEnd('\\');
            r.Commands.Add(Run("DEFRAG_ANALYZE", defrag, $"{drive} /A /V", 10 * 60 * 1000));
        }

        if (deepHealth)
        {
            var sfc = Path.Combine(windows, "System32", "sfc.exe");
            var chkdsk = Path.Combine(windows, "System32", "chkdsk.exe");
            if (File.Exists(sfc)) r.Commands.Add(Run("SFC_VERIFY_ONLY", sfc, "/verifyonly", 35 * 60 * 1000));
            if (File.Exists(chkdsk))
            {
                var drive = (Path.GetPathRoot(windows) ?? "C:\\").TrimEnd('\\');
                r.Commands.Add(Run("CHKDSK_SCAN", chkdsk, $"{drive} /scan", 35 * 60 * 1000));
            }
        }
        return r;
    }

    internal static bool DiagnosticExecutablePathMatchesPolicyForTests(string exe, string windowsRoot)
    {
        try
        {
            if (!Path.IsPathFullyQualified(exe) || !Path.IsPathFullyQualified(windowsRoot)) return false;
            var system32 = Path.Combine(windowsRoot, "System32");
            return SafetyPolicy.IsUnderRoot(exe, system32);
        }
        catch { return false; }
    }

    private static DiagnosticCommandResult Run(string name, string exe, string args, int timeoutMs)
    {
        // Hard fail if a future edit tries to turn a read-only diagnostic into a repair operation.
        var forbidden = new[] { "/RestoreHealth", "/scannow", " /f", " /r", "/offlinescanandfix", "delete shadows", "resize shadowstorage", " /O", " /L", " /K", " /G" };
        if (forbidden.Any(x => args.Contains(x, StringComparison.OrdinalIgnoreCase)))
            throw new SafetyBlockException($"Forbidden repair flag in read-only diagnostic: {args}");
        try
        {
            var windows = Environment.GetFolderPath(Environment.SpecialFolder.Windows);
            if (!DiagnosticExecutablePathMatchesPolicyForTests(exe, windows) || !File.Exists(exe))
                return new DiagnosticCommandResult(name, false, -1, $"{Path.GetFileName(exe)} {args}", "", "BLOCKED_UNTRUSTED_EXECUTABLE_PATH", true);

            var psi = new ProcessStartInfo(exe, args) { UseShellExecute = false, RedirectStandardOutput = true, RedirectStandardError = true, CreateNoWindow = true };
            using var p = Process.Start(psi) ?? throw new IOException("diagnostic process start failed");
            var o = p.StandardOutput.ReadToEndAsync();
            var e = p.StandardError.ReadToEndAsync();
            if (!p.WaitForExit(timeoutMs))
            {
                try { p.Kill(entireProcessTree: true); } catch { }
                return new DiagnosticCommandResult(name, false, -1, $"{Path.GetFileName(exe)} {args}", "", "TIMEOUT", true);
            }
            return new DiagnosticCommandResult(name, p.ExitCode == 0, p.ExitCode, $"{Path.GetFileName(exe)} {args}", Trim(o.GetAwaiter().GetResult()), Trim(e.GetAwaiter().GetResult()), true);
        }
        catch (Exception ex)
        {
            return new DiagnosticCommandResult(name, false, -1, $"{Path.GetFileName(exe)} {args}", "", ex.Message, true);
        }
    }

    private static string Trim(string s) => s.Length <= 24_000 ? s : s[..24_000] + "\n...[truncated]";
}
