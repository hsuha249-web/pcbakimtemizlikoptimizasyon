param(
    [string]$ExePath = "",
    [string]$ProofPath = "",
    [switch]$RunSelfTest
)
$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
if (-not $ExePath) { $ExePath = Join-Path $Root "dist\DiskGuardSpace.exe" }
if (-not $ProofPath) { $ProofPath = Join-Path $Root "dist\RELEASE_PROOF.json" }

function Fail([string]$m) { Write-Host "RELEASE VERIFY: FAIL - $m" -ForegroundColor Red; exit 2 }

if (-not (Test-Path $ExePath -PathType Leaf)) { Fail "EXE missing: $ExePath" }
if (-not (Test-Path $ProofPath -PathType Leaf)) { Fail "Proof missing: $ProofPath" }

try { $p = Get-Content $ProofPath -Raw | ConvertFrom-Json } catch { Fail "Proof JSON is invalid." }
if ($p.schema -ne "DiskGuardSpace.ReleaseProof.v1") { Fail "Unexpected proof schema." }
if ($p.product -ne "DiskGuardSpace" -or $p.version -ne "1.4") { Fail "Product/version mismatch." }
if ($p.result -ne "VERIFIED_PASS") { Fail "Release proof does not claim VERIFIED_PASS." }
if ($p.targetRid -ne "win-x64" -or $p.framework -ne "net8.0") { Fail "Runtime target mismatch." }
if (-not $p.selfContained -or -not $p.singleFile) { Fail "Single-file/self-contained contract not proven." }

$actualHash = (Get-FileHash $ExePath -Algorithm SHA256).Hash.ToLowerInvariant()
if ($actualHash -ne ([string]$p.exeSha256).ToLowerInvariant()) { Fail "EXE SHA-256 mismatch." }
if ((Get-Item $ExePath).Length -ne [long]$p.exeSizeBytes) { Fail "EXE size mismatch." }

$manifest = Join-Path $Root "SOURCE_MANIFEST.sha256"
if (-not (Test-Path $manifest)) { Fail "Source manifest missing." }
$manifestHash = (Get-FileHash $manifest -Algorithm SHA256).Hash.ToLowerInvariant()
if ($manifestHash -ne ([string]$p.sourceManifestSha256).ToLowerInvariant()) { Fail "Source manifest identity mismatch." }

$requiredGates = @(
    'strictSourceManifest','staticAudit','isolatedPublish','packagedSelfTest',
    'packagedNegativeTests','readOnlyPcProof','controllerNativeGui','pendingByteIdentity','pendingRegression','atomicPromotion'
)
foreach ($g in $requiredGates) {
    $prop = $p.gates.PSObject.Properties[$g]
    if ($null -eq $prop -or $prop.Value -ne 'PASS') { Fail "Gate not PASS: $g" }
}

if ($RunSelfTest) {
    & $ExePath self-test
    if ($LASTEXITCODE -ne 0) { Fail "Release EXE self-test failed." }
    & $ExePath negative-tests
    if ($LASTEXITCODE -ne 0) { Fail "Release EXE negative/regression tests failed." }
}

Write-Host "RELEASE VERIFY: VERIFIED_PASS" -ForegroundColor Green
Write-Host "EXE SHA256: $actualHash"
exit 0
