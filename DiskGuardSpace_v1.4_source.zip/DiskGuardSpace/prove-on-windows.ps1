param(
    [switch]$SkipBuild,
    [string]$ExePath = "",
    [string]$ProofDir = ""
)
$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $Root

if (-not $SkipBuild) {
    & .\build-win-x64.ps1
    if ($LASTEXITCODE -ne 0) { throw "developer build failed" }
}
if (-not $ExePath) { $ExePath = Join-Path $Root "bin\Release\net8.0\win-x64\publish\DiskGuardSpace.exe" }
$Exe = [IO.Path]::GetFullPath($ExePath)
if (-not (Test-Path $Exe -PathType Leaf)) { throw "EXE not found: $Exe" }

$stamp = Get-Date -Format "yyyyMMdd-HHmmss"
if (-not $ProofDir) { $ProofDir = Join-Path $Root "proof-$stamp" }
$ProofDir = [IO.Path]::GetFullPath($ProofDir)
New-Item -ItemType Directory -Force -Path $ProofDir | Out-Null
$scanReport = Join-Path $ProofDir "proof-scan.json"
$analysisReport = Join-Path $ProofDir "proof-analysis.json"
$autoDryReport = Join-Path $ProofDir "proof-auto-care-dry.json"
$summaryPath = Join-Path $ProofDir "PROOF_SUMMARY.json"

Write-Host "`n[PROOF 1] Isolated positive self-test" -ForegroundColor Cyan
& $Exe self-test
if ($LASTEXITCODE -ne 0) { throw "self-test failed" }

Write-Host "`n[PROOF 2] Negative/fail-closed tests" -ForegroundColor Cyan
& $Exe negative-tests
if ($LASTEXITCODE -ne 0) { throw "negative tests failed" }

Write-Host "`n[PROOF 3] Read-only safe scan" -ForegroundColor Cyan
& $Exe scan --min-age-days 7 --report $scanReport
if ($LASTEXITCODE -ne 0) { throw "safe scan failed closed" }

Write-Host "`n[PROOF 4] Independent safe report verification" -ForegroundColor Cyan
& $Exe verify-report $scanReport
if ($LASTEXITCODE -ne 0) { throw "safe report verification failed" }

Write-Host "`n[PROOF 5] Read-only deep analysis" -ForegroundColor Cyan
& $Exe analyze-deep --min-size-mib 500 --duplicate-min-mib 10 --top 100 --report $analysisReport
if ($LASTEXITCODE -ne 0) { throw "deep analysis had fail-closed violations" }

Write-Host "`n[PROOF 6] Independent deep-analysis verification" -ForegroundColor Cyan
& $Exe verify-analysis $analysisReport
if ($LASTEXITCODE -ne 0) { throw "analysis verification failed" }

Write-Host "`n[PROOF 7] PC-specific auto-care dry run" -ForegroundColor Cyan
& $Exe auto-care --report $autoDryReport --work-dir (Join-Path $ProofDir "autocare-dry")
if ($LASTEXITCODE -ne 0) { throw "auto-care dry-run failed closed" }

Write-Host "`n[PROOF 8] Independent auto-care verification" -ForegroundColor Cyan
& $Exe verify-auto-care $autoDryReport
if ($LASTEXITCODE -ne 0) { throw "auto-care verification failed" }

$hashes = [ordered]@{}
foreach ($f in @($Exe,$scanReport,$analysisReport,$autoDryReport)) {
    $hashes[[IO.Path]::GetFileName($f)] = (Get-FileHash $f -Algorithm SHA256).Hash.ToLowerInvariant()
}
$summary = [ordered]@{
    schema = "DiskGuardSpace.PcProof.v1"
    result = "PASS"
    createdUtc = (Get-Date).ToUniversalTime().ToString("o")
    writesPerformed = $false
    executable = $Exe
    hashes = $hashes
    gates = [ordered]@{
        selfTest = "PASS"
        negativeTests = "PASS"
        safeScan = "PASS"
        safeReportVerify = "PASS"
        deepAnalysis = "PASS"
        deepAnalysisVerify = "PASS"
        autoCareDryRun = "PASS"
        autoCareDryVerify = "PASS"
    }
}
$summary | ConvertTo-Json -Depth 8 | Set-Content -Encoding UTF8 $summaryPath

Write-Host "`nPROOF RUN: PASS" -ForegroundColor Green
Write-Host "No cleanup/write maintenance was executed by this proof script." -ForegroundColor Yellow
Write-Host "Summary: $summaryPath"
exit 0
