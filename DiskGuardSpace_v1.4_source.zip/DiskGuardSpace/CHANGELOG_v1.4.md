# DiskGuardSpace v1.4 changelog

## Native maintenance dashboard

The verified controller is now also the normal user-facing maintenance dashboard. It preserves the exact read-only verification button required by the release controller proof, while adding PC analysis, safe cleanup, full auto-care, performance care, 40 GiB fail-closed space-plan generation/application, proof/run-folder access, and verified startup-maintenance installation. Write actions require the adjacent `RELEASE_PROOF.json` to match the running EXE and launch through UAC.

## Automatic cadence policy

The verified startup task runs at user logon with a five-minute delay and Highest run level. Safe allowlisted cleanup and lightweight diagnostics are eligible on every boot. Delivery Optimization cleanup remains capped to once per 24 hours; drive `/O` optimization to once per 7 days; DISM StartComponentCleanup to once per 14 days. Deep space analysis runs at most once per 3 days, deep read-only SFC/CHKDSK health checks at most once per 14 days, and full packaged self/negative verification every 7 days or whenever the EXE changes.

The task remains once-per-boot, hidden, fail-closed, and `IgnoreNew`. A failed or unverified stage is skipped or blocks writes according to the existing global/feature-specific safety gates.
