# DiskGuardSpace v0.9 changelog

## Primary focus

Disk-space recovery remains the permanent first priority. v0.9 concentrates on stronger volume identity, bounded I/O work, truthful free-space proof, durable maintenance state, and storage-health negative controls.

## Changes

- Cleanup authorization is now bound to the Windows volume GUID identity rather than drive-letter equality alone.
- Cross-volume quarantine must prove both source and destination volume identities and rejects an unprovable or same-volume destination.
- Automatic cleanup now has both whole-run and per-category byte/file blast-radius limits.
- Safe candidates are still ordered by allocated bytes so the largest verified reclaim is attempted first inside those limits.
- Free-space evidence compares handle-bound allocated bytes removed with observed system-volume free-space change. Large disagreement becomes `CONCURRENT_VOLUME_ACTIVITY` and forces bounded proof rather than an exact claim.
- Apply mode performs a small write/read/fsync/delete durability probe in the protected DiskGuardSpace state directory before maintenance is authorized.
- Recent Windows System log storage/filesystem I/O events are collected read-only. One targeted event defers heavy maintenance; repeated events globally block write maintenance.
- Duplicate full SHA-256 analysis now has a 64 GiB / 512-file work budget. Budget exhaustion is disclosed as bounded deep analysis rather than silently continuing without limit.
- Product, assembly, and controlled-release versions advanced to 0.9.
- Negative/regression coverage expanded for volume identity, category blast radius, proof drift, state-store durability, storage-event gates, and duplicate hashing budgets.
