@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title DiskGuardSpace v1.4 - First Run
if not exist "%~dp0logs" mkdir "%~dp0logs" >nul 2>&1
set "LOG=%~dp0logs\FIRST_RUN_LAST.log"

echo DiskGuardSpace v1.4 first run baslatiliyor...
echo Log: %LOG%
echo.
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0FIRST_RUN.ps1" >"%LOG%" 2>&1
set "EC=%ERRORLEVEL%"
type "%LOG%"
echo.
if "%EC%"=="0" (
  echo FIRST RUN: PASS
) else (
  echo FIRST RUN: FAIL-CLOSED ^(exit %EC%^)
  echo Hata kaydi: %LOG%
)
echo.
echo Bu pencere hata olsa bile otomatik kapanmaz.
pause
exit /b %EC%
