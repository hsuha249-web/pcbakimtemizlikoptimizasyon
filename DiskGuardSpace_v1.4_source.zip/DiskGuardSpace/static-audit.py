from pathlib import Path
import hashlib, re, sys

ROOT = Path(__file__).resolve().parent
files = {p.name: p.read_text(encoding='utf-8') for p in ROOT.glob('*.cs')}
ps = {p.name: p.read_text(encoding='utf-8') for p in ROOT.glob('*.ps1')}
all_cs = '\n'.join(files.values())
all_ps = '\n'.join(ps.values())
checks=[]

def check(name, cond, detail=''):
    checks.append((name, bool(cond), detail))

# Required architecture
check('auto-care command exists', '"auto-care" => AutoCareRunner.Run' in files.get('Program.cs',''))
check('independent auto-care verifier exists', 'verify-auto-care' in files.get('Program.cs','') and 'public static int Verify' in files.get('AutoCare.cs',''))
check('disk space fixed as primary priority', 'PrimaryPriority { get; set; } = "DISK_SPACE"' in files.get('AutoCare.cs',''))
check('negative tests command exists', 'negative-tests' in files.get('Program.cs','') and 'internal static class NegativeTests' in files.get('NegativeTests.cs',''))
check('first run invokes automated installer', '.\\INSTALL_AND_RUN.ps1' in ps.get('FIRST_RUN.ps1',''))
check('verified release pipeline runs before apply', ps.get('INSTALL_AND_RUN.ps1','').find('BUILD_VERIFIED_EXE.ps1') >= 0 and ps.get('INSTALL_AND_RUN.ps1','').find('BUILD_VERIFIED_EXE.ps1') < ps.get('INSTALL_AND_RUN.ps1','').find('auto-care --apply'))
check('automatic apply occurs after proof', 'auto-care --apply' in ps.get('INSTALL_AND_RUN.ps1',''))
check('UAC elevation path exists', '-Verb RunAs' in ps.get('INSTALL_AND_RUN.ps1',''))
check('first-run elevation uses canonical System32 PowerShell', 'System32\\WindowsPowerShell\\v1.0\\powershell.exe' in ps.get('INSTALL_AND_RUN.ps1','') and 'refusing PATH-based elevation' in ps.get('INSTALL_AND_RUN.ps1',''))
check('space-plan command exists', '"plan-space" => SpacePlanRunner.Plan' in files.get('Program.cs','') and 'apply-space-plan' in files.get('Program.cs',''))
check('space-plan requires explicit confirmation', 'SPACE_PLAN_APPLY' in files.get('SpacePlan.cs','') and 'Hashing.Sha256' in files.get('SpacePlan.cs',''))
check('Update Guard is opt-in', 'UPDATE_GUARD_RISK' in files.get('UpdateGuard.cs','') and 'GuardEnabled' in files.get('UpdateGuard.cs',''))
check('Update Guard schedules boot and bounded repetition', 'BootTrigger' in files.get('UpdateGuard.cs','') and 'Append("H</Interval>' in files.get('UpdateGuard.cs','') and 'Append(hours)' in files.get('UpdateGuard.cs',''))
check('Update Guard records/restores owned state', 'OriginalStart_' in files.get('UpdateGuard.cs','') and 'RestoreServices' in files.get('UpdateGuard.cs',''))

# Safety gates
check('no arbitrary delete-path CLI switch', '--delete-path' not in all_cs and '--path-to-delete' not in all_cs)
check('reparse point checks exist', 'IsReparsePoint' in files.get('Program.cs',''))
check('changed-since-scan gate exists', 'File changed since scan' in files.get('Program.cs',''))
check('handle-bound verified delete exists', 'VerifiedWindowsFile.OpenAndVerify' in files.get('Program.cs','') and 'SetFileInformationByHandle' in files.get('AdvancedMaintenance.cs',''))
check('same-volume quarantine refused', 'quarantine must be on a different Windows volume identity' in files.get('Program.cs',''))
check('full SHA-256 duplicate confirmation exists', 'Hashing.Sha256(entry.Path)' in files.get('Program.cs',''))
check('System32 forbidden cleanup root', '"System32"' in files.get('Program.cs','') and 'IsForbiddenCleanupRoot' in files.get('Program.cs',''))
check('browser process feature skips exist', 'chrome' in files.get('AutoCare.cs','') and 'FIREFOX_CACHE' in files.get('AutoCare.cs',''))
check('physical disk health gate exists', 'physical-disk-health' in files.get('AutoCare.cs','') and 'Unhealthy' in files.get('AutoCare.cs',''))
check('pending servicing reboot gate exists', 'HasPendingServicingReboot' in files.get('AutoCare.cs',''))
check('drive optimize uses media-aware /O', '/O /H /U /V' in files.get('AutoCare.cs',''))
check('component cleanup uses StartComponentCleanup', '/StartComponentCleanup /NoRestart' in files.get('Program.cs',''))

# ResetBase must not occur in executable command construction. It may occur only in help/verifier/docs.
wm = files.get('Program.cs','')
start = wm.find('public static MaintenanceExecution RunStartComponentCleanup()')
end = wm.find('private static string TrimEvidence', start)
component_body = wm[start:end] if start >= 0 and end > start else ''
check('ResetBase absent from DISM execution body', 'ResetBase' not in component_body)

# Windows supported Delivery Optimization API, not direct service-data deletion
check('Delivery Optimization uses supported cmdlet', 'Delete-DeliveryOptimizationCache -Force' in files.get('AutoCare.cs',''))
check('SoftwareDistribution deletion is isolated to Update Guard', 'SoftwareDistribution' not in files.get('Program.cs','') and 'SoftwareDistribution' not in files.get('AutoCare.cs','') and 'SoftwareDistribution' in files.get('UpdateGuard.cs','') and 'IsUnderRoot' in files.get('UpdateGuard.cs',''))
check('Update Guard never touches protected roots', '.codex", "sessions' in files.get('SpacePlan.cs','') and 'bugbounty-platform' in files.get('SpacePlan.cs',''))
check('Update Guard uninstall hook exists', 'update-guard disable' in ps.get('UNINSTALL_STARTUP_AUTOMATION.ps1',''))

# No unsafe auto-deletion of analysis findings
opp = files.get('Program.cs','')
check('large files marked REVIEW_ONLY', '"LARGE_FILE", "REVIEW_ONLY"' in opp)
check('old installers marked REVIEW_ONLY', '"OLD_INSTALLER_OR_ARCHIVE", "REVIEW_ONLY"' in opp)
check('deep analyzer contains no File.Delete', 'File.Delete' not in opp[opp.find('internal static class OpportunityAnalyzer'):opp.find('internal static class DuplicateFinder')])

# Evidence and negative tests
check('master reopens linked evidence', 'EvidenceFileVerified' in files.get('AutoCare.cs','') and 'AnalysisFileVerified' in files.get('AutoCare.cs',''))
check('negative test: path escape', 'prefix-boundary escape rejected' in files.get('NegativeTests.cs',''))
check('negative test: changed file', 'changed-since-scan blocked' in files.get('NegativeTests.cs',''))
check('negative test: locked file', 'exclusive-lock causes fail-closed preservation' in files.get('NegativeTests.cs',''))
check('negative test: quick hash collision', 'quick fingerprint collision resolved by full SHA-256' in files.get('NegativeTests.cs',''))
check('negative test: tampered evidence', 'tampered evidence arithmetic rejected' in files.get('NegativeTests.cs',''))

# v0.4 hardening / optimization
check('TEMP env is not a cleanup authority', 'AddIfDirectory(roots, Path.GetTempPath()' not in files.get('Program.cs','') and 'Never trust TEMP/TMP' in files.get('Program.cs',''))
check('canonical cleanup root validation exists', 'IsCanonicalApprovedRoot' in files.get('Program.cs','') and 'canonical=' in files.get('AutoCare.cs',''))
check('runtime directory protection exists', 'IsRuntimeProtectedPath' in files.get('Program.cs',''))
check('delete is bound to verified kernel handle', 'DELETE_BY_VERIFIED_HANDLE' in files.get('Program.cs','') and 'File.Delete(c.Path)' not in files.get('Program.cs',''))
check('quarantine free-space reserve exists', 'quarantine destination lacks required free-space reserve' in files.get('Program.cs',''))
check('atomic report writer exists', 'internal static class AtomicFile' in files.get('Program.cs','') and 'FileOptions.WriteThrough' in files.get('Program.cs',''))
check('single auto-care instance guard exists', 'SingleInstanceGuard.Acquire' in files.get('AutoCare.cs',''))
check('AC-power drive optimization gate exists', 'ac-power-for-drive-optimization' in files.get('AutoCare.cs',''))
check('critical-low-space optimization gate exists', 'drive-optimization-space-margin' in files.get('AutoCare.cs',''))
check('maintenance timeouts exist', 'exceeded 45 minutes' in files.get('Program.cs','') and 'exceeded 30 minutes' in files.get('AutoCare.cs','') and 'exceeded 10 minutes' in files.get('AutoCare.cs',''))
check('AppData Local deep analysis exists', 'Environment.SpecialFolder.LocalApplicationData' in files.get('Program.cs','') and 'AppData\\Local is often' in files.get('Program.cs',''))
check('bounded deep-analysis budget exists', '300_000' in files.get('Program.cs','') and '120 seconds' in files.get('Program.cs',''))
check('representative compression sampling exists', 'Representative first/middle/last sampling' in files.get('Program.cs',''))
check('linked evidence SHA-256 manifest exists', 'ArtifactSha256' in files.get('AutoCare.cs','') and 'ArtifactHashMatches' in files.get('AutoCare.cs',''))
check('negative test: poisoned TEMP', 'poisoned TEMP/TMP cannot authorize arbitrary cleanup root' in files.get('NegativeTests.cs',''))
check('negative test: runtime self-protection', 'runtime directory is protected from cleanup' in files.get('NegativeTests.cs',''))
check('negative test: writer race', 'existing writer blocks locked verification' in files.get('NegativeTests.cs',''))
check('negative test: invalid hash evidence', 'non-hex SHA-256 evidence rejected' in files.get('NegativeTests.cs',''))
check('negative test: atomic report write', 'atomic report replacement leaves complete final file' in files.get('NegativeTests.cs',''))
check('directory hotspot aggregation exists', 'DirectoryHotspot' in files.get('Program.cs','') and 'BuildDirectoryHotspots' in files.get('Program.cs',''))
check('priority planner can choose AppData hotspot classification', 'APPDATA_HOTSPOT_CLASSIFICATION' in files.get('AutoCare.cs',''))
check('verified bounded analysis supported', 'VERIFIED_ANALYSIS_BOUNDED' in files.get('Program.cs','') and 'StartsWith("VERIFIED_ANALYSIS"' in files.get('AutoCare.cs',''))
check('linked scan status regression fixed', 'StartsWith("VERIFIED_SCAN"' in files.get('AutoCare.cs','') and 'linked read-only scan accepts VERIFIED_SCAN status' in files.get('NegativeTests.cs',''))
check('maintenance verifier regression covered', 'maintenance evidence does not require per-file action rows' in files.get('NegativeTests.cs',''))

# v0.5 multi-technique hardening / maintenance
check('safe-scan read errors are bounded, not global safety violations', 'public int ReadErrors { get; set; }' in files.get('Program.cs','') and 'VERIFIED_SCAN_BOUNDED' in files.get('Program.cs',''))
check('safe cleanup can prove bounded coverage', 'VERIFIED_PASS_BOUNDED' in files.get('Program.cs','') and 'Safe cleanup succeeded for verified candidates' in files.get('AutoCare.cs',''))
adv = files.get('AdvancedMaintenance.cs','')
check('hard-link cleanup rejection exists', 'Hard-linked file rejected' in adv and 'NumberOfLinks != 1' in adv)
check('read-only/system attribute cleanup rejection exists', 'ReadOnly/System attributes are not eligible' in files.get('Program.cs','') and 'FileAttributeSystem' in adv)
check('kernel handle denies write/delete sharing', 'FileShareRead' in adv and 'GenericRead | DeleteAccess' in adv and 'FileFlagOpenReparsePoint' in adv)
check('Electron cache adapters exist', all(x in files.get('Program.cs','') for x in ['VSCODE_CACHE','CURSOR_CACHE','DISCORD_CACHE','SLACK_CACHE']))
check('Electron cache owning-process gates exist', all(x in files.get('AutoCare.cs','') for x in ['("Code", "VSCODE_CACHE")','("Cursor", "CURSOR_CACHE")','("Discord", "DISCORD_CACHE")','("slack", "SLACK_CACHE")']))
check('advanced space snapshot exists', 'AdvancedSpaceAnalyzer.Capture' in files.get('AutoCare.cs','') and 'HIBERNATION_FILE' in adv and 'WINDOWS_OLD' in adv)
check('Windows Update is measured only and do-not-touch', 'WINDOWS_UPDATE_DOWNLOAD' in adv and 'DO_NOT_TOUCH' in adv and 'SoftwareDistribution' not in files.get('Program.cs',''))
check('Windows Installer cache is measured only', 'WINDOWS_INSTALLER' in adv and 'Installer cache is measured only' in adv)
check('developer cache opportunities are review-only', all(x in adv for x in ['PIP_CACHE','NPM_CACHE','NUGET_PACKAGES','GRADLE_CACHE','REBUILDABLE_REVIEW']))
check('bounded advanced directory sizing exists', 'BoundedDirectorySizer' in adv and '100_000' in adv and 'TimeSpan.FromSeconds(8)' in adv)
check('performance memory/process diagnostics exist', 'PerformanceDiagnostics' in adv and 'TopMemoryProcesses' in adv and 'MemoryLoadPercent' in adv)
check('read-only component-store analysis exists', '/AnalyzeComponentStore' in adv and '/CheckHealth' in adv)
check('deep health uses verify-only SFC', '/verifyonly' in adv and '/scannow' in adv and 'forbidden' in adv.lower())
check('deep health uses CHKDSK scan not repair', 'CHKDSK_SCAN' in adv and '$"{drive} /scan"' in adv and '" /f"' in adv)
check('CompactOS is query-only', '/CompactOS:query' in adv and '/CompactOS:always' not in adv)
check('hibernation remains review-only', 'REVIEW_ONLY_FEATURE_TRADEOFF' in adv and 'powercfg.exe -h off' not in all_cs.lower())
check('system disk health probe targets system volume disk', 'Get-Partition -DriveLetter $dl' in files.get('AutoCare.cs','') and 'Get-Disk -ErrorAction Stop' in files.get('AutoCare.cs',''))
check('auto-care schema advanced to 10.0', 'SchemaVersion { get; set; } = "10.0"' in files.get('AutoCare.cs',''))
check('master verifies bounded advanced-space policies', 'advanced-space policies are bounded' in files.get('AutoCare.cs','') and 'Windows Update/Installer stores remain do-not-touch' in files.get('AutoCare.cs',''))
check('negative test: hard-link preserved', 'hard-linked file is rejected and both links preserved' in files.get('NegativeTests.cs',''))
check('negative test: read-only preserved', 'read-only file is fail-closed and preserved' in files.get('NegativeTests.cs',''))
check('negative test: Windows Update direct cleanup absent', 'Windows Update cache is not an approved direct cleanup root' in files.get('NegativeTests.cs',''))
check('negative test: Windows Installer direct cleanup absent', 'Windows Installer cache is not an approved cleanup root' in files.get('NegativeTests.cs',''))

check('master binds report to executable SHA-256', 'ExecutableSha256' in files.get('AutoCare.cs','') and 'report executable SHA-256 matches verifier binary' in files.get('AutoCare.cs',''))
check('diagnostic command lines have strict policy matcher', 'DiagnosticCommandMatchesPolicy' in files.get('AutoCare.cs','') and 'diagnostic command lines match their read-only allow-list policy' in files.get('AutoCare.cs',''))
check('Delivery Optimization support is probed before write stage', 'IsDeliveryOptimizationCleanupSupported' in files.get('AutoCare.cs','') and 'Supported Delivery Optimization cleanup cmdlet unavailable' in files.get('AutoCare.cs',''))
auto = files.get('AutoCare.cs','')
check('deep health is sequenced after space work', auto.find('RunSafeCleanup') < auto.find('ReadOnlyMaintenanceDiagnostics.Capture(true)') and auto.find('RunOrSkipDeepAnalysis(options, sessionDir, report);', auto.find('RunSafeCleanup')) < auto.find('ReadOnlyMaintenanceDiagnostics.Capture(true)'))
check('blocked actions are separated from global violations', 'BlockedActions' in files.get('Program.cs','') and 'FailClosedViolations = scan.FailClosedViolations,' in files.get('Program.cs',''))
check('sharing/access conflicts become local preserved skips', 'err is 5 or 32 or 33' in files.get('AdvancedMaintenance.cs','') and 'File is inaccessible/in-use; preserved' in files.get('AdvancedMaintenance.cs',''))
check('negative test: bounded scan status honesty', 'scan with read errors cannot claim unbounded VERIFIED_SCAN' in files.get('NegativeTests.cs',''))
check('negative test: global violation cannot become bounded success', 'global safety violation cannot be downgraded to bounded success' in files.get('NegativeTests.cs',''))


# v0.6 allocation-aware / adaptive maintenance hardening
storage = files.get('StorageIntelligence.cs','')
check('physical NTFS allocation probe exists', 'GetCompressedFileSizeW' in storage and 'GetAllocatedBytesOrLogical' in storage)
check('handle-bound allocation verification exists', 'GetFileInformationByHandleEx' in adv and 'AllocationBytes' in adv and 'FileStandardInfo' in adv)
check('cleanup evidence separates logical and allocated bytes', 'SourceAllocatedBytesRemoved' in files.get('Program.cs','') and 'CandidateAllocatedBytes' in files.get('Program.cs',''))
check('duplicate analysis has physical savings accounting', 'DuplicatePhysicalPotentialSavingsBytes' in files.get('Program.cs','') and 'FileAllocatedBytes' in files.get('Program.cs',''))
check('compression analysis skips already space-efficient attributes', all(x in files.get('Program.cs','') for x in ['FileAttributes.Compressed','FileAttributes.SparseFile','FileAttributes.Encrypted']))
check('directory sizing uses allocated bytes', 'NtfsAllocationProbe.GetAllocatedBytesOrLogical' in adv and 'BoundedDirectorySizer' in adv)
check('space-pressure policy exists', 'SpacePressurePolicy' in storage and 'EMERGENCY' in storage and 'HEALTHY' in storage)
check('heavy-maintenance cooldown journal exists', 'MaintenanceCooldownJournal' in storage and 'cooldown' in storage.lower())
check('drive optimization cooldown is enforced', 'ShouldSkip("DRIVE_OPTIMIZATION"' in files.get('AutoCare.cs',''))
check('space-reclaim cooldown can bypass only under low pressure', 'bypassForCriticalSpace' in storage and 'COMPONENT_CLEANUP' in files.get('AutoCare.cs',''))
check('high memory pressure skips drive optimization', 'memory-pressure-for-drive-optimization' in files.get('AutoCare.cs',''))
check('ADS/device path syntax negative control exists', 'HasUnsafePathSyntax' in files.get('Program.cs','') and 'alternate-data-stream' in files.get('NegativeTests.cs',''))
check('persistent DiskGuardSpace state tree is self-protected', 'stateDir' in files.get('Program.cs','') and 'persistent evidence/state tree is self-protected' in files.get('NegativeTests.cs',''))
check('VSS shadow storage is query-only', 'VSS_SHADOW_STORAGE' in adv and 'list shadowstorage' in adv and 'delete shadows' in adv)
check('defrag analysis is read-only diagnostic', 'DEFRAG_ANALYZE' in adv and ' /A /V' in adv)
check('active power scheme is queried read-only', 'POWER_ACTIVE_SCHEME' in adv and '/getactivescheme' in adv)
check('virtual disks are review-only', 'VIRTUAL_DISK_REVIEW_ONLY' in adv and 'WSL_VHDX_' in adv and 'DOCKER_DATA_VHDX' in adv)
check('no direct VHDX delete path exists', '.vhdx' not in files.get('Program.cs','').lower() or 'File.Delete' not in files.get('Program.cs','')[files.get('Program.cs','').find('internal static class OpportunityAnalyzer'):files.get('Program.cs','').find('internal static class DuplicateFinder')])
check('additional package caches are review-only', all(x in adv for x in ['MAVEN_REPOSITORY','CARGO_REGISTRY','GO_BUILD_CACHE','YARN_CACHE','PNPM_STORE']))
check('negative test: physical evidence tamper', 'tampered physical-allocation evidence rejected' in files.get('NegativeTests.cs',''))
check('negative test: physical duplicate tamper', 'tampered physical duplicate-savings arithmetic rejected' in files.get('NegativeTests.cs',''))
check('negative test: allocation fallback bounded honesty', 'allocation-probe fallback is disclosed as bounded analysis' in files.get('NegativeTests.cs','') and 'allocation-probe fallback cannot claim exact analysis' in files.get('NegativeTests.cs',''))
check('negative test: cooldown future timestamp', 'future cooldown timestamp fail-closes heavy maintenance' in files.get('NegativeTests.cs',''))
check('negative test: virtual disk direct cleanup absent', 'virtual-disk files can never become direct cleanup roots' in files.get('NegativeTests.cs',''))
check('negative test: mutating VSS command rejected', 'read-only diagnostic policy rejects VSS deletion' in files.get('NegativeTests.cs',''))
check('negative test: defrag write mode rejected', 'read-only diagnostic policy rejects defrag write optimization' in files.get('NegativeTests.cs',''))
check('maintenance probes reject PATH-searched executables', 'PROBE_BLOCKED_UNTRUSTED_EXE_PATH' in files.get('AutoCare.cs','') and 'IsTrustedSystemExecutablePath' in files.get('AutoCare.cs',''))
check('fsutil probes use canonical System32 path', 'Path.Combine(windows, "System32", "fsutil.exe")' in files.get('AutoCare.cs','') and 'RunReadOnlyExe("fsutil.exe"' not in files.get('AutoCare.cs',''))
check('dirty-bit probe is read-only and canonical', 'dirty query' in files.get('AutoCare.cs','') and 'DirtyBitProbe' in files.get('AutoCare.cs',''))
check('negative test: bare maintenance executable rejected', 'bare executable name is rejected for maintenance probes' in files.get('NegativeTests.cs',''))
check('negative test: System32 lookalike rejected', 'lookalike System32 sibling executable path is rejected' in files.get('NegativeTests.cs',''))
check('read-only diagnostics enforce canonical executable provenance', 'DiagnosticExecutablePathMatchesPolicyForTests' in adv and 'BLOCKED_UNTRUSTED_EXECUTABLE_PATH' in adv)
check('negative test: read-only bare executable rejected', 'read-only diagnostic rejects bare executable path' in files.get('NegativeTests.cs',''))
check('negative test: read-only System32 lookalike rejected', 'read-only diagnostic rejects System32 lookalike sibling' in files.get('NegativeTests.cs',''))


# v0.8 interruption recovery / runtime race / blast-radius hardening
storage = files.get('StorageIntelligence.cs','')
auto = files.get('AutoCare.cs','')
prog = files.get('Program.cs','')
neg = files.get('NegativeTests.cs','')
check('runtime cache process recheck exists at delete time', 'RuntimeFeatureGuard.IsCategorySafeForWrite(c.Category' in prog and 'CategoryProcesses' in auto)
check('candidate category is rebound to owning root', 'Candidate category does not match owning approved root' in prog)
check('approved-root age policy is rechecked at delete time', 'Candidate no longer satisfies approved-root age policy' in prog)
check('automatic cleanup has physical-space blast-radius budget', 'CleanupBlastRadiusPolicy.GetSystemRunBudgetBytes' in prog and 'physical-space blast-radius budget reached' in prog)
check('automatic cleanup roots are bound to the evidenced system volume', 'IsOnSystemVolume(path)' in prog and 'Directory.Exists(path) && IsOnSystemVolume(path)' in prog)
check('negative test: cleanup authority system-volume binding', 'automatic cleanup authority is bound to the system volume' in neg)
check('automatic cleanup has finite file-count budget', 'MaxFilesPerRun' in prog and 'file-count blast-radius budget reached' in prog)
check('space-recovery budget prioritizes largest allocated candidates', 'OrderByDescending(c => c.AllocatedBytes' in prog)
check('interrupted auto-care journal exists', 'MaintenanceRunJournal' in storage and 'IN_PROGRESS' in storage and 'last-auto-care-run.json' in storage)
check('interrupted prior run suppresses heavy maintenance', 'ApplyInterruptedRunGate' in auto and 'Recovery mode after interrupted/untrusted previous run' in auto)
check('auto-care stages are journaled before writes', 'MarkStage(runId, "SAFE_CLEANUP")' in auto and 'MarkStage(runId, "COMPONENT_CLEANUP")' in auto and 'MarkStage(runId, "DRIVE_OPTIMIZATION")' in auto)
check('runtime AC power is rechecked before heavy stages', auto.count('HeavyStagePowerStillSafe') >= 3)
check('component cleanup has live free-space margin', 'ComponentCleanupMinimumFreeBytes' in auto and 'Insufficient verified free-space margin' in auto)
check('pending reboot defers drive optimization too', 'drive optimization deferred until reboot completes' in auto)
check('master report schema upgraded to v10', 'SchemaVersion { get; set; } = "10.0"' in auto and 'master schema version is 10.0' in auto)
check('master report carries run identity and recovery state', 'RunId { get; set; }' in auto and 'RecoveryModeFromInterruptedRun' in auto)
check('verifier proves recovery mode ran no heavy stages', 'recovery mode executes no Delivery Optimization cleanup' in auto and 'recovery mode executes no drive optimization' in auto)
check('negative test: interrupted run recovery', 'interrupted prior auto-care run triggers recovery mode' in neg)
check('negative test: recovery gate suppresses all heavy stages', 'interrupted-run gate suppresses every heavy write stage without global-blocking safe cleanup' in neg)
check('negative test: future run journal timestamp', 'future auto-care journal timestamp triggers recovery mode' in neg)
check('negative test: cleanup blast radius', 'cleanup blast-radius budget expands under emergency space pressure but remains capped' in neg)
check('negative test: forged candidate category', 'forged candidate category cannot bypass owning-root policy' in neg)
check('negative test: delete-time age recheck', 'cleaner rechecks approved-root age policy at delete time' in neg)

# v0.9 volume identity / proof drift / bounded I/O / state durability
check('cleanup system-volume binding uses Windows volume GUID identity', 'GetVolumeNameForVolumeMountPointW' in prog and 'TryGetVolumeIdentity' in prog and 'IsOnSystemVolume' in prog)
check('quarantine requires provable distinct volume identities', 'TryAreSameVolume(c.Path, quarantineRoot' in prog and 'source/quarantine volume identity could not be proven' in prog)
check('per-category byte blast-radius exists', 'ComputeCategoryBudgetBytes' in storage and 'Per-category automatic cleanup physical-space blast-radius budget reached' in prog)
check('per-category file blast-radius exists', 'MaxFilesPerCategory' in storage and 'Per-category automatic cleanup file-count blast-radius budget reached' in prog)
check('free-space proof drift is explicitly classified', 'FreeSpaceProofPolicy' in storage and 'FreeSpaceProofAssessment' in prog and 'CONCURRENT_VOLUME_ACTIVITY' in prog)
check('proof drift forces bounded cleanup status', 'proofIsBounded' in prog and 'VERIFIED_PASS_BOUNDED' in prog)
check('apply mode has durable protected state-store gate', 'ApplyStateStoreGate' in auto and 'StateStoreHealthProbe.Probe' in auto and 'state-store-durability' in auto)
check('state-store durability probe uses write-through flush and readback', 'FileOptions.WriteThrough' in auto and 'Flush(flushToDisk: true)' in auto and 'write/read/fsync/delete durability probe passed' in auto)
check('recent storage I/O event probe is read-only and numeric', 'RISK_COUNT=' in auto and 'Get-WinEvent -FilterHashtable' in auto and 'StorageReliabilityPolicy' in auto)
check('single storage event suppresses heavy stages while repeated events global block', 'HEAVY_ONLY' in auto and 'BLOCK_WRITES' in auto and 'Recent storage I/O error event' in auto)
check('duplicate full-hash work has byte and file budgets', 'MaxFullHashBytes = 64L * 1024 * 1024 * 1024' in prog and 'MaxFullHashFiles = 512' in prog and 'DuplicateHashBudget.CanHash' in prog)
check('duplicate hash budget exhaustion is disclosed as truncated analysis', 'duplicate full-hash work budget reached' in prog and 'duplicateBudgetTruncated' in prog)
check('negative test: volume GUID identity', 'canonical Windows volume identity' in neg)
check('negative test: per-category blast radius', 'per-category cleanup byte budget cannot consume the whole run budget' in neg and 'per-category cleanup file-count cap is stricter' in neg)
check('negative test: free-space proof drift', 'free-space proof marks concurrent volume drift as bounded' in neg and 'concurrent volume activity cannot be mislabeled as exact cleanup proof' in neg)
check('negative test: hostile proof arithmetic overflow', 'free-space proof arithmetic is overflow-safe for hostile extreme values' in neg and 'absoluteDelta' in storage)
check('negative test: state-store durability mismatch', 'state-store durability policy rejects a readback mismatch' in neg)
check('negative test: storage event gate', 'repeated storage I/O events global-block all write maintenance' in neg and 'single storage I/O event gate preserves safe cleanup' in neg)
check('negative test: duplicate full-hash budgets', 'duplicate full-hash byte budget rejects an oversized next file' in neg and 'duplicate full-hash file-count budget is finite' in neg)
check('project version advanced to 1.4.0', '<Version>1.4.0</Version>' in Path(ROOT/'DiskGuardSpace.csproj').read_text(encoding='utf-8'))
check('v0.9 changelog is present', (ROOT/'CHANGELOG_v0.9.md').exists())

# v1.0 verified background startup automation
startup_install = ps.get('INSTALL_STARTUP_AUTOMATION.ps1','')
startup_bg = ps.get('BACKGROUND_MAINTENANCE.ps1','')
startup_verify = ps.get('VERIFY_STARTUP_AUTOMATION.ps1','')
startup_uninstall = ps.get('UNINSTALL_STARTUP_AUTOMATION.ps1','')
install_run = ps.get('INSTALL_AND_RUN.ps1','')
check('v1.0 changelog is present', (ROOT/'CHANGELOG_v1.0.md').exists())
check('startup automation installer exists', 'Register-ScheduledTask' in startup_install and 'StartupMaintenance' in startup_install)
check('startup runtime installs under Program Files', 'Join-Path $env:ProgramFiles "DiskGuardSpace"' in startup_install and 'Install root escaped Program Files' in startup_install)
check('startup task uses canonical Windows PowerShell path', 'System32\\WindowsPowerShell\\v1.0\\powershell.exe' in startup_install and 'Get-Command powershell' not in startup_install)
check('startup task is per-user delayed logon not SYSTEM startup', 'New-ScheduledTaskTrigger -AtLogOn -User $userSid' in startup_install and "$trigger.Delay = 'PT5M'" in startup_install and '-AtStartup' not in startup_install and 'SYSTEM' not in startup_install)
check('startup task is hidden and ignores duplicate instances', 'New-ScheduledTaskSettingsSet -Hidden' in startup_install and '-MultipleInstances IgnoreNew' in startup_install)
check('startup task requests highest interactive run level', 'New-ScheduledTaskPrincipal -UserId $userSid -LogonType Interactive -RunLevel Highest' in startup_install)
check('startup install begins from verified release', '& $VerifyReleasePath -ExePath $ExePath -ProofPath $ProofPath' in startup_install and 'Release verification failed; startup automation was not installed.' in startup_install)
check('startup install manifest binds runtime files by SHA-256 and size', 'DiskGuardSpace.StartupInstall.v1' in startup_install and 'sha256=(Get-Sha256 $ip)' in startup_install and 'sizeBytes=(Get-Item $ip).Length' in startup_install)
check('startup task is verified after registration', 'VERIFY_STARTUP_AUTOMATION.ps1' in startup_install and 'Startup task post-registration verification failed.' in startup_install)
check('startup installer preserves prior task XML for rollback', 'Export-ScheduledTask' in startup_install and 'existingTaskXml' in startup_install and 'Register-ScheduledTask -TaskName $TaskName -TaskPath $TaskPath -Xml $existingTaskXml -Force' in startup_install)
check('startup installer rolls back replaced runtime files on failure', 'Restore-Files $rollbackEntries' in startup_install and 'INSTALL_MANIFEST.previous.json' in startup_install)
check('startup verifier checks exact action arguments and canonical executable', 'Task executable is not canonical Windows PowerShell.' in startup_verify and 'Task arguments differ from the verified install manifest.' in startup_verify)
check('startup verifier checks trigger, hidden setting and principal SID', 'MSFT_TaskLogonTrigger' in startup_verify and 'Task must be enabled and hidden.' in startup_verify and 'Task principal SID mismatch.' in startup_verify)
check('background runtime verifies task and release before auto-care', startup_bg.find('VERIFY_STARTUP_AUTOMATION.ps1') >= 0 and startup_bg.find('VERIFY_RELEASE.ps1') >= 0 and startup_bg.find("$careArgs = @('auto-care'") > startup_bg.find('VERIFY_RELEASE.ps1'))
check('background run uses explicit startup evidence mode', "'--startup-background'" in startup_bg and 'StartupBackground' in files.get('AutoCare.cs','') and 'STARTUP_BACKGROUND' in files.get('AutoCare.cs',''))
check('background runtime has once-per-boot identity guard', 'LastBootUpTime' in startup_bg and 'lastBootId' in startup_bg and 'if ([string]$prior.lastBootId -eq $bootId) { exit 0 }' in startup_bg)
check('background state writes are write-through and atomic', 'FileOptions]::WriteThrough' in startup_bg and '$fs.Flush($true)' in startup_bg and '[IO.File]::Replace' in startup_bg)
check('background script stays Windows PowerShell 5.1 compatible for text SHA-256', '[Security.Cryptography.SHA256]::Create()' in startup_bg and 'HashData' not in startup_bg and 'ToHexString' not in startup_bg)
check('background malformed state fails closed for current boot', 'Startup state was malformed; current boot skipped fail-closed.' in startup_bg)
check('background full tests repeat on EXE change or seven-day interval', 'AddDays(-7)' in startup_bg and 'lastFullExeSha256' in startup_bg and '& $Exe self-test' in startup_bg and '& $Exe negative-tests' in startup_bg)
check('background heavy health is periodic not forced every boot', "if ($deepHealthDue) { $careArgs += '--deep-health' }" in startup_bg and 'AddDays(-14)' in startup_bg)
check('background session retention is bounded to 30 own-format directories', "Select-Object -Skip 30" in startup_bg and "^\\d{8}-\\d{6}-[0-9a-f]{8}$" in startup_bg)
check('startup uninstall refuses mid-maintenance termination', "State -eq 'Running'" in startup_uninstall and 'do not terminate it mid-maintenance' in startup_uninstall)
check('startup uninstall preserves reports by default', 'User maintenance reports under LocalAppData were preserved.' in startup_uninstall)
check('first-run pipeline installs startup automation after release verification', install_run.find('VERIFY_RELEASE.ps1 -ExePath $Exe') >= 0 and install_run.find('INSTALL_STARTUP_AUTOMATION.ps1') > install_run.find('VERIFY_RELEASE.ps1 -ExePath $Exe'))
check('first-run final gate re-verifies startup automation', 'VERIFY_STARTUP_AUTOMATION.ps1' in install_run and '$startupExit' in install_run)
check('negative test: startup background flag is explicit', 'startup background mode is explicit and does not imply apply by itself' in files.get('NegativeTests.cs',''))

build_verified = ps.get('BUILD_VERIFIED_EXE.ps1','')
verify_release = ps.get('VERIFY_RELEASE.ps1','')

# v1.1/v1.3 native runtime controller / CSV Cleaner parity
controller = files.get('ControllerUi.cs','')
verify_controller = ps.get('VERIFY_CONTROLLER.ps1','')
check('v1.1 changelog is present', (ROOT/'CHANGELOG_v1.1.md').exists())
check('double-click no-argument path opens native controller', 'if (args.Length == 0)' in files.get('Program.cs','') and 'ControllerUi.Run(Array.Empty<string>())' in files.get('Program.cs',''))
check('explicit controller command exists', '"controller" => ControllerUi.Run' in files.get('Program.cs',''))
check('controller is native Win32 and detaches without hiding parent console', 'CreateWindowExW' in controller and 'FreeConsole()' in controller and 'ShowWindow(console, SwHide)' not in controller)
check('controller has real Windows button action', 'Run Read-Only Verification' in controller and 'IdRun' in controller and 'StartVerification()' in controller)
check('controller proof path is restricted to LocalAppData or TEMP', 'ControllerPathPolicy' in controller and 'LocalApplicationData' in controller and 'LocalApplicationData' in controller and 'outside canonical LocalAppData' in controller and 'Path.GetTempPath()' not in controller)
check('controller proof path rejects unsafe/reparse paths', 'SafetyPolicy.HasUnsafePathSyntax' in controller and 'SafetyPolicy.IsReparsePoint' in controller)
check('controller runtime proof is read-only maintenance', '"self-test"' in controller and '"negative-tests"' in controller and '"scan"' in controller and '"auto-care"' in controller and '"--apply"' not in controller)
check('controller independently verifies scan and auto-care evidence', '"verify-report"' in controller and '"verify-auto-care"' in controller)
check('controller proof binds packaged EXE SHA-256', 'ExeSha256' in controller and 'SHA256.HashData' in controller and 'CONTROLLER_PROOF.json' in controller)
check('controller proof is atomic/write-through', 'FileOptions.WriteThrough' in controller and 'Flush(flushToDisk: true)' in controller and 'AtomicWriteJson' in controller)
check('controller verifies adjacent final release proof when present', 'RELEASE_PROOF.json' in controller and 'ReleaseProof.v1' in controller and 'version.GetString() == "1.4"' in controller)
check('native controller automation uses Windows UI Automation for exact control discovery', 'UIAutomationClient' in verify_controller and 'Run Read-Only Verification' in verify_controller and 'NativeWindowHandle' in verify_controller)
check('controller activation does not depend on optional InvokePattern', 'GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern)' not in verify_controller and 'BM_CLICK' in verify_controller)
check('controller native target class is verified before activation', 'GetClassName' in verify_controller and "controller_run_button_native_hwnd" in verify_controller and "-ieq 'Button'" in verify_controller)
check('controller click requires observed state transition', 'actionObserved' in verify_controller and 'STATUS: RUNNING' in verify_controller and 'Native controller button click was sent but no controller state transition was observed.' in verify_controller)
check('double-click controller verifier launcher exists', 'VERIFY_CONTROLLER.ps1' in Path(ROOT/'VERIFY_CONTROLLER.cmd').read_text(encoding='utf-8') if (ROOT/'VERIFY_CONTROLLER.cmd').exists() else False)
check('native controller automation proves actual visible window and PASS title', 'controller_window_visible' in verify_controller and 'controller_window_status_pass' in verify_controller and 'STATUS: PASS' in verify_controller)
check('release pipeline requires staging controller GUI proof', 'GATE 7/11' in build_verified and 'VERIFY_CONTROLLER.ps1 -ExePath $StageExe' in build_verified and 'controllerNativeGui = "PASS"' in build_verified)
check('final release reruns controller and requires release-proof identity', 'VERIFY_CONTROLLER.ps1 -ExePath $FinalExe' in build_verified and '-RequireReleaseProof' in build_verified)
check('release verifier requires controller gate', 'controllerNativeGui' in verify_release)
check('release proof records controller automation identity', 'controllerAutomationProofSha256' in build_verified)
check('startup install deploys controller verifier for installed runtime', 'VERIFY_CONTROLLER.ps1' in startup_install and 'ControllerVerifierSource' in startup_install)
check('negative test: controller proof directory containment', 'controller proof output outside canonical LocalAppData is rejected' in files.get('NegativeTests.cs',''))
check('negative test: controller ADS output path', 'controller proof output rejects ADS syntax' in files.get('NegativeTests.cs',''))
check('negative test: controller unknown option', 'controller rejects unknown command-line options' in files.get('NegativeTests.cs',''))

# v1.3 persistent error/controller reliability
crash = files.get('CrashDiagnostics.cs','')
build_cmd = Path(ROOT/'BUILD_VERIFIED_EXE.cmd').read_text(encoding='utf-8') if (ROOT/'BUILD_VERIFIED_EXE.cmd').exists() else ''
first_cmd = Path(ROOT/'FIRST_RUN.cmd').read_text(encoding='utf-8') if (ROOT/'FIRST_RUN.cmd').exists() else ''
diag_cmd = Path(ROOT/'RUN_CONTROLLER_DIAGNOSTIC.cmd').read_text(encoding='utf-8') if (ROOT/'RUN_CONTROLLER_DIAGNOSTIC.cmd').exists() else ''
check('v1.3 changelog is present', (ROOT/'CHANGELOG_v1.3.md').exists())
check('top-level controller failure writes persistent crash proof', 'CrashDiagnostics.TryWrite' in files.get('Program.cs','') and 'DiskGuardSpace.CrashProof.v1' in crash)
check('crash diagnostics is canonical LocalAppData only', 'SpecialFolder.LocalApplicationData' in crash and 'IsAllowedLogDirectory' in crash and 'HasUnsafePathSyntax' in crash)
check('GUI startup failure displays persistent log path', 'CrashDiagnostics.ShowFatalDialog' in files.get('Program.cs','') and 'Kalıcı hata kaydı' in crash)
check('controller no longer hides a shared parent console window', 'FreeConsole()' in controller and 'ShowWindow(console, SwHide)' not in controller)
check('build launcher persists output and always pauses', 'BUILD_LAST.log' in build_cmd and 'pause >nul' in build_cmd)
check('first-run launcher persists output and always pauses', 'FIRST_RUN_LAST.log' in first_cmd and 'pause' in first_cmd)
check('controller diagnostic launcher persists failure output and pauses', 'CONTROLLER_LAST.log' in diag_cmd and 'crash-*.json' in diag_cmd and 'pause' in diag_cmd)
check('negative test: crash log external path rejected', 'crash diagnostics rejects an arbitrary external log directory' in files.get('NegativeTests.cs',''))
check('negative test: crash log ADS rejected', 'crash diagnostics rejects ADS log-root syntax' in files.get('NegativeTests.cs',''))

# v1.4 maintenance dashboard + cadence policy
actions = files.get('ControllerActions.cs','')
check('v1.4 changelog is present', (ROOT/'CHANGELOG_v1.4.md').exists())
check('native controller exposes analysis and maintenance dashboard buttons', all(x in controller for x in ['Analyze PC','Safe Cleanup','Full Auto-Care','Performance Care','40 GiB Space Plan','Apply Space Plan','Enable Startup Maintenance']))
check('GUI write actions require verified release identity', 'VerifyControlledReleaseForWrite' in actions and 'RELEASE_PROOF.json' in actions and 'version.GetString() == "1.4"' in actions)
check('GUI write actions request UAC runas', 'Verb = "runas"' in actions and 'RunElevated' in actions)
check('GUI safe cleanup keeps independent evidence verification', '"verify-report"' in actions and 'SafeCleanup' in actions)
check('GUI full auto-care keeps independent master verification', '"verify-auto-care"' in actions and 'FullAutoCare' in actions)
check('GUI 40 GiB plan remains hash-bound and two-stage', 'CreateSpaceRecoveryPlan' in actions and 'ApplyLatestSpacePlan' in actions and 'SPACE_PLAN_APPLY' in actions)
check('startup logon delay is five minutes', "$trigger.Delay = 'PT5M'" in startup_install and "-ne 'PT5M'" in startup_verify)
check('startup deep analysis cadence is three days', 'AddDays(-3)' in startup_bg and "'--skip-deep-analysis'" in startup_bg)
check('startup deep health cadence is fourteen days', 'AddDays(-14)' in startup_bg and "$deepHealthDue" in startup_bg)
check('component cleanup cooldown is fourteen days', 'ShouldSkip("COMPONENT_CLEANUP", TimeSpan.FromDays(14)' in auto)
check('delivery optimization cooldown remains one day', 'ShouldSkip("DELIVERY_OPTIMIZATION", TimeSpan.FromDays(1)' in auto)
check('drive optimization cooldown remains seven days', 'ShouldSkip("DRIVE_OPTIMIZATION", TimeSpan.FromDays(7)' in auto)
check('auto-care can explicitly defer deep analysis', 'SkipDeepAnalysis' in auto and '--skip-deep-analysis' in auto and 'DeepAnalysisSkippedByPolicy' in auto)
check('auto-care verifier accepts only explicit policy-skipped deep analysis', 'policy-skipped deep analysis has no linked analysis artifact' in auto and 'policy-skipped deep analysis has no analysis artifact hash' in auto)

# v0.7 controlled release / Game Recorder parity
build_verified = ps.get('BUILD_VERIFIED_EXE.ps1','')
verify_release = ps.get('VERIFY_RELEASE.ps1','')
verify_source = ps.get('VERIFY_SOURCE.ps1','')
check('double-click verified EXE launcher exists', 'BUILD_VERIFIED_EXE.ps1' in Path(ROOT/'BUILD_VERIFIED_EXE.cmd').read_text(encoding='utf-8') if (ROOT/'BUILD_VERIFIED_EXE.cmd').exists() else False)
check('controlled verified EXE pipeline exists', 'BUILD VERIFIED EXE: PASS' in build_verified and 'GATE 11/11' in build_verified)
check('release build uses staging before dist promotion', 'release-staging-' in build_verified and 'DiskGuardSpace.pending.exe' in build_verified and 'Move-Item $Pending $FinalExe' in build_verified)
check('release promotion requires packaged self-test', '& $StageExe self-test' in build_verified and '& $Pending self-test' in build_verified)
check('release promotion requires negative tests', '& $StageExe negative-tests' in build_verified and '& $Pending negative-tests' in build_verified)
check('release promotion requires real-PC read-only proof', 'prove-on-windows.ps1 -SkipBuild -ExePath $StageExe -ProofDir $ProofDir' in build_verified)
check('release exact-byte identity is SHA-256 bound', '$pendingHash -ne $stageHash' in build_verified and '$finalHash -ne $stageHash' in build_verified)
check('release proof records source and EXE identity', 'sourceManifestSha256' in build_verified and 'exeSha256' in build_verified and 'exeSizeBytes' in build_verified)
check('independent release verifier exists', 'RELEASE VERIFY: VERIFIED_PASS' in verify_release and 'EXE SHA-256 mismatch' in verify_release)
check('independent release verifier can rerun packaged self-test', 'RunSelfTest' in verify_release and '& $ExePath self-test' in verify_release)
check('release failure withdraws promoted EXE', 'promoted artifact was withdrawn' in build_verified and 'Remove-Item $FinalExe' in build_verified)
check('release rollback protects both prior EXE and prior proof', 'DiskGuardSpace.previous.exe' in build_verified and 'RELEASE_PROOF.previous.json' in build_verified and 'Restore-PreviousRelease' in build_verified)
check('release EXE and proof promotion use same-volume atomic replacement when prior artifacts exist', '[System.IO.File]::Replace($Pending, $FinalExe, $OldExe, $true)' in build_verified and '[System.IO.File]::Replace($ProofPending, $FinalProof, $OldProof, $true)' in build_verified)
check('release proof product version advanced to 1.4', 'version = "1.4"' in build_verified and '$p.version -ne "1.4"' in verify_release)
check('independent release verifier reruns negative tests with self-test gate', '& $ExePath negative-tests' in verify_release and 'Release EXE negative/regression tests failed.' in verify_release)
check('low-level build is explicitly unverified', 'UNVERIFIED FOR RELEASE' in ps.get('build-win-x64.ps1',''))
check('strict source manifest rejects unmanifested tracked files', 'unmanifested tracked source/control file' in verify_source and "'.csproj'" in verify_source and "'.ps1'" in verify_source and "'.cmd'" in verify_source)
check('PC proof summary is machine-readable', 'DiskGuardSpace.PcProof.v1' in ps.get('prove-on-windows.ps1','') and 'PROOF_SUMMARY.json' in ps.get('prove-on-windows.ps1',''))
check('release pipeline does not claim code-signing when absent', 'No claim of code-signing is made' in build_verified)
check('install path re-verifies release before write maintenance', ps.get('INSTALL_AND_RUN.ps1','').find('VERIFY_RELEASE.ps1') >= 0 and ps.get('INSTALL_AND_RUN.ps1','').find('VERIFY_RELEASE.ps1') < ps.get('INSTALL_AND_RUN.ps1','').find('auto-care --apply'))

# Simple lexical structure checker that ignores strings/comments enough for accidental-edit detection.
def balanced(src):
    stack=[]; i=0; state='code'; raw=False
    pairs={'}':'{',')':'(',']':'['}
    while i < len(src):
        c=src[i]; n=src[i+1] if i+1<len(src) else ''
        if state=='code':
            if c=='/' and n=='/': state='line'; i+=2; continue
            if c=='/' and n=='*': state='block'; i+=2; continue
            if src.startswith('"""',i): state='raw'; i+=3; continue
            if c=='"': state='str'; i+=1; continue
            if c=="'": state='char'; i+=1; continue
            if c in '{([': stack.append(c)
            elif c in '})]':
                if not stack or stack.pop()!=pairs[c]: return False
            i+=1; continue
        if state=='line':
            if c=='\n': state='code'
            i+=1; continue
        if state=='block':
            if c=='*' and n=='/': state='code'; i+=2; continue
            i+=1; continue
        if state=='raw':
            if src.startswith('"""',i): state='code'; i+=3; continue
            i+=1; continue
        if state in ('str','char'):
            quote='"' if state=='str' else "'"
            if c=='\\': i+=2; continue
            if c==quote: state='code'
            i+=1; continue
    return not stack and state in ('code','line')

for name,src in files.items():
    check(f'balanced C# structure: {name}', balanced(src))

# PowerShell basic brace balance (scripts intentionally do not embed brace-heavy JSON).
for name,src in ps.items():
    check(f'PowerShell brace count: {name}', src.count('{') == src.count('}'))

passed=sum(1 for _,ok,_ in checks if ok)
failed=[x for x in checks if not x[1]]
print(f'STATIC_AUDIT: {"PASS" if not failed else "FAIL"} ({passed}/{len(checks)} checks passed)')
for name,ok,detail in checks:
    print(('PASS' if ok else 'FAIL') + ': ' + name + ((' -- '+detail) if detail else ''))

if failed:
    sys.exit(1)
