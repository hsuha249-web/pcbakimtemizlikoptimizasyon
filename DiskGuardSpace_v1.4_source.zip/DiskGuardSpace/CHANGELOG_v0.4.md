# DiskGuardSpace v0.4 Changes

## Space-first improvements

- Added bounded read-only `%LOCALAPPDATA%` analysis (300,000 files / 120 seconds).
- Added aggregate directory-hotspot ranking to expose large AppData/application trees even when no single file is huge.
- Added additional NVIDIA and AMD shader/cache roots.
- Added old Windows Error Reporting archive/queue cleanup roots with conservative age limits.
- Improved compression estimates by sampling the beginning, middle, and end of large files instead of only the beginning.
- Priority planner now uses post-maintenance free space and can select AppData-hotspot classification or analysis-coverage hardening.

## Fail-closed hardening

- Removed `TEMP/TMP` environment variables as cleanup-root authorities.
- Added canonical cleanup-root validation.
- Added runtime-directory self-protection.
- Added locked SHA-256 verification through the final delete/quarantine action.
- Added quarantine destination free-space reserve checks.
- Added single-instance auto-care guard.
- Added AC-power and critical-low-space gates for heavy drive optimization.
- Added maintenance timeouts for DISM, drive optimization, and Delivery Optimization cleanup.
- Added atomic evidence-file writes.
- Added SHA-256 linkage from the master report to stage evidence.
- Added explicit bounded-analysis coverage metadata.

## Regression fixes

- Fixed master evidence verification so read-only scan reports correctly accept `VERIFIED_SCAN` instead of incorrectly requiring `VERIFIED_PASS`.
- Fixed evidence verification so maintenance stages are not incorrectly required to contain per-file delete action rows.
- No-op safe cleanup can now verify successfully without requiring unrelated background disk activity to produce a positive free-space delta.

## Negative/regression matrix additions

Added cases for poisoned TEMP/TMP, runtime self-deletion, noncanonical cleanup roots, zero-byte candidates, existing writers, invalid SHA-256 evidence, atomic report replacement, linked `VERIFIED_SCAN`, maintenance evidence without per-file rows, and explicitly bounded analysis.
