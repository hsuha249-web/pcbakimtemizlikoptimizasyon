# DiskGuardSpace v0.7 Changes

## Controlled EXE release pipeline

- Added `BUILD_VERIFIED_EXE.ps1` with a 10-gate staged release flow.
- A newly compiled binary remains unreleased until packaged self-test, negative tests, real-PC read-only proof, report verification, pending regression tests and byte-identity checks pass.
- Release promotion is atomic through `DiskGuardSpace.pending.exe`.
- Added `RELEASE_PROOF.json` containing EXE SHA-256/size, strict source-manifest SHA-256, runtime target and gate statuses.
- Added `VERIFY_RELEASE.ps1` to independently reopen release evidence and optionally rerun the packaged self-test.
- Release-verifier failure withdraws the newly promoted binary.
- Low-level `build-win-x64.ps1` is explicitly marked developer/unverified.
- `FIRST_RUN.ps1` / `INSTALL_AND_RUN.ps1` now require the verified release identity before any write maintenance.

## Source-chain hardening

- Source manifest verification now rejects unmanifested top-level source/control files.
- Unsafe manifest paths and source-root escapes are rejected.
- Real-PC proof emits machine-readable `PROOF_SUMMARY.json`.
- Packaged binary identity is checked at staging, pending and final release states.
- Authenticode state is recorded without claiming a signature when none exists.

## Validation in this development environment

- Static architecture/safety audit: 151/151 PASS after the v0.7 changes.
- Windows/.NET runtime build cannot be honestly claimed here because the current build environment has no `dotnet` SDK or Windows PowerShell. The target Windows PC performs those gates itself.
