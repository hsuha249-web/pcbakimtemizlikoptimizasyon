@echo off
setlocal
cd /d "%~dp0"
if not exist "%~dp0dist\DiskGuardSpace.exe" (
  echo CONTROLLER VERIFY: FAIL - dist\DiskGuardSpace.exe missing.
  echo Run BUILD_VERIFIED_EXE.cmd first.
  pause
  exit /b 2
)
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0VERIFY_CONTROLLER.ps1" -ExePath "%~dp0dist\DiskGuardSpace.exe" -RequireReleaseProof
set "EC=%ERRORLEVEL%"
echo.
if "%EC%"=="0" (
  echo CONTROLLER VERIFY: VERIFIED_PASS
) else (
  echo CONTROLLER VERIFY: FAIL-CLOSED ^(exit %EC%^)
)
pause
exit /b %EC%
