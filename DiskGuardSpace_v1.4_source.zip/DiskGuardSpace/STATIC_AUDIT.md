# DiskGuardSpace v1.4 Static Audit

Generated from static-audit.py in this source package.

```text
STATIC_AUDIT: PASS (296/296 checks passed)
PASS: auto-care command exists
PASS: independent auto-care verifier exists
PASS: disk space fixed as primary priority
PASS: negative tests command exists
PASS: first run invokes automated installer
PASS: verified release pipeline runs before apply
PASS: automatic apply occurs after proof
PASS: UAC elevation path exists
PASS: first-run elevation uses canonical System32 PowerShell
PASS: space-plan command exists
PASS: space-plan requires explicit confirmation
PASS: Update Guard is opt-in
PASS: Update Guard schedules boot and bounded repetition
PASS: Update Guard records/restores owned state
PASS: no arbitrary delete-path CLI switch
PASS: reparse point checks exist
PASS: changed-since-scan gate exists
PASS: handle-bound verified delete exists
PASS: same-volume quarantine refused
PASS: full SHA-256 duplicate confirmation exists
PASS: System32 forbidden cleanup root
PASS: browser process feature skips exist
PASS: physical disk health gate exists
PASS: pending servicing reboot gate exists
PASS: drive optimize uses media-aware /O
PASS: component cleanup uses StartComponentCleanup
PASS: ResetBase absent from DISM execution body
PASS: Delivery Optimization uses supported cmdlet
PASS: SoftwareDistribution deletion is isolated to Update Guard
PASS: Update Guard never touches protected roots
PASS: Update Guard uninstall hook exists
PASS: large files marked REVIEW_ONLY
PASS: old installers marked REVIEW_ONLY
PASS: deep analyzer contains no File.Delete
PASS: master reopens linked evidence
PASS: negative test: path escape
PASS: negative test: changed file
PASS: negative test: locked file
PASS: negative test: quick hash collision
PASS: negative test: tampered evidence
PASS: TEMP env is not a cleanup authority
PASS: canonical cleanup root validation exists
PASS: runtime directory protection exists
PASS: delete is bound to verified kernel handle
PASS: quarantine free-space reserve exists
PASS: atomic report writer exists
PASS: single auto-care instance guard exists
PASS: AC-power drive optimization gate exists
PASS: critical-low-space optimization gate exists
PASS: maintenance timeouts exist
PASS: AppData Local deep analysis exists
PASS: bounded deep-analysis budget exists
PASS: representative compression sampling exists
PASS: linked evidence SHA-256 manifest exists
PASS: negative test: poisoned TEMP
PASS: negative test: runtime self-protection
PASS: negative test: writer race
PASS: negative test: invalid hash evidence
PASS: negative test: atomic report write
PASS: directory hotspot aggregation exists
PASS: priority planner can choose AppData hotspot classification
PASS: verified bounded analysis supported
PASS: linked scan status regression fixed
PASS: maintenance verifier regression covered
PASS: safe-scan read errors are bounded, not global safety violations
PASS: safe cleanup can prove bounded coverage
PASS: hard-link cleanup rejection exists
PASS: read-only/system attribute cleanup rejection exists
PASS: kernel handle denies write/delete sharing
PASS: Electron cache adapters exist
PASS: Electron cache owning-process gates exist
PASS: advanced space snapshot exists
PASS: Windows Update is measured only and do-not-touch
PASS: Windows Installer cache is measured only
PASS: developer cache opportunities are review-only
PASS: bounded advanced directory sizing exists
PASS: performance memory/process diagnostics exist
PASS: read-only component-store analysis exists
PASS: deep health uses verify-only SFC
PASS: deep health uses CHKDSK scan not repair
PASS: CompactOS is query-only
PASS: hibernation remains review-only
PASS: system disk health probe targets system volume disk
PASS: auto-care schema advanced to 10.0
PASS: master verifies bounded advanced-space policies
PASS: negative test: hard-link preserved
PASS: negative test: read-only preserved
PASS: negative test: Windows Update direct cleanup absent
PASS: negative test: Windows Installer direct cleanup absent
PASS: master binds report to executable SHA-256
PASS: diagnostic command lines have strict policy matcher
PASS: Delivery Optimization support is probed before write stage
PASS: deep health is sequenced after space work
PASS: blocked actions are separated from global violations
PASS: sharing/access conflicts become local preserved skips
PASS: negative test: bounded scan status honesty
PASS: negative test: global violation cannot become bounded success
PASS: physical NTFS allocation probe exists
PASS: handle-bound allocation verification exists
PASS: cleanup evidence separates logical and allocated bytes
PASS: duplicate analysis has physical savings accounting
PASS: compression analysis skips already space-efficient attributes
PASS: directory sizing uses allocated bytes
PASS: space-pressure policy exists
PASS: heavy-maintenance cooldown journal exists
PASS: drive optimization cooldown is enforced
PASS: space-reclaim cooldown can bypass only under low pressure
PASS: high memory pressure skips drive optimization
PASS: ADS/device path syntax negative control exists
PASS: persistent DiskGuardSpace state tree is self-protected
PASS: VSS shadow storage is query-only
PASS: defrag analysis is read-only diagnostic
PASS: active power scheme is queried read-only
PASS: virtual disks are review-only
PASS: no direct VHDX delete path exists
PASS: additional package caches are review-only
PASS: negative test: physical evidence tamper
PASS: negative test: physical duplicate tamper
PASS: negative test: allocation fallback bounded honesty
PASS: negative test: cooldown future timestamp
PASS: negative test: virtual disk direct cleanup absent
PASS: negative test: mutating VSS command rejected
PASS: negative test: defrag write mode rejected
PASS: maintenance probes reject PATH-searched executables
PASS: fsutil probes use canonical System32 path
PASS: dirty-bit probe is read-only and canonical
PASS: negative test: bare maintenance executable rejected
PASS: negative test: System32 lookalike rejected
PASS: read-only diagnostics enforce canonical executable provenance
PASS: negative test: read-only bare executable rejected
PASS: negative test: read-only System32 lookalike rejected
PASS: runtime cache process recheck exists at delete time
PASS: candidate category is rebound to owning root
PASS: approved-root age policy is rechecked at delete time
PASS: automatic cleanup has physical-space blast-radius budget
PASS: automatic cleanup roots are bound to the evidenced system volume
PASS: negative test: cleanup authority system-volume binding
PASS: automatic cleanup has finite file-count budget
PASS: space-recovery budget prioritizes largest allocated candidates
PASS: interrupted auto-care journal exists
PASS: interrupted prior run suppresses heavy maintenance
PASS: auto-care stages are journaled before writes
PASS: runtime AC power is rechecked before heavy stages
PASS: component cleanup has live free-space margin
PASS: pending reboot defers drive optimization too
PASS: master report schema upgraded to v10
PASS: master report carries run identity and recovery state
PASS: verifier proves recovery mode ran no heavy stages
PASS: negative test: interrupted run recovery
PASS: negative test: recovery gate suppresses all heavy stages
PASS: negative test: future run journal timestamp
PASS: negative test: cleanup blast radius
PASS: negative test: forged candidate category
PASS: negative test: delete-time age recheck
PASS: cleanup system-volume binding uses Windows volume GUID identity
PASS: quarantine requires provable distinct volume identities
PASS: per-category byte blast-radius exists
PASS: per-category file blast-radius exists
PASS: free-space proof drift is explicitly classified
PASS: proof drift forces bounded cleanup status
PASS: apply mode has durable protected state-store gate
PASS: state-store durability probe uses write-through flush and readback
PASS: recent storage I/O event probe is read-only and numeric
PASS: single storage event suppresses heavy stages while repeated events global block
PASS: duplicate full-hash work has byte and file budgets
PASS: duplicate hash budget exhaustion is disclosed as truncated analysis
PASS: negative test: volume GUID identity
PASS: negative test: per-category blast radius
PASS: negative test: free-space proof drift
PASS: negative test: hostile proof arithmetic overflow
PASS: negative test: state-store durability mismatch
PASS: negative test: storage event gate
PASS: negative test: duplicate full-hash budgets
PASS: project version advanced to 1.4.0
PASS: v0.9 changelog is present
PASS: v1.0 changelog is present
PASS: startup automation installer exists
PASS: startup runtime installs under Program Files
PASS: startup task uses canonical Windows PowerShell path
PASS: startup task is per-user delayed logon not SYSTEM startup
PASS: startup task is hidden and ignores duplicate instances
PASS: startup task requests highest interactive run level
PASS: startup install begins from verified release
PASS: startup install manifest binds runtime files by SHA-256 and size
PASS: startup task is verified after registration
PASS: startup installer preserves prior task XML for rollback
PASS: startup installer rolls back replaced runtime files on failure
PASS: startup verifier checks exact action arguments and canonical executable
PASS: startup verifier checks trigger, hidden setting and principal SID
PASS: background runtime verifies task and release before auto-care
PASS: background run uses explicit startup evidence mode
PASS: background runtime has once-per-boot identity guard
PASS: background state writes are write-through and atomic
PASS: background script stays Windows PowerShell 5.1 compatible for text SHA-256
PASS: background malformed state fails closed for current boot
PASS: background full tests repeat on EXE change or seven-day interval
PASS: background heavy health is periodic not forced every boot
PASS: background session retention is bounded to 30 own-format directories
PASS: startup uninstall refuses mid-maintenance termination
PASS: startup uninstall preserves reports by default
PASS: first-run pipeline installs startup automation after release verification
PASS: first-run final gate re-verifies startup automation
PASS: negative test: startup background flag is explicit
PASS: v1.1 changelog is present
PASS: double-click no-argument path opens native controller
PASS: explicit controller command exists
PASS: controller is native Win32 and detaches without hiding parent console
PASS: controller has real Windows button action
PASS: controller proof path is restricted to LocalAppData or TEMP
PASS: controller proof path rejects unsafe/reparse paths
PASS: controller runtime proof is read-only maintenance
PASS: controller independently verifies scan and auto-care evidence
PASS: controller proof binds packaged EXE SHA-256
PASS: controller proof is atomic/write-through
PASS: controller verifies adjacent final release proof when present
PASS: native controller automation uses Windows UI Automation for exact control discovery
PASS: controller activation does not depend on optional InvokePattern
PASS: controller native target class is verified before activation
PASS: controller click requires observed state transition
PASS: double-click controller verifier launcher exists
PASS: native controller automation proves actual visible window and PASS title
PASS: release pipeline requires staging controller GUI proof
PASS: final release reruns controller and requires release-proof identity
PASS: release verifier requires controller gate
PASS: release proof records controller automation identity
PASS: startup install deploys controller verifier for installed runtime
PASS: negative test: controller proof directory containment
PASS: negative test: controller ADS output path
PASS: negative test: controller unknown option
PASS: v1.3 changelog is present
PASS: top-level controller failure writes persistent crash proof
PASS: crash diagnostics is canonical LocalAppData only
PASS: GUI startup failure displays persistent log path
PASS: controller no longer hides a shared parent console window
PASS: build launcher persists output and always pauses
PASS: first-run launcher persists output and always pauses
PASS: controller diagnostic launcher persists failure output and pauses
PASS: negative test: crash log external path rejected
PASS: negative test: crash log ADS rejected
PASS: v1.4 changelog is present
PASS: native controller exposes analysis and maintenance dashboard buttons
PASS: GUI write actions require verified release identity
PASS: GUI write actions request UAC runas
PASS: GUI safe cleanup keeps independent evidence verification
PASS: GUI full auto-care keeps independent master verification
PASS: GUI 40 GiB plan remains hash-bound and two-stage
PASS: startup logon delay is five minutes
PASS: startup deep analysis cadence is three days
PASS: startup deep health cadence is fourteen days
PASS: component cleanup cooldown is fourteen days
PASS: delivery optimization cooldown remains one day
PASS: drive optimization cooldown remains seven days
PASS: auto-care can explicitly defer deep analysis
PASS: auto-care verifier accepts only explicit policy-skipped deep analysis
PASS: double-click verified EXE launcher exists
PASS: controlled verified EXE pipeline exists
PASS: release build uses staging before dist promotion
PASS: release promotion requires packaged self-test
PASS: release promotion requires negative tests
PASS: release promotion requires real-PC read-only proof
PASS: release exact-byte identity is SHA-256 bound
PASS: release proof records source and EXE identity
PASS: independent release verifier exists
PASS: independent release verifier can rerun packaged self-test
PASS: release failure withdraws promoted EXE
PASS: release rollback protects both prior EXE and prior proof
PASS: release EXE and proof promotion use same-volume atomic replacement when prior artifacts exist
PASS: release proof product version advanced to 1.4
PASS: independent release verifier reruns negative tests with self-test gate
PASS: low-level build is explicitly unverified
PASS: strict source manifest rejects unmanifested tracked files
PASS: PC proof summary is machine-readable
PASS: release pipeline does not claim code-signing when absent
PASS: install path re-verifies release before write maintenance
PASS: balanced C# structure: SpacePlan.cs
PASS: balanced C# structure: ControllerUi.cs
PASS: balanced C# structure: UpdateGuard.cs
PASS: balanced C# structure: AutoCare.cs
PASS: balanced C# structure: Program.cs
PASS: balanced C# structure: AdvancedMaintenance.cs
PASS: balanced C# structure: NegativeTests.cs
PASS: balanced C# structure: StorageIntelligence.cs
PASS: balanced C# structure: ControllerActions.cs
PASS: balanced C# structure: CrashDiagnostics.cs
PASS: PowerShell brace count: BUILD_VERIFIED_EXE.ps1
PASS: PowerShell brace count: prove-on-windows.ps1
PASS: PowerShell brace count: INSTALL_STARTUP_AUTOMATION.ps1
PASS: PowerShell brace count: FIRST_RUN.ps1
PASS: PowerShell brace count: VERIFY_SOURCE.ps1
PASS: PowerShell brace count: INSTALL_AND_RUN.ps1
PASS: PowerShell brace count: UNINSTALL_STARTUP_AUTOMATION.ps1
PASS: PowerShell brace count: build-win-x64.ps1
PASS: PowerShell brace count: BACKGROUND_MAINTENANCE.ps1
PASS: PowerShell brace count: VERIFY_STARTUP_AUTOMATION.ps1
PASS: PowerShell brace count: VERIFY_CONTROLLER.ps1
PASS: PowerShell brace count: VERIFY_RELEASE.ps1
```
