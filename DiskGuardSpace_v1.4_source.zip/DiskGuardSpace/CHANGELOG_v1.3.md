# DiskGuardSpace v1.3 changelog

## Controller automation compatibility fix

The v1.2 Windows run proved that the packaged EXE, self-test, adversarial tests, real-PC read-only proof, controller window, and controller button were all present, but release gate 7 failed because that Windows UI Automation provider did not expose `InvokePattern` for the native Win32 button (`Unsupported Pattern`).

v1.3 removes that provider-specific assumption. `VERIFY_CONTROLLER.ps1` still uses Windows UI Automation to locate the exact controller process, visible window, and the named `Run Read-Only Verification` control. It then requires a non-zero `NativeWindowHandle`, verifies the target HWND class is exactly native `Button`, and activates that exact HWND with Win32 `BM_CLICK`.

The verifier does not trust the send call alone. It must observe a real controller state transition (`STATUS: RUNNING`, `PASS`, or `FAIL`) or the controller proof appearing, then still requires `CONTROLLER_PROOF.json`, EXE SHA-256 binding, read-only status, and final `STATUS: PASS`.

## New fail-closed controller checks

- zero/absent native HWND -> FAIL
- target HWND class not `Button` -> FAIL
- BM_CLICK sent but no controller state transition -> FAIL
- controller proof not produced -> FAIL
- proof identity/hash/read-only gates unchanged
- final release controller proof remains mandatory

This fixes the exact Windows failure observed in v1.2 without weakening the controller proof gate.
