param(
    [string]$InstallRoot = "",
    [switch]$RequireCurrentUser
)
$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest
if (-not $InstallRoot) { $InstallRoot = Join-Path $env:ProgramFiles "DiskGuardSpace" }
$ManifestPath = Join-Path $InstallRoot "INSTALL_MANIFEST.json"

function Fail([string]$Message) { Write-Host "STARTUP AUTOMATION VERIFY: FAIL - $Message" -ForegroundColor Red; exit 2 }
function Get-Sha256([string]$Path) { return (Get-FileHash $Path -Algorithm SHA256).Hash.ToLowerInvariant() }
function Resolve-Sid([string]$Identity) {
    if ($Identity -match '^S-1-') { return $Identity }
    try { return (New-Object Security.Principal.NTAccount($Identity)).Translate([Security.Principal.SecurityIdentifier]).Value } catch { return "" }
}

if (-not (Test-Path $ManifestPath -PathType Leaf)) { Fail "Install manifest missing." }
try { $m = Get-Content $ManifestPath -Raw | ConvertFrom-Json } catch { Fail "Install manifest JSON invalid." }
if ($m.schema -ne 'DiskGuardSpace.StartupInstall.v1' -or $m.product -ne 'DiskGuardSpace' -or $m.version -ne '1.4') { Fail "Install manifest identity mismatch." }
if ([IO.Path]::GetFullPath([string]$m.installRoot).TrimEnd('\') -ne [IO.Path]::GetFullPath($InstallRoot).TrimEnd('\')) { Fail "Install root mismatch." }
if ((((Get-Item $InstallRoot -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0)) { Fail "Install root is a reparse point." }

foreach ($f in @($m.files)) {
    $name = [string]$f.name
    if ([IO.Path]::IsPathRooted($name) -or $name.Contains('..') -or $name.Contains('\') -or $name.Contains('/')) { Fail "Unsafe installed-file manifest entry: $name" }
    $p = Join-Path $InstallRoot $name
    if (-not (Test-Path $p -PathType Leaf)) { Fail "Installed file missing: $name" }
    if ((Get-Sha256 $p) -ne ([string]$f.sha256).ToLowerInvariant()) { Fail "Installed file SHA-256 mismatch: $name" }
    if ((Get-Item $p).Length -ne [long]$f.sizeBytes) { Fail "Installed file size mismatch: $name" }
}

$canonicalPs = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
if ([IO.Path]::GetFullPath([string]$m.canonicalPowerShell) -ne [IO.Path]::GetFullPath($canonicalPs)) { Fail "Canonical PowerShell identity mismatch." }
if (-not (Test-Path $canonicalPs -PathType Leaf)) { Fail "Canonical PowerShell missing." }

$task = Get-ScheduledTask -TaskPath ([string]$m.taskPath) -TaskName ([string]$m.taskName) -ErrorAction SilentlyContinue
if (-not $task) { Fail "Scheduled task missing." }
if (-not $task.Settings.Enabled -or -not $task.Settings.Hidden) { Fail "Task must be enabled and hidden." }
if ([string]$task.Settings.MultipleInstances -ne 'IgnoreNew') { Fail "Task multiple-instance policy is not IgnoreNew." }
if (@($task.Actions).Count -ne 1) { Fail "Task must have exactly one action." }
$action = @($task.Actions)[0]
if ([IO.Path]::GetFullPath([string]$action.Execute) -ne [IO.Path]::GetFullPath($canonicalPs)) { Fail "Task executable is not canonical Windows PowerShell." }
if ([string]$action.Arguments -ne [string]$m.actionArguments) { Fail "Task arguments differ from the verified install manifest." }
if ([IO.Path]::GetFullPath([string]$action.WorkingDirectory).TrimEnd('\') -ne [IO.Path]::GetFullPath($InstallRoot).TrimEnd('\')) { Fail "Task working directory mismatch." }
if (@($task.Triggers).Count -ne 1) { Fail "Task must have exactly one trigger." }
$trigger = @($task.Triggers)[0]
if ($trigger.CimClass.CimClassName -ne 'MSFT_TaskLogonTrigger') { Fail "Task trigger must be a logon trigger." }
if ([string]$trigger.Delay -ne 'PT5M') { Fail "Task logon delay must be PT5M." }
$principalSid = Resolve-Sid ([string]$task.Principal.UserId)
if ($principalSid -ne [string]$m.expectedUserSid) { Fail "Task principal SID mismatch." }
if ([string]$task.Principal.RunLevel -ne 'Highest') { Fail "Task must use Highest run level." }
if ([string]$task.Principal.LogonType -notmatch 'Interactive') { Fail "Task must use an interactive user token." }

if ($RequireCurrentUser) {
    $currentSid = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
    if ($currentSid -ne [string]$m.expectedUserSid) { Fail "Background task is running under the wrong Windows user." }
}

Write-Host "STARTUP AUTOMATION VERIFY: VERIFIED_PASS" -ForegroundColor Green
Write-Host "Task: $($m.taskPath)$($m.taskName)"
Write-Host "User SID: $($m.expectedUserSid)"
Write-Host "Trigger: logon + PT5M"
exit 0
