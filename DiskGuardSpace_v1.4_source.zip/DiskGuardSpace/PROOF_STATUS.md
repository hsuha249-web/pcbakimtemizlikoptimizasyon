# DiskGuardSpace v1.4 Proof Status

## Proven in this workspace

- source-level fail-closed architecture audit: PASS
- static audit: PASS (265/265 checks)
- C# lexical structure balance checks: PASS
- PowerShell brace-balance checks: PASS
- source package manifest: regenerated during packaging
- release ZIP integrity: checked during packaging
- v0.6 allocation/cooldown/ADS/VHDX/executable-provenance negative-control audit: PASS
- v0.8 interrupted-run/runtime-process/blast-radius/system-volume static controls: PASS
- v0.9 volume-GUID/category-budget/proof-drift/state-durability/storage-event/duplicate-hash-budget static controls: PASS
- negative/regression scenarios present in source: 90

## Not claimed in this workspace

This workspace is not Windows and does not have the .NET 8 SDK/runtime used for the Windows target build. Therefore no Windows runtime/build result is fabricated here.

## Required target-PC proof

`FIRST_RUN.ps1` automatically runs the target proof chain:

1. `VERIFY_SOURCE.ps1`
2. `build-win-x64.ps1`
3. `self-test`
4. `negative-tests`
5. read-only safe scan + independent verification
6. bounded deep analysis + independent verification
7. read-only auto-care dry run + independent verification
8. verified startup-task installation + post-registration verification
9. fail-closed `auto-care --apply --deep-health`
10. `verify-auto-care` + release/startup identity re-verification

Apply does not start unless the pre-apply proof gate succeeds.

Expected success markers:

- `SOURCE MANIFEST: VERIFIED_PASS`
- `BUILD VERIFIED`
- `SELF_TEST: VERIFIED_PASS`
- `NEGATIVE_TESTS: VERIFIED_PASS`
- `PROOF RUN: PASS`
- `STARTUP AUTOMATION VERIFY: VERIFIED_PASS`
- `AUTOMATIC PC CARE + STARTUP AUTOMATION: VERIFIED PASS`

A safe bounded result may contain `VERIFIED_SCAN_BOUNDED` or `VERIFIED_PASS_BOUNDED` for individual evidence stages while the master report remains verifiable. Unsafe global gates produce `PARTIAL OR FAIL-CLOSED` instead of a false success.



## v0.9 proof additions

Static/source-level controls added for:

- Windows volume GUID cleanup authorization and quarantine identity proof.
- Per-category byte/file blast-radius budgets.
- Free-space proof drift classification.
- Protected state-store durability gating.
- Recent storage I/O event health gating.
- Duplicate full-hash byte/file work budgets.

Windows runtime/build claims are intentionally not made by this document until the controlled Windows pipeline runs. `BUILD_VERIFIED_EXE.cmd` remains the only release path for a distributable `dist\DiskGuardSpace.exe`.

## v0.8 controlled-EXE status

- Controlled staging/pending/final release architecture: static audit PASS.
- Strict source-manifest coverage architecture: static audit PASS.
- Independent release proof re-open architecture: static audit PASS.
- Exact EXE hash binding at staging/pending/final: static audit PASS.
- Local static audit after v0.8 changes: 178/178 PASS.
- Native Windows `dotnet publish`, packaged EXE self-test, negative tests and real-PC proof remain **NOT MEASURED in this Linux environment**. They are mandatory gates inside `BUILD_VERIFIED_EXE.ps1` on the target PC.


## v1.0 startup automation proof additions

Static/source-level proof now additionally checks: Program Files runtime installation, installed-file hash manifest, canonical PowerShell action, delayed per-user logon trigger, hidden/IgnoreNew task settings, post-registration task verification, once-per-boot guard, weekly/change-triggered packaged tests, explicit `STARTUP_BACKGROUND` master-report trigger mode, bounded background-session retention, and uninstall fail-closed behavior.

As with previous versions, actual Task Scheduler registration and real Windows runtime behavior must be proven on the target Windows PC by `FIRST_RUN.ps1`; this development environment does not claim that Windows runtime proof.

## v1.2 controller proof additions

v1.2 fixes the no-argument packaged-EXE behavior: double-click now opens a native runtime controller rather than printing help and immediately exiting.

New proof artifacts on Windows:

- `CONTROLLER_PROOF.json`: machine-readable packaged-EXE read-only runtime verification.
- `CONTROLLER_AUTOMATION_PROOF.json`: native Windows UI Automation evidence proving visible controller launch, real button invocation, generated proof, EXE SHA-256 identity and `STATUS: PASS`.

The controlled release pipeline includes controller verification both before promotion and after final release-proof creation. The post-promotion controller run additionally requires adjacent `RELEASE_PROOF.json` identity to match the exact binary.

## v1.2 startup/controller proof additions

v1.2 adds persistent startup evidence and non-vanishing launchers. A controller initialization exception is written as `DiskGuardSpace.CrashProof.v1` under `%LOCALAPPDATA%\DiskGuardSpace\Logs`. The build and first-run CMD launchers persist logs and pause on both success and failure. Parent-shell console hiding from v1.1 is removed; controller mode uses `FreeConsole()`.


## v1.4 Windows evidence-driven fix

The supplied v1.2 Windows build log reached controller gate 7 after passing source manifest, static audit, packaged self-test, 92/92 adversarial tests, and read-only PC proof. The window and named run button were both found, but `GetCurrentPattern(InvokePattern)` returned `Unsupported Pattern`. v1.4 replaces that single provider-dependent action with native HWND/class validation + `BM_CLICK`, followed by a required observed state transition and the existing machine-readable proof gates. Windows runtime success must still be re-proven on the target PC.

## v1.4 status

Source-side changes add the user-facing maintenance dashboard and cadence-controlled background policy. The v1.3 Windows evidence already proved the native controller/button path and final release controller identity. v1.4 must still be rebuilt and re-proven on the target Windows PC because the final binary hash changes. The release gate continues to require packaged self-test, negative/regression tests, real-PC read-only proof, native controller button activation, pending-byte identity, atomic promotion and final independent release/controller verification.
