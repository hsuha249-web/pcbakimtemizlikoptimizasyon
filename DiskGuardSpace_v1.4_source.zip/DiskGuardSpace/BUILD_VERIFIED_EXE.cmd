@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title DiskGuardSpace v1.4 - Verified EXE Build
if not exist "%~dp0logs" mkdir "%~dp0logs" >nul 2>&1
set "LOG=%~dp0logs\BUILD_LAST.log"

echo ============================================================
echo DiskGuardSpace v1.4 - Controlled Verified EXE Build
echo ============================================================
echo Output is also saved to:
echo %LOG%
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0BUILD_VERIFIED_EXE.ps1" >"%LOG%" 2>&1
set "EC=%ERRORLEVEL%"
type "%LOG%"
echo.
if "%EC%"=="0" (
  echo ============================================================
  echo BUILD VERIFIED EXE: PASS
  echo Output: %~dp0dist\DiskGuardSpace.exe
  echo Proof : %~dp0dist\RELEASE_PROOF.json
  echo ============================================================
) else (
  echo ============================================================
  echo BUILD VERIFIED EXE: FAIL-CLOSED ^(exit %EC%^)
  echo Hata kaydi kapanmayacak: %LOG%
  echo ============================================================
)
echo.
echo Pencereyi kapatmak icin bir tusa basin.
pause >nul
exit /b %EC%
