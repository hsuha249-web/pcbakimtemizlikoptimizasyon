using System.Text;

namespace DiskGuardSpace;

internal static class NegativeTests
{
    public static int Run()
    {
        var failures = new List<string>();
        var passes = new List<string>();
        var root = Path.Combine(Path.GetTempPath(), "DiskGuardSpace-Negative-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(root);
        try
        {
            var startupOpts = AutoCareOptions.Parse(new[] { "--startup-background" });
            Test("startup background mode is explicit and does not imply apply by itself", startupOpts.StartupBackground && !startupOpts.Apply, passes, failures);
            var cadenceOpts = AutoCareOptions.Parse(new[] { "--skip-deep-analysis" });
            Test("startup cadence can defer deep analysis without implying write mode", cadenceOpts.SkipDeepAnalysis && !cadenceOpts.Apply, passes, failures);


            var controllerTempProof = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Temp", "DiskGuardSpace-Controller-Negative-" + Guid.NewGuid().ToString("N"));
            Test("controller proof output is allowed under canonical LocalAppData Temp",
                ControllerPathPolicy.IsAllowedProofDirectory(controllerTempProof), passes, failures);
            var controllerProgramFilesProof = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "DiskGuardSpace-Controller-Proof");
            Test("controller proof output outside canonical LocalAppData is rejected",
                !ControllerPathPolicy.IsAllowedProofDirectory(controllerProgramFilesProof), passes, failures);
            Test("controller proof output rejects ADS syntax",
                !ControllerPathPolicy.IsAllowedProofDirectory(controllerTempProof + ":hidden"), passes, failures);
            bool controllerUnknownOptionRejected = false;
            try { _ = ControllerOptions.Parse(new[] { "--unknown-controller-option" }); }
            catch (ArgumentException) { controllerUnknownOptionRejected = true; }
            Test("controller rejects unknown command-line options", controllerUnknownOptionRejected, passes, failures);

            var crashLogRoot = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "DiskGuardSpace", "Logs");
            Test("crash diagnostics log root is restricted to canonical LocalAppData tree",
                CrashDiagnostics.IsAllowedLogDirectory(crashLogRoot), passes, failures);
            Test("crash diagnostics rejects an arbitrary external log directory",
                !CrashDiagnostics.IsAllowedLogDirectory(controllerProgramFilesProof), passes, failures);
            Test("crash diagnostics rejects ADS log-root syntax",
                !CrashDiagnostics.IsAllowedLogDirectory(crashLogRoot + ":hidden"), passes, failures);

            var allowed = Path.Combine(root, "allowed");
            var sibling = Path.Combine(root, "allowed_evil");
            Directory.CreateDirectory(allowed);
            Directory.CreateDirectory(sibling);

            Test("prefix-boundary escape rejected",
                !SafetyPolicy.IsUnderRoot(Path.Combine(sibling, "victim.bin"), allowed), passes, failures);
            Test("dot-dot traversal rejected",
                !SafetyPolicy.IsUnderRoot(Path.Combine(allowed, "..", "allowed_evil", "victim.bin"), allowed), passes, failures);
            Test("runtime directory is protected from cleanup",
                SafetyPolicy.IsRuntimeProtectedPath(Path.Combine(AppContext.BaseDirectory, "do-not-delete.tmp")), passes, failures);
            var nonCanonicalTempRoot = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "DiskGuardSpace-Negative-Temp");
            Test("arbitrary TEMP-category root is not canonical",
                !SafetyPolicy.IsCanonicalApprovedRoot(new ApprovedRoot(nonCanonicalTempRoot, "TEMP", 1)), passes, failures);
            Test("NTFS alternate-data-stream syntax is rejected",
                SafetyPolicy.HasUnsafePathSyntax(Path.Combine(allowed, "victim.tmp") + ":hidden"), passes, failures);
            Test("Win32 device path syntax is rejected",
                SafetyPolicy.HasUnsafePathSyntax(@"\\?\C:\Temp\victim.tmp"), passes, failures);

            var windowsRootForVolumeTest = Path.GetPathRoot(Environment.GetFolderPath(Environment.SpecialFolder.Windows)) ?? "C:\\";
            var otherVolumeRoot = windowsRootForVolumeTest.StartsWith("C:", StringComparison.OrdinalIgnoreCase) ? "D:\\" : "C:\\";
            Test("automatic cleanup authority is bound to the system volume",
                SafetyPolicy.IsOnSystemVolume(Environment.GetFolderPath(Environment.SpecialFolder.Windows)) && !SafetyPolicy.IsOnSystemVolume(otherVolumeRoot), passes, failures);
            Test("system-volume authorization resolves a canonical Windows volume identity",
                SafetyPolicy.TryGetVolumeIdentityForTests(Environment.GetFolderPath(Environment.SpecialFolder.Windows), out var systemVolumeIdentity)
                && systemVolumeIdentity.StartsWith("\\\\?\\Volume{", StringComparison.OrdinalIgnoreCase), passes, failures);

            var syntheticWindows = @"C:\Windows";
            Test("bare executable name is rejected for maintenance probes",
                !PcHealthDiagnostics.IsTrustedExecutablePathForTests("fsutil.exe", syntheticWindows), passes, failures);
            Test("canonical System32 executable path is accepted for maintenance probes",
                PcHealthDiagnostics.IsTrustedExecutablePathForTests(@"C:\Windows\System32\fsutil.exe", syntheticWindows), passes, failures);
            Test("lookalike System32 sibling executable path is rejected",
                !PcHealthDiagnostics.IsTrustedExecutablePathForTests(@"C:\Windows\System32_evil\fsutil.exe", syntheticWindows), passes, failures);

            Test("read-only diagnostic rejects bare executable path",
                !ReadOnlyMaintenanceDiagnostics.DiagnosticExecutablePathMatchesPolicyForTests("dism.exe", syntheticWindows), passes, failures);
            Test("read-only diagnostic rejects System32 lookalike sibling",
                !ReadOnlyMaintenanceDiagnostics.DiagnosticExecutablePathMatchesPolicyForTests(@"C:\Windows\System32_evil\dism.exe", syntheticWindows), passes, failures);
            Test("read-only diagnostic accepts canonical System32 executable",
                ReadOnlyMaintenanceDiagnostics.DiagnosticExecutablePathMatchesPolicyForTests(@"C:\Windows\System32\dism.exe", syntheticWindows), passes, failures);

            var protectedState = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "DiskGuardSpace", "State", "maintenance-cooldowns.json");
            Test("DiskGuardSpace persistent evidence/state tree is self-protected", SafetyPolicy.IsRuntimeProtectedPath(protectedState), passes, failures);

            var oldTemp = Environment.GetEnvironmentVariable("TEMP");
            var oldTmp = Environment.GetEnvironmentVariable("TMP");
            try
            {
                Environment.SetEnvironmentVariable("TEMP", sibling);
                Environment.SetEnvironmentVariable("TMP", sibling);
                var canonicalRoots = SafetyPolicy.GetApprovedCleanupRoots();
                Test("poisoned TEMP/TMP cannot authorize arbitrary cleanup root",
                    !canonicalRoots.Any(x => SafetyPolicy.Normalize(x.Path).Equals(SafetyPolicy.Normalize(sibling), StringComparison.OrdinalIgnoreCase)), passes, failures);
            }
            finally
            {
                Environment.SetEnvironmentVariable("TEMP", oldTemp);
                Environment.SetEnvironmentVariable("TMP", oldTmp);
            }

            var young = Path.Combine(allowed, "young.tmp");
            File.WriteAllText(young, "young");
            Test("young file not eligible", !SafetyPolicy.IsOldEnough(young, 3), passes, failures);

            var zero = Path.Combine(allowed, "zero.tmp");
            File.WriteAllBytes(zero, Array.Empty<byte>());
            File.SetLastWriteTimeUtc(zero, DateTime.UtcNow.AddDays(-10));
            var zeroScan = Scanner.ScanApprovedRoots(new[] { new ApprovedRoot(allowed, "SELF_TEST", 1) }, 1);
            Test("zero-byte files are excluded from cleanup candidates",
                !zeroScan.Candidates.Any(c => c.Path.Equals(zero, StringComparison.OrdinalIgnoreCase)), passes, failures);

            var changed = Path.Combine(allowed, "changed.tmp");
            File.WriteAllBytes(changed, new byte[4096]);
            File.SetLastWriteTimeUtc(changed, DateTime.UtcNow.AddDays(-10));
            var changedCandidate = new Candidate(changed, 4096, File.GetLastWriteTimeUtc(changed), "SELF_TEST", "SAFE", allowed);
            File.AppendAllText(changed, "mutation");
            var changedExec = Cleaner.ExecuteSafeCandidates(new[] { changedCandidate }, new[] { new ApprovedRoot(allowed, "SELF_TEST", 1) }, null);
            Test("changed-since-scan blocked and preserved", changedExec.Blocked == 1 && File.Exists(changed), passes, failures);

            var locked = Path.Combine(allowed, "locked.tmp");
            File.WriteAllBytes(locked, new byte[4096]);
            File.SetLastWriteTimeUtc(locked, DateTime.UtcNow.AddDays(-10));
            var lockedCandidate = new Candidate(locked, 4096, File.GetLastWriteTimeUtc(locked), "SELF_TEST", "SAFE", allowed);
            using (var lockStream = new FileStream(locked, FileMode.Open, FileAccess.ReadWrite, FileShare.None))
            {
                var lockedExec = Cleaner.ExecuteSafeCandidates(new[] { lockedCandidate }, new[] { new ApprovedRoot(allowed, "SELF_TEST", 1) }, null);
                Test("exclusive-lock causes fail-closed preservation", lockedExec.Blocked == 1 && File.Exists(locked), passes, failures);
            }

            var writerOpen = Path.Combine(allowed, "writer-open.tmp");
            File.WriteAllBytes(writerOpen, new byte[4096]);
            File.SetLastWriteTimeUtc(writerOpen, DateTime.UtcNow.AddDays(-10));
            var writerCandidate = new Candidate(writerOpen, 4096, File.GetLastWriteTimeUtc(writerOpen), "SELF_TEST", "SAFE", allowed);
            using (var writer = new FileStream(writerOpen, FileMode.Open, FileAccess.Write, FileShare.ReadWrite | FileShare.Delete))
            {
                var writerExec = Cleaner.ExecuteSafeCandidates(new[] { writerCandidate }, new[] { new ApprovedRoot(allowed, "SELF_TEST", 1) }, null);
                Test("existing writer blocks locked verification and preserves source", writerExec.Blocked == 1 && File.Exists(writerOpen), passes, failures);
            }

            var readOnly = Path.Combine(allowed, "readonly.tmp");
            File.WriteAllBytes(readOnly, new byte[4096]);
            File.SetLastWriteTimeUtc(readOnly, DateTime.UtcNow.AddDays(-10));
            var readOnlyTime = File.GetLastWriteTimeUtc(readOnly);
            File.SetAttributes(readOnly, File.GetAttributes(readOnly) | FileAttributes.ReadOnly);
            var readOnlyCandidate = new Candidate(readOnly, 4096, readOnlyTime, "SELF_TEST", "SAFE", allowed);
            var readOnlyExec = Cleaner.ExecuteSafeCandidates(new[] { readOnlyCandidate }, new[] { new ApprovedRoot(allowed, "SELF_TEST", 1) }, null);
            Test("read-only file is fail-closed and preserved", readOnlyExec.Blocked == 1 && File.Exists(readOnly), passes, failures);
            File.SetAttributes(readOnly, FileAttributes.Normal);

            var hardSource = Path.Combine(allowed, "hard-source.tmp");
            var hardLink = Path.Combine(allowed, "hard-link.tmp");
            File.WriteAllBytes(hardSource, new byte[8192]);
            File.SetLastWriteTimeUtc(hardSource, DateTime.UtcNow.AddDays(-10));
            if (VerifiedWindowsFile.TryCreateHardLinkForTests(hardLink, hardSource))
            {
                var hardCandidate = new Candidate(hardSource, 8192, File.GetLastWriteTimeUtc(hardSource), "SELF_TEST", "SAFE", allowed);
                var hardExec = Cleaner.ExecuteSafeCandidates(new[] { hardCandidate }, new[] { new ApprovedRoot(allowed, "SELF_TEST", 1) }, null);
                Test("hard-linked file is rejected and both links preserved", hardExec.Blocked == 1 && File.Exists(hardSource) && File.Exists(hardLink), passes, failures);
            }
            else
            {
                Test("hard-link negative-control fixture could be created", false, passes, failures);
            }

            var sameVolume = Path.Combine(allowed, "samevolume.tmp");
            File.WriteAllBytes(sameVolume, new byte[4096]);
            File.SetLastWriteTimeUtc(sameVolume, DateTime.UtcNow.AddDays(-10));
            var sameCandidate = new Candidate(sameVolume, 4096, File.GetLastWriteTimeUtc(sameVolume), "SELF_TEST", "SAFE", allowed);
            var quarantine = Path.Combine(root, "quarantine");
            var sameExec = Cleaner.ExecuteSafeCandidates(new[] { sameCandidate }, new[] { new ApprovedRoot(allowed, "SELF_TEST", 1) }, quarantine);
            Test("same-volume quarantine refused and source preserved", sameExec.Failed == 1 && File.Exists(sameVolume), passes, failures);

            var dupDir = Path.Combine(root, "dup");
            Directory.CreateDirectory(dupDir);
            var f1 = Path.Combine(dupDir, "a.bin");
            var f2 = Path.Combine(dupDir, "b.bin");
            var f3 = Path.Combine(dupDir, "c.bin");
            WriteQuickCollisionPair(f1, f2);
            File.Copy(f1, f3);
            var groups = DuplicateFinder.Find(new[] { dupDir }, 1, 10, out var violations);
            Test("quick fingerprint collision resolved by full SHA-256", violations == 0 && groups.Count == 1 && groups[0].Files.Count == 2, passes, failures);

            Test("duplicate full-hash byte budget rejects an oversized next file",
                !DuplicateHashBudget.CanHash(0, 0, DuplicateHashBudget.MaxFullHashBytes + 1), passes, failures);
            Test("duplicate full-hash file-count budget is finite",
                !DuplicateHashBudget.CanHash(0, DuplicateHashBudget.MaxFullHashFiles, 1)
                && DuplicateHashBudget.MaxFullHashFiles > 0 && DuplicateHashBudget.MaxFullHashFiles <= 1024, passes, failures);
            Test("duplicate full-hash budget permits work strictly inside both caps",
                DuplicateHashBudget.CanHash(DuplicateHashBudget.MaxFullHashBytes - 1024, DuplicateHashBudget.MaxFullHashFiles - 1, 1024), passes, failures);

            Test("allocation fallback never invents negative physical bytes",
                NtfsAllocationProbe.NormalizeForTests(1234, -1) == 1234 && NtfsAllocationProbe.NormalizeForTests(-5, null) == 0, passes, failures);
            Test("space-pressure tiers prioritize emergency recovery",
                SpacePressurePolicy.Classify(500L * 1024 * 1024, 100L * 1024 * 1024 * 1024) == "EMERGENCY"
                && SpacePressurePolicy.Classify(50L * 1024 * 1024 * 1024, 100L * 1024 * 1024 * 1024) == "HEALTHY", passes, failures);

            var now = DateTime.UtcNow;
            Test("future cooldown timestamp fail-closes heavy maintenance",
                MaintenanceCooldownJournal.EvaluateTimestampForTests(now, now.AddHours(1), TimeSpan.FromDays(1)), passes, failures);
            Test("recent heavy maintenance respects cooldown",
                MaintenanceCooldownJournal.EvaluateTimestampForTests(now, now.AddHours(-1), TimeSpan.FromDays(1)), passes, failures);
            Test("expired heavy-maintenance cooldown permits reconsideration",
                !MaintenanceCooldownJournal.EvaluateTimestampForTests(now, now.AddDays(-8), TimeSpan.FromDays(7)), passes, failures);

            var runId = Guid.NewGuid().ToString("N");
            Test("interrupted prior auto-care run triggers recovery mode",
                MaintenanceRunJournal.EvaluateStateForTests("1.0", runId, "IN_PROGRESS", now.AddMinutes(-5), now.AddMinutes(-1), now), passes, failures);
            Test("completed prior auto-care run does not trigger recovery mode",
                !MaintenanceRunJournal.EvaluateStateForTests("1.0", runId, "COMPLETED", now.AddMinutes(-5), now.AddMinutes(-1), now), passes, failures);
            Test("future auto-care journal timestamp triggers recovery mode",
                MaintenanceRunJournal.EvaluateStateForTests("1.0", runId, "COMPLETED", now.AddMinutes(-5), now.AddHours(1), now), passes, failures);
            Test("malformed auto-care run identity triggers recovery mode",
                MaintenanceRunJournal.EvaluateStateForTests("1.0", "not-a-guid", "COMPLETED", now.AddMinutes(-5), now.AddMinutes(-1), now), passes, failures);

            var recoveryGate = new PreflightResult();
            AutoCarePreflight.ApplyInterruptedRunGate(recoveryGate, true, "synthetic interrupted run");
            Test("interrupted-run gate suppresses every heavy write stage without global-blocking safe cleanup",
                !recoveryGate.GlobalWriteBlocked
                && recoveryGate.IsFeatureSkipped("DELIVERY_OPTIMIZATION")
                && recoveryGate.IsFeatureSkipped("COMPONENT_CLEANUP")
                && recoveryGate.IsFeatureSkipped("DRIVE_OPTIMIZATION"), passes, failures);

            var healthyBudget = CleanupBlastRadiusPolicy.ComputeBudgetBytes(100L * 1024 * 1024 * 1024, 50L * 1024 * 1024 * 1024);
            var emergencyBudget = CleanupBlastRadiusPolicy.ComputeBudgetBytes(100L * 1024 * 1024 * 1024, 500L * 1024 * 1024);
            Test("cleanup blast-radius budget expands under emergency space pressure but remains capped",
                emergencyBudget > healthyBudget && emergencyBudget <= 128L * 1024 * 1024 * 1024 && healthyBudget >= 8L * 1024 * 1024 * 1024, passes, failures);
            Test("cleanup blast-radius file-count cap is finite",
                CleanupBlastRadiusPolicy.MaxFilesPerRun > 0 && CleanupBlastRadiusPolicy.MaxFilesPerRun <= 200_000, passes, failures);
            var categoryBudget = CleanupBlastRadiusPolicy.ComputeCategoryBudgetBytes(emergencyBudget);
            Test("per-category cleanup byte budget cannot consume the whole run budget",
                categoryBudget > 0 && categoryBudget <= emergencyBudget / 2 && categoryBudget <= 32L * 1024 * 1024 * 1024, passes, failures);
            Test("per-category cleanup file-count cap is stricter than per-run cap",
                CleanupBlastRadiusPolicy.MaxFilesPerCategory > 0 && CleanupBlastRadiusPolicy.MaxFilesPerCategory < CleanupBlastRadiusPolicy.MaxFilesPerRun, passes, failures);

            Test("free-space proof accepts allocation-consistent reclaim",
                FreeSpaceProofPolicy.Classify(1024L * 1024 * 1024, 900L * 1024 * 1024) == "CONSISTENT", passes, failures);
            Test("free-space proof marks concurrent volume drift as bounded",
                FreeSpaceProofPolicy.Classify(1024L * 1024 * 1024, 300L * 1024 * 1024) == "CONCURRENT_VOLUME_ACTIVITY", passes, failures);
            Test("free-space proof rejects successful-delete claim with no observed gain",
                FreeSpaceProofPolicy.Classify(1024L * 1024 * 1024, 0) == "INCONSISTENT_NO_OBSERVED_GAIN", passes, failures);
            Test("free-space proof arithmetic is overflow-safe for hostile extreme values",
                FreeSpaceProofPolicy.Classify(long.MaxValue, 1) == "CONCURRENT_VOLUME_ACTIVITY", passes, failures);

            Test("storage reliability probe classifies zero targeted events as healthy",
                StorageReliabilityPolicy.Classify("exit=0; RISK_COUNT=0") == "HEALTHY", passes, failures);
            Test("single recent storage I/O event suppresses only heavy maintenance",
                StorageReliabilityPolicy.Classify("exit=0; RISK_COUNT=1") == "HEAVY_ONLY", passes, failures);
            Test("repeated recent storage I/O events block write maintenance",
                StorageReliabilityPolicy.Classify("exit=0; RISK_COUNT=2") == "BLOCK_WRITES", passes, failures);
            Test("malformed storage reliability probe cannot claim healthy",
                StorageReliabilityPolicy.Classify("RISK_COUNT=not-a-number") == "UNKNOWN", passes, failures);
            Test("state-store durability policy rejects a readback mismatch",
                !StateStoreHealthProbe.EvaluateForTests(false, true, true, false), passes, failures);
            Test("state-store durability policy requires trusted fixed local volume and self-protected path",
                !StateStoreHealthProbe.EvaluateForTests(false, false, true, true)
                && !StateStoreHealthProbe.EvaluateForTests(false, true, false, true), passes, failures);

            var singleIoHealth = new PcHealthSnapshot(now, TimeSpan.Zero, 0, 0, false, "Healthy", "", "", "RISK_COUNT=1", "NORMAL");
            var singleIoGate = new PreflightResult();
            AutoCarePreflight.ApplyPhysicalDiskHealthGate(singleIoGate, singleIoHealth);
            Test("single storage I/O event gate preserves safe cleanup but suppresses every heavy write stage",
                !singleIoGate.GlobalWriteBlocked
                && singleIoGate.IsFeatureSkipped("DELIVERY_OPTIMIZATION")
                && singleIoGate.IsFeatureSkipped("COMPONENT_CLEANUP")
                && singleIoGate.IsFeatureSkipped("DRIVE_OPTIMIZATION"), passes, failures);

            var repeatedIoHealth = new PcHealthSnapshot(now, TimeSpan.Zero, 0, 0, false, "Healthy", "", "", "RISK_COUNT=3", "NORMAL");
            var repeatedIoGate = new PreflightResult();
            AutoCarePreflight.ApplyPhysicalDiskHealthGate(repeatedIoGate, repeatedIoHealth);
            Test("repeated storage I/O events global-block all write maintenance", repeatedIoGate.GlobalWriteBlocked, passes, failures);

            Test("browser cache category has runtime owning-process guard",
                RuntimeFeatureGuard.OwningProcessesForCategoryForTests("CHROME_CACHE").Contains("chrome", StringComparer.OrdinalIgnoreCase), passes, failures);
            Test("non-application SELF_TEST category does not invent process guard",
                RuntimeFeatureGuard.OwningProcessesForCategoryForTests("SELF_TEST").Length == 0, passes, failures);

            var forgedCategory = Path.Combine(allowed, "forged-category.tmp");
            File.WriteAllBytes(forgedCategory, new byte[4096]);
            File.SetLastWriteTimeUtc(forgedCategory, DateTime.UtcNow.AddDays(-10));
            var forgedCategoryCandidate = new Candidate(forgedCategory, 4096, File.GetLastWriteTimeUtc(forgedCategory), "CHROME_CACHE", "SAFE", allowed);
            var forgedCategoryExec = Cleaner.ExecuteSafeCandidates(new[] { forgedCategoryCandidate }, new[] { new ApprovedRoot(allowed, "SELF_TEST", 1) }, null);
            Test("forged candidate category cannot bypass owning-root policy", forgedCategoryExec.Blocked == 1 && File.Exists(forgedCategory), passes, failures);

            var forgedYoung = Path.Combine(allowed, "forged-young.tmp");
            File.WriteAllBytes(forgedYoung, new byte[4096]);
            File.SetLastWriteTimeUtc(forgedYoung, DateTime.UtcNow.AddDays(-2));
            var forgedYoungCandidate = new Candidate(forgedYoung, 4096, File.GetLastWriteTimeUtc(forgedYoung), "SELF_TEST", "SAFE", allowed);
            var forgedYoungExec = Cleaner.ExecuteSafeCandidates(new[] { forgedYoungCandidate }, new[] { new ApprovedRoot(allowed, "SELF_TEST", 30) }, null);
            Test("cleaner rechecks approved-root age policy at delete time", forgedYoungExec.Blocked == 1 && File.Exists(forgedYoung), passes, failures);

            Test("compressed media excluded from compression estimator", !CompressionEstimator.IsWorthSampling("video.mp4"), passes, failures);
            Test("System32 is forbidden cleanup root",
                SafetyPolicy.IsForbiddenCleanupRoot(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), "System32")), passes, failures);

            Test("Windows Update cache is not an approved direct cleanup root",
                !SafetyPolicy.GetApprovedCleanupRoots().Any(x => x.Path.Contains("SoftwareDistribution", StringComparison.OrdinalIgnoreCase)), passes, failures);
            Test("Windows Installer cache is not an approved cleanup root",
                !SafetyPolicy.GetApprovedCleanupRoots().Any(x => x.Path.EndsWith(Path.Combine("Windows", "Installer"), StringComparison.OrdinalIgnoreCase)), passes, failures);
            Test("virtual-disk files can never become direct cleanup roots",
                !SafetyPolicy.GetApprovedCleanupRoots().Any(x => x.Path.EndsWith(".vhdx", StringComparison.OrdinalIgnoreCase)), passes, failures);
            Test("developer package stores remain outside automatic cleanup roots",
                !SafetyPolicy.GetApprovedCleanupRoots().Any(x => x.Path.Contains(".nuget", StringComparison.OrdinalIgnoreCase) || x.Path.Contains(".gradle", StringComparison.OrdinalIgnoreCase) || x.Path.Contains(".m2", StringComparison.OrdinalIgnoreCase) || x.Path.Contains(".cargo", StringComparison.OrdinalIgnoreCase)), passes, failures);

            Test("read-only diagnostic policy rejects VSS deletion",
                !AutoCareRunner.DiagnosticCommandMatchesPolicyForTests(new DiagnosticCommandResult("VSS_SHADOW_STORAGE", false, 0, "vssadmin.exe delete shadows /all", "", "", true)), passes, failures);
            Test("read-only diagnostic policy rejects defrag write optimization",
                !AutoCareRunner.DiagnosticCommandMatchesPolicyForTests(new DiagnosticCommandResult("DEFRAG_ANALYZE", false, 0, "defrag.exe C: /O /V", "", "", true)), passes, failures);
            Test("read-only diagnostic policy accepts defrag analysis only",
                AutoCareRunner.DiagnosticCommandMatchesPolicyForTests(new DiagnosticCommandResult("DEFRAG_ANALYZE", true, 0, "defrag.exe C: /A /V", "", "", true)), passes, failures);

            var tampered = new EvidenceReport
            {
                Mode = "clean-safe",
                FreeBytesBefore = 1000,
                FreeBytesAfter = 2000,
                VerifiedFreeGainBytes = 999,
                CandidateCount = 1,
                CandidateBytes = 10,
                SucceededActions = 1,
                Actions = new List<ActionEvidence> { new("X", null, 10, new string('A', 64), "DELETE", "VERIFIED", null) }
            };
            Test("tampered evidence arithmetic rejected", EvidenceVerifier.Verify(tampered).Status == "VERIFY_FAIL", passes, failures);

            var badHashEvidence = new EvidenceReport
            {
                Mode = "clean-safe", FreeBytesBefore = 1000, FreeBytesAfter = 2000, VerifiedFreeGainBytes = 1000,
                CandidateCount = 1, CandidateBytes = 10, SucceededActions = 1, SourceBytesRemoved = 10,
                Actions = new List<ActionEvidence> { new("X", null, 10, new string('Z', 64), "DELETE_LOCKED", "VERIFIED", null) }
            };
            Test("non-hex SHA-256 evidence rejected", EvidenceVerifier.Verify(badHashEvidence).Status == "VERIFY_FAIL", passes, failures);

            var badPhysicalEvidence = new EvidenceReport
            {
                Mode = "clean-safe", FreeBytesBefore = 1000, FreeBytesAfter = 1100, VerifiedFreeGainBytes = 100,
                CandidateCount = 1, CandidateBytes = 100, CandidateAllocatedBytes = 80, SucceededActions = 1,
                SourceBytesRemoved = 100, SourceAllocatedBytesRemoved = 79, VerificationStatus = "VERIFIED_PASS",
                Actions = new List<ActionEvidence> { new("X", null, 100, new string('A', 64), "DELETE_BY_VERIFIED_HANDLE", "VERIFIED", null, 80) }
            };
            Test("tampered physical-allocation evidence rejected", EvidenceVerifier.Verify(badPhysicalEvidence).Status == "VERIFY_FAIL", passes, failures);

            var atomic = Path.Combine(root, "atomic-report.json");
            AtomicFile.WriteAllText(atomic, "one");
            AtomicFile.WriteAllText(atomic, "two");
            Test("atomic report replacement leaves complete final file", File.ReadAllText(atomic) == "two", passes, failures);
            Test("atomic report replacement leaves no temp sibling", !Directory.EnumerateFiles(root, ".atomic-report.json.*.tmp").Any(), passes, failures);

            var scanEvidencePath = Path.Combine(root, "scan-evidence.json");
            var scanEvidence = new EvidenceReport
            {
                Mode = "auto-care-safe-scan", FreeBytesBefore = 1000, FreeBytesAfter = 1000, VerifiedFreeGainBytes = 0,
                CandidateCount = 0, CandidateBytes = 0, FailClosedViolations = 0, VerificationStatus = "VERIFIED_SCAN"
            };
            AtomicFile.WriteAllText(scanEvidencePath, System.Text.Json.JsonSerializer.Serialize(scanEvidence, Json.Options));
            Test("linked read-only scan accepts VERIFIED_SCAN status", AutoCareRunner.VerifyLinkedEvidenceFileForTests(scanEvidencePath), passes, failures);

            var boundedScanPath = Path.Combine(root, "scan-bounded-evidence.json");
            var boundedScanEvidence = new EvidenceReport
            {
                Mode = "auto-care-safe-scan", FreeBytesBefore = 1000, FreeBytesAfter = 1000, VerifiedFreeGainBytes = 0,
                CandidateCount = 0, CandidateBytes = 0, ReadErrors = 1, FailClosedViolations = 0, VerificationStatus = "VERIFIED_SCAN_BOUNDED"
            };
            AtomicFile.WriteAllText(boundedScanPath, System.Text.Json.JsonSerializer.Serialize(boundedScanEvidence, Json.Options));
            Test("linked bounded scan accepts explicit VERIFIED_SCAN_BOUNDED status", AutoCareRunner.VerifyLinkedEvidenceFileForTests(boundedScanPath), passes, failures);

            var wrongBoundedScan = new EvidenceReport
            {
                Mode = "auto-care-safe-scan", FreeBytesBefore = 1000, FreeBytesAfter = 1000, VerifiedFreeGainBytes = 0,
                CandidateCount = 0, CandidateBytes = 0, ReadErrors = 1, FailClosedViolations = 0, VerificationStatus = "VERIFIED_SCAN"
            };
            Test("scan with read errors cannot claim unbounded VERIFIED_SCAN", EvidenceVerifier.Verify(wrongBoundedScan).Status == "VERIFY_FAIL", passes, failures);

            var boundedCleanup = new EvidenceReport
            {
                Mode = "auto-care-safe-cleanup", FreeBytesBefore = 1000, FreeBytesAfter = 1000, VerifiedFreeGainBytes = 0,
                CandidateCount = 1, CandidateBytes = 10, BlockedActions = 1, ReadErrors = 0, FailClosedViolations = 0,
                FreeSpaceProofAssessment = "NO_FILE_RECLAIM", VerificationStatus = "VERIFIED_PASS_BOUNDED",
                Actions = new List<ActionEvidence> { new("X", null, 10, "", "BLOCK", "FAIL_CLOSED", "preserved") }
            };
            Test("file-level fail-closed skip can verify as bounded cleanup", EvidenceVerifier.Verify(boundedCleanup).Status == "VERIFIED_PASS", passes, failures);

            var driftBoundedCleanup = new EvidenceReport
            {
                Mode = "auto-care-safe-cleanup", FreeBytesBefore = 1000, FreeBytesAfter = 300L * 1024 * 1024 + 1000, VerifiedFreeGainBytes = 300L * 1024 * 1024,
                CandidateCount = 1, CandidateBytes = 1024L * 1024 * 1024, CandidateAllocatedBytes = 1024L * 1024 * 1024, SucceededActions = 1,
                SourceBytesRemoved = 1024L * 1024 * 1024, SourceAllocatedBytesRemoved = 1024L * 1024 * 1024, FreeSpaceProofAssessment = "CONCURRENT_VOLUME_ACTIVITY",
                VerificationStatus = "VERIFIED_PASS_BOUNDED",
                Actions = new List<ActionEvidence> { new("X", null, 1024L * 1024 * 1024, new string('A', 64), "DELETE_BY_VERIFIED_HANDLE", "VERIFIED", null, 1024L * 1024 * 1024) }
            };
            Test("concurrent volume activity cannot be mislabeled as exact cleanup proof", EvidenceVerifier.Verify(driftBoundedCleanup).Status == "VERIFIED_PASS", passes, failures);

            var globalViolationCannotBound = new EvidenceReport
            {
                Mode = "auto-care-safe-cleanup", FreeBytesBefore = 1000, FreeBytesAfter = 1000, VerifiedFreeGainBytes = 0,
                CandidateCount = 0, CandidateBytes = 0, FailClosedViolations = 1, VerificationStatus = "VERIFIED_PASS_BOUNDED"
            };
            Test("global safety violation cannot be downgraded to bounded success", EvidenceVerifier.Verify(globalViolationCannotBound).Status == "VERIFY_FAIL", passes, failures);

            var maintenanceEvidence = new EvidenceReport
            {
                Mode = "windows-component-cleanup", FreeBytesBefore = 1000, FreeBytesAfter = 1100, VerifiedFreeGainBytes = 100,
                CandidateCount = 1, SucceededActions = 1, SourceBytesRemoved = 100, VerificationStatus = "VERIFIED_PASS",
                Maintenance = new MaintenanceExecution(true, 0, "ok", "", "dism.exe /Online /Cleanup-Image /StartComponentCleanup /NoRestart")
            };
            Test("maintenance evidence does not require per-file action rows", EvidenceVerifier.Verify(maintenanceEvidence).Status == "VERIFIED_PASS", passes, failures);

            var ar = new AnalysisReport
            {
                DuplicateGroups = new List<DuplicateGroup> { new(new string('A', 64), 100, new List<string> { "A", "B" }, 1) },
                DuplicatePotentialSavingsBytes = 1,
                CompressionEstimatedSavingsBytes = 0,
                TotalEstimatedOpportunityBytes = 1
            };
            Test("tampered duplicate arithmetic rejected", AnalysisVerifier.Verify(ar).Status == "VERIFY_FAIL", passes, failures);

            var physicalTamper = new AnalysisReport
            {
                VerificationStatus = "VERIFIED_ANALYSIS", FreeBytesBefore = 1000, FreeBytesAfter = 1000,
                DuplicateGroups = new List<DuplicateGroup>
                {
                    new(new string('A', 64), 100, new List<string> { "A", "B" }, 100, new List<long> { 40, 60 }, 999)
                },
                DuplicatePotentialSavingsBytes = 100, DuplicatePhysicalPotentialSavingsBytes = 999, TotalEstimatedOpportunityBytes = 999
            };
            Test("tampered physical duplicate-savings arithmetic rejected", AnalysisVerifier.Verify(physicalTamper).Status == "VERIFY_FAIL", passes, failures);

            var bounded = new AnalysisReport
            {
                VerificationStatus = "VERIFIED_ANALYSIS_BOUNDED", ReadErrors = 1, InventoryFilesScanned = 10, InventoryBytesScanned = 100,
                AnalysisTruncated = false, FailClosedViolations = 0, FreeBytesBefore = 1000, FreeBytesAfter = 1000
            };
            Test("bounded read-only analysis is verifiable when limitation is explicit", AnalysisVerifier.Verify(bounded).Status == "VERIFIED_PASS", passes, failures);

            var allocationBounded = new AnalysisReport
            {
                VerificationStatus = "VERIFIED_ANALYSIS_BOUNDED", AllocationMeasurementErrors = 2, InventoryFilesScanned = 2,
                InventoryBytesScanned = 200, InventoryAllocatedBytesScanned = 200, FreeBytesBefore = 1000, FreeBytesAfter = 1000
            };
            Test("allocation-probe fallback is disclosed as bounded analysis", AnalysisVerifier.Verify(allocationBounded).Status == "VERIFIED_PASS", passes, failures);

            var dishonestAllocationExact = new AnalysisReport
            {
                VerificationStatus = "VERIFIED_ANALYSIS", AllocationMeasurementErrors = 1, InventoryFilesScanned = 1,
                InventoryBytesScanned = 100, InventoryAllocatedBytesScanned = 100, FreeBytesBefore = 1000, FreeBytesAfter = 1000
            };
            Test("allocation-probe fallback cannot claim exact analysis", AnalysisVerifier.Verify(dishonestAllocationExact).Status == "VERIFY_FAIL", passes, failures);

            Console.WriteLine($"NEGATIVE_TESTS: {(failures.Count == 0 ? "VERIFIED_PASS" : "FAIL")} ({passes.Count} pass / {failures.Count} fail)");
            foreach (var p in passes) Console.WriteLine(" PASS: " + p);
            foreach (var f in failures) Console.WriteLine(" FAIL: " + f);
            return failures.Count == 0 ? 0 : 80;
        }
        finally
        {
            try { Directory.Delete(root, true); } catch { }
        }
    }

    private static void Test(string name, bool condition, List<string> passes, List<string> failures)
    {
        (condition ? passes : failures).Add(name);
    }

    private static void WriteQuickCollisionPair(string a, string b)
    {
        const int size = 2 * 1024 * 1024;
        const int edge = 64 * 1024;
        var x = new byte[size];
        var y = new byte[size];
        Array.Fill<byte>(x, 0x11);
        Array.Fill<byte>(y, 0x11);
        for (int i = edge; i < size - edge; i++) y[i] = 0x22;
        File.WriteAllBytes(a, x);
        File.WriteAllBytes(b, y);
    }
}
