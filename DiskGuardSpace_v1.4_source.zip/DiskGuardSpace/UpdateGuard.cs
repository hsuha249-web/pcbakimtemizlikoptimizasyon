using Microsoft.Win32;
using System.Diagnostics;
using System.Security;
using System.Text;
using System.Text.Json;

namespace DiskGuardSpace;

internal static class UpdateGuardRunner
{
    private const string TaskName = "DiskGuardSpace_UpdateGuard";
    private const string StatePath = @"SOFTWARE\DiskGuardSpace\UpdateGuard";
    private static readonly string[] Services = { "wuauserv", "UsoSvc", "BITS", "DoSvc" };

    internal static bool TryPauseServicesForCleanup(out Action restore)
    {
        restore = static () => { };
        if (!WindowsMaintenance.IsAdministrator()) return false;
        using var state = Registry.LocalMachine.OpenSubKey(StatePath);
        var guardEnabled = state?.GetValue("GuardEnabled") is not null;
        var running = Services.Where(x => ServiceState(x) == "RUNNING").ToArray();
        foreach (var service in Services) Run("sc.exe", $"stop {service}");
        restore = () =>
        {
            if (guardEnabled) return;
            foreach (var service in running) Run("sc.exe", $"start {service}");
        };
        return Services.All(x => ServiceState(x) != "RUNNING");
    }

    public static int Run(string[] args)
    {
        Program.EnsureWindowsForInternal();
        if (args.Length == 0) return Fail("Kullanım: update-guard enable|disable|status|run-once");
        return args[0].ToLowerInvariant() switch
        {
            "enable" => Enable(args.Skip(1).ToArray()),
            "disable" => Disable(),
            "status" => Status(),
            "run-once" => RunOnce(args.Skip(1).ToArray()),
            _ => Fail($"Bilinmeyen update-guard komutu: {args[0]}")
        };
    }

    private static int Enable(string[] args)
    {
        if (!WindowsMaintenance.IsAdministrator()) return Fail("FAIL-CLOSED: update-guard enable yönetici yetkisi gerektirir.");
        var yes = args.Contains("--yes", StringComparer.OrdinalIgnoreCase);
        var confirm = Value(args, "--confirm");
        if (!yes || !string.Equals(confirm, "UPDATE_GUARD_RISK", StringComparison.Ordinal))
            return Fail("FAIL-CLOSED: --yes --confirm UPDATE_GUARD_RISK gerekir; bu özellik güvenlik güncellemelerini engeller.");
        var hours = ParseHours(Value(args, "--interval-hours"));

        using var state = Registry.LocalMachine.CreateSubKey(StatePath, writable: true) ?? throw new InvalidOperationException("Update Guard state açılamadı.");
        if (state.GetValue("GuardEnabled") is null)
        {
            foreach (var service in Services)
            {
                using var key = Registry.LocalMachine.OpenSubKey($@"SYSTEM\CurrentControlSet\Services\{service}");
                if (key?.GetValue("Start") is int start) state.SetValue($"OriginalStart_{service}", start, RegistryValueKind.DWord);
            }
            using var policy = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU");
            if (policy?.GetValue("NoAutoUpdate") is int value)
            {
                state.SetValue("OriginalNoAutoUpdate", value, RegistryValueKind.DWord);
                state.SetValue("HadNoAutoUpdate", 1, RegistryValueKind.DWord);
            }
        }

        ApplyEnforcement(state);
        RegisterTask(hours);
        state.SetValue("GuardEnabled", 1, RegistryValueKind.DWord);
        state.SetValue("IntervalHours", hours, RegistryValueKind.DWord);
        var report = ExecuteGuard("enable", null);
        WriteLog(report);
        Console.WriteLine("UPDATE GUARD: ENABLED");
        Console.WriteLine($"Interval: every {hours} hour(s) + startup trigger");
        return report.Status == "VERIFIED_PASS" ? 0 : 42;
    }

    private static int Disable()
    {
        if (!WindowsMaintenance.IsAdministrator()) return Fail("FAIL-CLOSED: update-guard disable yönetici yetkisi gerektirir.");
        using var state = Registry.LocalMachine.OpenSubKey(StatePath, writable: true);
        if (state is null) { UnregisterTask(); Console.WriteLine("UPDATE GUARD: DISABLED (not installed)"); return 0; }
        UnregisterTask();
        RestoreServices(state);
        RestorePolicy(state);
        state.DeleteValue("GuardEnabled", throwOnMissingValue: false);
        var report = new UpdateGuardReport { Mode = "disable", Status = "VERIFIED_PASS", CreatedUtc = DateTime.UtcNow, Notes = new() { "Update Guard disabled and owned policy/service changes restored." } };
        WriteLog(report);
        Console.WriteLine("UPDATE GUARD: DISABLED");
        return 0;
    }

    private static int Status()
    {
        using var state = Registry.LocalMachine.OpenSubKey(StatePath);
        var enabled = state?.GetValue("GuardEnabled") is not null;
        Console.WriteLine($"Enabled: {enabled}");
        Console.WriteLine($"Task: {TaskName}");
        foreach (var service in Services) Console.WriteLine($"{service}: {ServiceState(service)}");
        return 0;
    }

    private static int RunOnce(string[] args)
    {
        if (!WindowsMaintenance.IsAdministrator()) return Fail("FAIL-CLOSED: update-guard run-once yönetici yetkisi gerektirir.");
        using var state = Registry.LocalMachine.OpenSubKey(StatePath, writable: true);
        if (state?.GetValue("GuardEnabled") is null) return Fail("FAIL-CLOSED: Update Guard etkin değil.");
        ApplyEnforcement(state);
        var report = ExecuteGuard("run-once", Value(args, "--report"));
        Console.WriteLine($"UPDATE GUARD: {report.Status}; deleted={report.DeletedBytes / (1024.0 * 1024 * 1024):0.00} GiB");
        return report.Status == "VERIFIED_PASS" ? 0 : 42;
    }

    private static void ApplyEnforcement(RegistryKey state)
    {
        foreach (var service in Services)
        {
            Run("sc.exe", $"stop {service}");
            using var key = Registry.LocalMachine.OpenSubKey($@"SYSTEM\CurrentControlSet\Services\{service}", writable: true);
            key?.SetValue("Start", 4, RegistryValueKind.DWord);
        }
        using var policy = Registry.LocalMachine.CreateSubKey(@"SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU", writable: true);
        policy?.SetValue("NoAutoUpdate", 1, RegistryValueKind.DWord);
    }

    private static void RestoreServices(RegistryKey state)
    {
        foreach (var service in Services)
        {
            var original = state.GetValue($"OriginalStart_{service}");
            if (original is int start)
            {
                using var key = Registry.LocalMachine.OpenSubKey($@"SYSTEM\CurrentControlSet\Services\{service}", writable: true);
                key?.SetValue("Start", start, RegistryValueKind.DWord);
            }
        }
    }

    private static void RestorePolicy(RegistryKey state)
    {
        using var policy = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU", writable: true);
        if (policy is null) return;
        if (state.GetValue("HadNoAutoUpdate") is int && state.GetValue("OriginalNoAutoUpdate") is int original)
            policy.SetValue("NoAutoUpdate", original, RegistryValueKind.DWord);
        else policy.DeleteValue("NoAutoUpdate", throwOnMissingValue: false);
    }

    private static UpdateGuardReport ExecuteGuard(string mode, string? requestedReport)
    {
        var before = DiskSnapshot.CaptureSystemDrive();
        var root = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), "SoftwareDistribution", "Download");
        long deleted = 0; int files = 0; var notes = new List<string>();
        try
        {
            if (Directory.Exists(root))
            {
                var cutoff = DateTime.UtcNow.AddDays(-1);
                foreach (var file in Directory.EnumerateFiles(root, "*", SearchOption.AllDirectories))
                {
                    if (!SafetyPolicy.IsUnderRoot(file, root) || SafetyPolicy.IsReparsePoint(file)) continue;
                    var info = new FileInfo(file);
                    if (info.LastWriteTimeUtc > cutoff) continue;
                    var bytes = info.Length;
                    try { File.Delete(file); if (!File.Exists(file)) { deleted += bytes; files++; } }
                    catch (Exception ex) { notes.Add($"skip:{Path.GetFileName(file)}:{ex.GetType().Name}"); }
                }
            }
        }
        catch (Exception ex) { notes.Add("enumeration:" + ex.GetType().Name); }
        var after = DiskSnapshot.CaptureSystemDrive();
        var report = new UpdateGuardReport
        {
            Mode = mode, CreatedUtc = DateTime.UtcNow, Status = notes.Any(x => x.StartsWith("enumeration:")) ? "PARTIAL_OR_FAIL_CLOSED" : "VERIFIED_PASS",
            FreeBytesBefore = before.FreeBytes, FreeBytesAfter = after.FreeBytes, VerifiedFreeGainBytes = after.FreeBytes - before.FreeBytes,
            DeletedBytes = deleted, DeletedFiles = files, Services = Services.ToDictionary(x => x, ServiceState), Notes = notes
        };
        WriteLog(report);
        if (!string.IsNullOrWhiteSpace(requestedReport)) AtomicFile.WriteAllText(Path.GetFullPath(requestedReport), JsonSerializer.Serialize(report, Json.Options));
        return report;
    }

    private static void RegisterTask(int hours)
    {
        var exe = Environment.ProcessPath ?? throw new InvalidOperationException("EXE yolu belirlenemedi.");
        var logDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "DiskGuardSpace", "UpdateGuard");
        Directory.CreateDirectory(logDir);
        var taskReport = Path.Combine(logDir, "latest.json");
        var xml = new StringBuilder()
            .AppendLine("<?xml version=\"1.0\" encoding=\"UTF-16\"?>")
            .Append("<Task version=\"1.4\" xmlns=\"http://schemas.microsoft.com/windows/2004/02/mit/task\"><Triggers><BootTrigger><Enabled>true</Enabled><Delay>PT1M</Delay></BootTrigger><CalendarTrigger><StartBoundary>")
            .Append(DateTime.UtcNow.AddMinutes(2).ToString("o"))
            .Append("</StartBoundary><Enabled>true</Enabled><ScheduleByDay><DaysInterval>1</DaysInterval></ScheduleByDay><Repetition><Interval>PT")
            .Append(hours)
            .Append("H</Interval><Duration>P1D</Duration><StopAtDurationEnd>false</StopAtDurationEnd></Repetition></CalendarTrigger></Triggers><Principals><Principal id=\"Author\"><UserId>S-1-5-18</UserId><RunLevel>HighestAvailable</RunLevel></Principal></Principals><Settings><MultipleInstancesPolicy>IgnoreNew</MultipleInstancesPolicy><StartWhenAvailable>true</StartWhenAvailable><ExecutionTimeLimit>PT2H</ExecutionTimeLimit><Hidden>true</Hidden></Settings><Actions Context=\"Author\"><Exec><Command>")
            .Append(SecurityElement.Escape(exe))
            .Append("</Command><Arguments>update-guard run-once --report &quot;")
            .Append(SecurityElement.Escape(taskReport))
            .Append("&quot;</Arguments><WorkingDirectory>")
            .Append(SecurityElement.Escape(Path.GetDirectoryName(exe) ?? ""))
            .Append("</WorkingDirectory></Exec></Actions></Task>")
            .ToString();
        var xmlPath = Path.Combine(logDir, ".task.xml");
        File.WriteAllText(xmlPath, xml, Encoding.Unicode);
        try { Run("schtasks.exe", $"/Create /TN {TaskName} /XML \"{xmlPath}\" /F"); }
        finally { try { File.Delete(xmlPath); } catch { } }
    }

    private static void UnregisterTask() => Run("schtasks.exe", $"/Delete /TN {TaskName} /F");
    private static string ServiceState(string name) => RunCapture("sc.exe", $"query {name}").Contains("RUNNING", StringComparison.OrdinalIgnoreCase) ? "RUNNING" : "NOT_RUNNING";
    private static int Run(string file, string args) { try { using var p = Process.Start(new ProcessStartInfo(file, args) { UseShellExecute = false, CreateNoWindow = true }); p?.WaitForExit(30_000); return p?.ExitCode ?? -1; } catch { return -1; } }
    private static string RunCapture(string file, string args) { try { using var p = Process.Start(new ProcessStartInfo(file, args) { UseShellExecute = false, CreateNoWindow = true, RedirectStandardOutput = true }); return p?.StandardOutput.ReadToEnd() ?? ""; } catch { return ""; } }
    private static void WriteLog(UpdateGuardReport report)
    {
        var dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "DiskGuardSpace", "UpdateGuard");
        Directory.CreateDirectory(dir);
        AtomicFile.WriteAllText(Path.Combine(dir, $"run-{DateTime.UtcNow:yyyyMMdd-HHmmss}.json"), JsonSerializer.Serialize(report, Json.Options));
        var old = Directory.EnumerateFiles(dir, "run-*.json").OrderByDescending(x => File.GetLastWriteTimeUtc(x)).Skip(30).ToList();
        foreach (var file in old) try { File.Delete(file); } catch { }
    }
    private static string? Value(string[] args, string name) { var i = Array.FindIndex(args, x => string.Equals(x, name, StringComparison.OrdinalIgnoreCase)); return i >= 0 && i + 1 < args.Length ? args[i + 1] : null; }
    private static int ParseHours(string? value) => int.TryParse(value, out var n) && n is >= 1 and <= 24 ? n : 12;
    private static int Fail(string message) { Console.Error.WriteLine(message); return 2; }
}

internal sealed class UpdateGuardReport
{
    public string Schema { get; set; } = "DiskGuardSpace.UpdateGuard.v1";
    public string Mode { get; set; } = "";
    public DateTime CreatedUtc { get; set; }
    public string Status { get; set; } = "";
    public long FreeBytesBefore { get; set; }
    public long FreeBytesAfter { get; set; }
    public long VerifiedFreeGainBytes { get; set; }
    public long DeletedBytes { get; set; }
    public int DeletedFiles { get; set; }
    public Dictionary<string, string> Services { get; set; } = new();
    public List<string> Notes { get; set; } = new();
}
