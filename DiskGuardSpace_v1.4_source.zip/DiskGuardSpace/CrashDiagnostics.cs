using System.Runtime.InteropServices;
using System.Text;
using System.Text.Json;

namespace DiskGuardSpace;

internal static class CrashDiagnostics
{
    private const uint MbIconError = 0x00000010;
    private const uint MbOk = 0x00000000;

    internal static string? TryWrite(Exception ex, string phase, string[]? args = null)
    {
        try
        {
            var local = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            if (string.IsNullOrWhiteSpace(local)) return null;
            var root = Path.Combine(local, "DiskGuardSpace", "Logs");
            if (!IsAllowedLogDirectory(root)) return null;
            Directory.CreateDirectory(root);
            if (!IsAllowedLogDirectory(root) || SafetyPolicy.IsReparsePoint(root)) return null;
            var path = Path.Combine(root, $"crash-{DateTime.UtcNow:yyyyMMdd-HHmmss}-{Guid.NewGuid():N}.json");
            var payload = new
            {
                schema = "DiskGuardSpace.CrashProof.v1",
                product = "DiskGuardSpace",
                version = "1.4",
                createdUtc = DateTime.UtcNow.ToString("O"),
                phase,
                processPath = Environment.ProcessPath,
                commandLineArgs = args ?? Array.Empty<string>(),
                exceptionType = ex.GetType().FullName,
                exceptionMessage = ex.Message,
                hresult = ex.HResult,
                stackTrace = ex.StackTrace,
                os = RuntimeInformation.OSDescription,
                architecture = RuntimeInformation.ProcessArchitecture.ToString()
            };
            var bytes = Encoding.UTF8.GetBytes(JsonSerializer.Serialize(payload, Json.Options));
            var tmp = path + ".tmp-" + Guid.NewGuid().ToString("N");
            try
            {
                using var fs = new FileStream(tmp, FileMode.CreateNew, FileAccess.Write, FileShare.None, 4096, FileOptions.WriteThrough);
                fs.Write(bytes, 0, bytes.Length);
                fs.Flush(flushToDisk: true);
                File.Move(tmp, path);
            }
            finally
            {
                try { if (File.Exists(tmp)) File.Delete(tmp); } catch { }
            }
            return path;
        }
        catch { return null; }
    }


    internal static bool IsAllowedLogDirectory(string path)
    {
        try
        {
            if (!OperatingSystem.IsWindows() || string.IsNullOrWhiteSpace(path)) return false;
            if (SafetyPolicy.HasUnsafePathSyntax(path)) return false;
            var local = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            if (string.IsNullOrWhiteSpace(local)) return false;
            var full = SafetyPolicy.Normalize(path);
            var allowedRoot = SafetyPolicy.Normalize(Path.Combine(local, "DiskGuardSpace", "Logs"));
            if (!full.Equals(allowedRoot, StringComparison.OrdinalIgnoreCase)) return false;

            var current = full;
            var localNorm = SafetyPolicy.Normalize(local);
            while (!current.Equals(localNorm, StringComparison.OrdinalIgnoreCase))
            {
                if ((Directory.Exists(current) || File.Exists(current)) && SafetyPolicy.IsReparsePoint(current)) return false;
                var parent = Path.GetDirectoryName(current);
                if (string.IsNullOrWhiteSpace(parent) || parent.Equals(current, StringComparison.OrdinalIgnoreCase)) return false;
                current = SafetyPolicy.Normalize(parent);
                if (!(current.Equals(localNorm, StringComparison.OrdinalIgnoreCase) || SafetyPolicy.IsUnderRoot(current, localNorm))) return false;
            }
            return !SafetyPolicy.IsReparsePoint(localNorm);
        }
        catch { return false; }
    }

    internal static void ShowFatalDialog(Exception ex, string? logPath)
    {
        if (!OperatingSystem.IsWindows()) return;
        try
        {
            var detail = $"DiskGuardSpace FAIL-CLOSED\n\n{ex.GetType().Name}: {ex.Message}";
            if (!string.IsNullOrWhiteSpace(logPath)) detail += $"\n\nKalıcı hata kaydı:\n{logPath}";
            detail += "\n\nBu hata nedeniyle hiçbir bakım işlemi zorlanmadı.";
            MessageBoxW(0, detail, "DiskGuardSpace v1.4 - Startup Error", MbOk | MbIconError);
        }
        catch { }
    }

    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern int MessageBoxW(nint hwnd, string text, string caption, uint type);
}
