param(
    [string]$ExePath = "",
    [string]$ProofDir = "",
    [switch]$RequireReleaseProof
)
$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
if (-not $ExePath) { $ExePath = Join-Path $Root "dist\DiskGuardSpace.exe" }
$ExePath = [IO.Path]::GetFullPath($ExePath)
if (-not (Test-Path $ExePath -PathType Leaf)) { throw "Controller verification EXE missing: $ExePath" }

if (-not $ProofDir) {
    $local = [Environment]::GetFolderPath([Environment+SpecialFolder]::LocalApplicationData)
    $ProofDir = Join-Path $local ("DiskGuardSpace\ControllerVerify\" + [guid]::NewGuid().ToString('N'))
}
$ProofDir = [IO.Path]::GetFullPath($ProofDir)
if (Test-Path $ProofDir) { throw "Controller proof directory already exists; refusing recursive overwrite: $ProofDir" }
New-Item -ItemType Directory -Path $ProofDir | Out-Null
$ControllerProof = Join-Path $ProofDir "CONTROLLER_PROOF.json"
$AutomationProof = Join-Path $ProofDir "CONTROLLER_AUTOMATION_PROOF.json"

$checks = New-Object System.Collections.Generic.List[object]
function Add-Check([string]$Name, [bool]$Ok, [string]$Detail) {
    $checks.Add([ordered]@{ name=$Name; status=$(if($Ok){'PASS'}else{'FAIL'}); detail=$Detail }) | Out-Null
    Write-Host "[$(if($Ok){'PASS'}else{'FAIL'})] $Name - $Detail" -ForegroundColor $(if($Ok){'Green'}else{'Red'})
}

$proc = $null
try {
    Add-Type -AssemblyName UIAutomationClient
    Add-Type -AssemblyName UIAutomationTypes

    $exeHash = (Get-FileHash $ExePath -Algorithm SHA256).Hash.ToLowerInvariant()
    Add-Check "exe_exists" $true $ExePath
    Add-Check "controller_proof_absent_before_gui_action" (-not (Test-Path $ControllerProof)) "proof did not pre-exist"

    $args = "controller --proof-dir `"$ProofDir`""
    $proc = Start-Process -FilePath $ExePath -ArgumentList $args -PassThru

    $desktop = [System.Windows.Automation.AutomationElement]::RootElement
    $processCondition = New-Object -TypeName System.Windows.Automation.PropertyCondition -ArgumentList @(
        [System.Windows.Automation.AutomationElement]::ProcessIdProperty,
        [int]$proc.Id
    )

    $window = $null
    $deadline = [DateTime]::UtcNow.AddSeconds(20)
    while ([DateTime]::UtcNow -lt $deadline -and -not $window) {
        Start-Sleep -Milliseconds 150
        $window = $desktop.FindFirst([System.Windows.Automation.TreeScope]::Children, $processCondition)
    }
    Add-Check "controller_window_visible" ($null -ne $window) $(if($window){$window.Current.Name}else{'window not found'})
    if (-not $window) { throw "Controller native window did not become visible." }

    $buttonName = New-Object -TypeName System.Windows.Automation.PropertyCondition -ArgumentList @(
        [System.Windows.Automation.AutomationElement]::NameProperty,
        "Run Read-Only Verification"
    )
    $button = $window.FindFirst([System.Windows.Automation.TreeScope]::Descendants, $buttonName)
    Add-Check "controller_run_button_found" ($null -ne $button) "Run Read-Only Verification"
    if (-not $button) { throw "Controller verification button not found." }

    # UI Automation reliably locates the real native button, but some Windows builds/providers
    # expose the Win32 BUTTON without InvokePattern.  Do not fail the release merely because
    # that optional accessibility pattern is absent.  Bind the action to the exact HWND that
    # UIA discovered and activate the native BUTTON with BM_CLICK instead.
    if (-not ("DiskGuardNativeButton" -as [type])) {
        Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
using System.Text;
public static class DiskGuardNativeButton {
    [DllImport("user32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    public static extern IntPtr SendMessage(IntPtr hWnd, uint Msg, IntPtr wParam, IntPtr lParam);
    [DllImport("user32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    public static extern int GetClassName(IntPtr hWnd, StringBuilder lpClassName, int nMaxCount);
}
"@
    }

    $buttonHwndValue = [int64]$button.Current.NativeWindowHandle
    if ($buttonHwndValue -eq 0) { throw "Controller button has no native HWND; refusing synthetic coordinate click." }
    $buttonHwnd = [IntPtr]$buttonHwndValue
    $classNameBuffer = New-Object System.Text.StringBuilder 128
    $classLen = [DiskGuardNativeButton]::GetClassName($buttonHwnd, $classNameBuffer, $classNameBuffer.Capacity)
    if ($classLen -le 0) { throw "Controller button HWND class could not be verified." }
    $buttonClass = $classNameBuffer.ToString()
    Add-Check "controller_run_button_native_hwnd" ($buttonClass -ieq 'Button') ("HWND=" + $buttonHwndValue + "; class=" + $buttonClass)
    if ($buttonClass -ine 'Button') { throw "Controller verification target is not a native Win32 BUTTON." }
    Add-Check "controller_run_button_enabled" ([bool]$button.Current.IsEnabled) ("enabled=" + [string]$button.Current.IsEnabled)
    if (-not [bool]$button.Current.IsEnabled) { throw "Controller verification button is disabled before activation." }

    $BM_CLICK = 0x00F5
    [void][DiskGuardNativeButton]::SendMessage($buttonHwnd, $BM_CLICK, [IntPtr]::Zero, [IntPtr]::Zero)

    # Prove that the click reached the controller, rather than assuming SendMessage succeeded.
    $actionObserved = $false
    $actionTitle = ""
    $actionDeadline = [DateTime]::UtcNow.AddSeconds(5)
    while ([DateTime]::UtcNow -lt $actionDeadline) {
        try {
            $window = $desktop.FindFirst([System.Windows.Automation.TreeScope]::Children, $processCondition)
            if ($window) {
                $actionTitle = [string]$window.Current.Name
                if ($actionTitle -like '*STATUS: RUNNING*' -or $actionTitle -like '*STATUS: PASS*' -or $actionTitle -like '*STATUS: FAIL*') {
                    $actionObserved = $true
                    break
                }
            }
        } catch { }
        if (Test-Path $ControllerProof -PathType Leaf) { $actionObserved = $true; break }
        Start-Sleep -Milliseconds 100
    }
    Add-Check "controller_gui_action_invoked" $actionObserved ("native HWND BM_CLICK observed; title=" + $actionTitle)
    if (-not $actionObserved) { throw "Native controller button click was sent but no controller state transition was observed." }

    $deadline = [DateTime]::UtcNow.AddMinutes(12)
    while ([DateTime]::UtcNow -lt $deadline -and -not (Test-Path $ControllerProof -PathType Leaf)) {
        if ($proc.HasExited) { break }
        Start-Sleep -Milliseconds 250
    }
    Add-Check "controller_proof_created" (Test-Path $ControllerProof -PathType Leaf) $ControllerProof
    if (-not (Test-Path $ControllerProof -PathType Leaf)) { throw "CONTROLLER_PROOF.json was not produced." }

    $proof = Get-Content $ControllerProof -Raw | ConvertFrom-Json
    Add-Check "controller_proof_schema" ($proof.schema -eq 'DiskGuardSpace.ControllerProof.v1') ([string]$proof.schema)
    Add-Check "controller_proof_product_version" ($proof.product -eq 'DiskGuardSpace' -and $proof.version -eq '1.4') ("$($proof.product) $($proof.version)")
    Add-Check "controller_proof_overall" ($proof.overall -eq 'PASS') ([string]$proof.overall)
    Add-Check "controller_proof_read_only" (-not [bool]$proof.writesPerformed) ("writesPerformed=" + [string]$proof.writesPerformed)
    Add-Check "controller_proof_exe_hash" (([string]$proof.exeSha256).ToLowerInvariant() -eq $exeHash) ([string]$proof.exeSha256)
    if ($RequireReleaseProof) {
        Add-Check "controller_release_proof_identity" ($proof.releaseProofIdentity -eq 'PASS') ([string]$proof.releaseProofIdentity)
    }

    $deadline = [DateTime]::UtcNow.AddSeconds(8)
    $passTitle = $false
    $lastTitle = ""
    while ([DateTime]::UtcNow -lt $deadline) {
        try {
            $window = $desktop.FindFirst([System.Windows.Automation.TreeScope]::Children, $processCondition)
            if ($window) {
                $lastTitle = $window.Current.Name
                if ($lastTitle -like '*STATUS: PASS*') { $passTitle = $true; break }
                if ($lastTitle -like '*STATUS: FAIL*') { break }
            }
        } catch { }
        Start-Sleep -Milliseconds 150
    }
    Add-Check "controller_window_status_pass" $passTitle $lastTitle
}
catch {
    Add-Check "controller_native_automation" $false ("$($_.Exception.GetType().Name): $($_.Exception.Message)")
}
finally {
    if ($proc -and -not $proc.HasExited) {
        try { $null = $proc.CloseMainWindow(); Start-Sleep -Milliseconds 500 } catch { }
        if (-not $proc.HasExited) { try { Stop-Process -Id $proc.Id -Force -ErrorAction SilentlyContinue } catch { } }
    }
}

$failed = @($checks | Where-Object { $_.status -ne 'PASS' }).Count
$report = [ordered]@{
    schema = 'DiskGuardSpace.ControllerAutomationProof.v1'
    product = 'DiskGuardSpace'
    version = '1.4'
    createdUtc = (Get-Date).ToUniversalTime().ToString('o')
    result = $(if($failed -eq 0){'PASS'}else{'FAIL'})
    writesPerformed = $false
    exe = $ExePath
    exeSha256 = (Get-FileHash $ExePath -Algorithm SHA256).Hash.ToLowerInvariant()
    controllerProof = $(if(Test-Path $ControllerProof){$ControllerProof}else{$null})
    controllerProofSha256 = $(if(Test-Path $ControllerProof){(Get-FileHash $ControllerProof -Algorithm SHA256).Hash.ToLowerInvariant()}else{$null})
    checks = $checks
}
$report | ConvertTo-Json -Depth 8 | Set-Content -Encoding UTF8 $AutomationProof

if ($failed -eq 0) {
    Write-Host "CONTROLLER VERIFY: VERIFIED_PASS" -ForegroundColor Green
    Write-Host "Automation proof: $AutomationProof"
    exit 0
}
Write-Host "CONTROLLER VERIFY: FAIL" -ForegroundColor Red
Write-Host "Automation proof: $AutomationProof"
exit 2
