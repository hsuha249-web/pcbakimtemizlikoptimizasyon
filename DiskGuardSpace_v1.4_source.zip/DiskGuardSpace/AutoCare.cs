using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Security.Principal;
using System.Security.Cryptography;
using System.Text.Json;
using Microsoft.Win32;

namespace DiskGuardSpace;

internal sealed class AutoCareOptions
{
    public bool Apply { get; init; }
    public int MinAgeDays { get; init; } = 7;
    public int MinSizeMiB { get; init; } = 500;
    public int DuplicateMinMiB { get; init; } = 10;
    public int Top { get; init; } = 100;
    public string? ReportPath { get; init; }
    public string? WorkDir { get; init; }
    public bool SkipComponentCleanup { get; init; }
    public bool SkipPerformance { get; init; }
    public bool SkipDeliveryOptimization { get; init; }
    public bool SkipDeepAnalysis { get; init; }
    public bool DeepHealth { get; init; }
    public bool StartupBackground { get; init; }

    public static AutoCareOptions Parse(string[] args)
    {
        bool apply = false;
        int days = 7, minSize = 500, dupMin = 10, top = 100;
        string? report = null, workDir = null;
        bool skipComponent = false, skipPerformance = false, skipDelivery = false, skipDeepAnalysis = false, deepHealth = false, startupBackground = false;

        for (int i = 0; i < args.Length; i++)
        {
            switch (args[i])
            {
                case "--apply": apply = true; break;
                case "--skip-component-cleanup": skipComponent = true; break;
                case "--skip-performance": skipPerformance = true; break;
                case "--skip-delivery-optimization": skipDelivery = true; break;
                case "--skip-deep-analysis": skipDeepAnalysis = true; break;
                case "--deep-health": deepHealth = true; break;
                case "--startup-background": startupBackground = true; break;
                case "--min-age-days": days = ParseInt(args, ref i, "--min-age-days", 1, 3650); break;
                case "--min-size-mib": minSize = ParseInt(args, ref i, "--min-size-mib", 1, 1024 * 1024); break;
                case "--duplicate-min-mib": dupMin = ParseInt(args, ref i, "--duplicate-min-mib", 1, 1024 * 1024); break;
                case "--top": top = ParseInt(args, ref i, "--top", 1, 5000); break;
                case "--report":
                    if (++i >= args.Length) throw new ArgumentException("--report değer bekliyor.");
                    report = args[i];
                    break;
                case "--work-dir":
                    if (++i >= args.Length) throw new ArgumentException("--work-dir değer bekliyor.");
                    workDir = args[i];
                    break;
                default: throw new ArgumentException($"Bilinmeyen auto-care argümanı: {args[i]}");
            }
        }

        return new AutoCareOptions
        {
            Apply = apply,
            MinAgeDays = days,
            MinSizeMiB = minSize,
            DuplicateMinMiB = dupMin,
            Top = top,
            ReportPath = report,
            WorkDir = workDir,
            SkipComponentCleanup = skipComponent,
            SkipPerformance = skipPerformance,
            SkipDeliveryOptimization = skipDelivery,
            SkipDeepAnalysis = skipDeepAnalysis,
            DeepHealth = deepHealth,
            StartupBackground = startupBackground
        };
    }

    public CliOptions ToCliOptions() => new()
    {
        MinAgeDays = MinAgeDays,
        MinSizeMiB = MinSizeMiB,
        DuplicateMinMiB = DuplicateMinMiB,
        Top = Top
    };

    private static int ParseInt(string[] args, ref int i, string name, int min, int max)
    {
        if (++i >= args.Length || !int.TryParse(args[i], out var value) || value < min || value > max)
            throw new ArgumentException($"{name} {min}..{max} olmalı.");
        return value;
    }
}

internal sealed record SafetyCheck(string Name, string Status, string Detail, bool GlobalBlock);
internal sealed record FeatureSkip(string Feature, string Reason);

internal sealed class PreflightResult
{
    public List<SafetyCheck> Checks { get; } = new();
    public List<FeatureSkip> FeatureSkips { get; } = new();
    public bool GlobalWriteBlocked => Checks.Any(x => x.GlobalBlock && x.Status != "PASS");
    public bool IsFeatureSkipped(string feature) => FeatureSkips.Any(x => x.Feature.Equals(feature, StringComparison.OrdinalIgnoreCase));
}

internal static class AutoCarePreflight
{
    public static PreflightResult Run()
    {
        var r = new PreflightResult();
        Add(r, OperatingSystem.IsWindows(), "windows-platform", "Windows is required", true);
        if (!OperatingSystem.IsWindows()) return r;

        var windows = Environment.GetFolderPath(Environment.SpecialFolder.Windows);
        var root = Path.GetPathRoot(windows);
        Add(r, !string.IsNullOrWhiteSpace(root), "system-drive-resolved", root ?? "unresolved", true);
        if (string.IsNullOrWhiteSpace(root)) return r;

        try
        {
            var drive = new DriveInfo(root);
            Add(r, drive.IsReady, "system-drive-ready", drive.Name, true);
            if (drive.IsReady)
            {
                Add(r, drive.DriveType == DriveType.Fixed, "system-drive-fixed", drive.DriveType.ToString(), true);
                Add(r, string.Equals(drive.DriveFormat, "NTFS", StringComparison.OrdinalIgnoreCase), "system-drive-ntfs", drive.DriveFormat, true);
                Add(r, drive.TotalSize > 0 && drive.AvailableFreeSpace >= 0 && drive.AvailableFreeSpace <= drive.TotalSize,
                    "disk-snapshot-sane", $"free={drive.AvailableFreeSpace}; total={drive.TotalSize}", true);
                var freePercent = drive.TotalSize > 0 ? drive.AvailableFreeSpace * 100.0 / drive.TotalSize : 0;
                if (drive.AvailableFreeSpace < 2L * 1024 * 1024 * 1024 || freePercent < 5.0)
                {
                    r.Checks.Add(new SafetyCheck("drive-optimization-space-margin", "FAIL", $"free={drive.AvailableFreeSpace}; percent={freePercent:F2}; cleanup is prioritized before drive optimization", false));
                    r.FeatureSkips.Add(new FeatureSkip("DRIVE_OPTIMIZATION", "Critical low free space; avoid heavy optimization until cleanup has recovered headroom."));
                }
                else
                {
                    r.Checks.Add(new SafetyCheck("drive-optimization-space-margin", "PASS", $"free={drive.AvailableFreeSpace}; percent={freePercent:F2}", false));
                }
            }
        }
        catch (Exception ex)
        {
            r.Checks.Add(new SafetyCheck("system-drive-inspection", "FAIL", ex.Message, true));
        }

        try
        {
            var roots = SafetyPolicy.GetApprovedCleanupRoots();
            bool rootsOk = roots.Length > 0 && roots.All(x => Directory.Exists(x.Path) && !SafetyPolicy.IsReparsePoint(x.Path) && !SafetyPolicy.IsForbiddenCleanupRoot(x.Path) && SafetyPolicy.IsCanonicalApprovedRoot(x));
            Add(r, rootsOk, "approved-cleanup-roots", $"count={roots.Length}; canonical={rootsOk}", true);
        }
        catch (Exception ex)
        {
            r.Checks.Add(new SafetyCheck("approved-cleanup-roots", "FAIL", ex.Message, true));
        }

        foreach (var (processName, feature) in new[]
        {
            ("chrome", "CHROME_CACHE"), ("msedge", "EDGE_CACHE"), ("brave", "BRAVE_CACHE"),
            ("chromium", "CHROMIUM_CACHE"), ("firefox", "FIREFOX_CACHE"),
            ("Code", "VSCODE_CACHE"), ("Cursor", "CURSOR_CACHE"), ("Discord", "DISCORD_CACHE"), ("slack", "SLACK_CACHE")
        })
        {
            try
            {
                if (Process.GetProcessesByName(processName).Length > 0)
                    r.FeatureSkips.Add(new FeatureSkip(feature, $"{processName}.exe is running; live application cache is not modified."));
            }
            catch
            {
                r.FeatureSkips.Add(new FeatureSkip(feature, $"Could not verify {processName}.exe process state; fail-closed skip."));
            }
        }

        if (!PowerSafety.IsOnAcPower(out var powerDetail))
        {
            r.Checks.Add(new SafetyCheck("ac-power-for-drive-optimization", "FAIL", powerDetail, false));
            r.FeatureSkips.Add(new FeatureSkip("DRIVE_OPTIMIZATION", "AC power could not be confirmed; heavy drive optimization is skipped."));
        }
        else
        {
            r.Checks.Add(new SafetyCheck("ac-power-for-drive-optimization", "PASS", powerDetail, false));
        }

        if (!WindowsMaintenance.IsAdministrator())
        {
            r.FeatureSkips.Add(new FeatureSkip("COMPONENT_CLEANUP", "Administrator privileges unavailable."));
            r.FeatureSkips.Add(new FeatureSkip("DELIVERY_OPTIMIZATION", "Administrator privileges unavailable."));
            r.FeatureSkips.Add(new FeatureSkip("DRIVE_OPTIMIZATION", "Administrator privileges unavailable."));
        }

        var system32 = Path.Combine(windows, "System32");
        if (!File.Exists(Path.Combine(system32, "dism.exe")))
            r.FeatureSkips.Add(new FeatureSkip("COMPONENT_CLEANUP", "dism.exe is unavailable."));
        if (!File.Exists(Path.Combine(system32, "defrag.exe")))
            r.FeatureSkips.Add(new FeatureSkip("DRIVE_OPTIMIZATION", "defrag.exe is unavailable."));
        if (!ExtraSpaceMaintenance.IsDeliveryOptimizationCleanupSupported(out var deliveryProbe))
            r.FeatureSkips.Add(new FeatureSkip("DELIVERY_OPTIMIZATION", "Supported Delivery Optimization cleanup cmdlet unavailable: " + deliveryProbe));

        if (WindowsState.HasPendingServicingReboot())
        {
            r.FeatureSkips.Add(new FeatureSkip("COMPONENT_CLEANUP", "Windows servicing reboot is pending; DISM cleanup skipped."));
            r.FeatureSkips.Add(new FeatureSkip("DRIVE_OPTIMIZATION", "Windows servicing reboot is pending; drive optimization deferred until reboot completes."));
        }

        return r;
    }

    public static void ApplyPhysicalDiskHealthGate(PreflightResult result, PcHealthSnapshot? health)
    {
        if (health is null)
        {
            result.Checks.Add(new SafetyCheck("physical-disk-health", "FAIL", "Health snapshot unavailable; drive optimization skipped.", false));
            result.FeatureSkips.Add(new FeatureSkip("DRIVE_OPTIMIZATION", "Physical disk health could not be verified."));
            return;
        }

        var reliability = StorageReliabilityPolicy.Classify(health.RecentStorageErrorProbe);
        if (reliability == "BLOCK_WRITES")
        {
            result.Checks.Add(new SafetyCheck("recent-storage-io-errors", "FAIL", "Repeated storage/filesystem I/O error events detected in the last 24 hours; write maintenance blocked.", true));
            return;
        }
        if (reliability == "HEAVY_ONLY")
        {
            result.Checks.Add(new SafetyCheck("recent-storage-io-errors", "FAIL", "A recent storage/filesystem I/O error event was detected; heavy maintenance deferred.", false));
            result.FeatureSkips.Add(new FeatureSkip("DELIVERY_OPTIMIZATION", "Recent storage I/O error event; defer heavy write maintenance."));
            result.FeatureSkips.Add(new FeatureSkip("COMPONENT_CLEANUP", "Recent storage I/O error event; defer heavy write maintenance."));
            result.FeatureSkips.Add(new FeatureSkip("DRIVE_OPTIMIZATION", "Recent storage I/O error event; defer heavy write maintenance."));
        }
        else if (reliability == "HEALTHY")
        {
            result.Checks.Add(new SafetyCheck("recent-storage-io-errors", "PASS", "No targeted storage/filesystem I/O error events found in the last 24 hours.", false));
        }
        else
        {
            result.Checks.Add(new SafetyCheck("recent-storage-io-errors", "FAIL", "Storage event-log reliability signal unavailable/ambiguous; drive optimization deferred.", false));
            result.FeatureSkips.Add(new FeatureSkip("DRIVE_OPTIMIZATION", "Recent storage I/O event history could not be verified."));
        }

        var probe = health.PhysicalDiskHealthProbe ?? "";
        if (probe.Contains("Unhealthy", StringComparison.OrdinalIgnoreCase) || probe.Contains("Warning", StringComparison.OrdinalIgnoreCase))
        {
            result.Checks.Add(new SafetyCheck("physical-disk-health", "FAIL", "Storage health reported Warning/Unhealthy; write maintenance blocked.", true));
            return;
        }
        if (probe.Contains("Healthy", StringComparison.OrdinalIgnoreCase))
        {
            result.Checks.Add(new SafetyCheck("physical-disk-health", "PASS", "Storage health probe reported Healthy.", true));
            return;
        }

        result.Checks.Add(new SafetyCheck("physical-disk-health", "FAIL", "Storage health could not be verified; heavy drive optimization skipped.", false));
        result.FeatureSkips.Add(new FeatureSkip("DRIVE_OPTIMIZATION", "Physical disk health probe unavailable/ambiguous."));
    }

    public static void ApplyPerformancePressureGate(PreflightResult result, PerformanceSnapshot? performance)
    {
        if (performance is null)
        {
            result.FeatureSkips.Add(new FeatureSkip("DRIVE_OPTIMIZATION", "Performance pressure snapshot unavailable; heavy drive optimization skipped."));
            return;
        }
        if (performance.Assessment is "CRITICAL_MEMORY_PRESSURE" or "HIGH_MEMORY_PRESSURE")
        {
            result.Checks.Add(new SafetyCheck("memory-pressure-for-drive-optimization", "FAIL", performance.Assessment, false));
            result.FeatureSkips.Add(new FeatureSkip("DRIVE_OPTIMIZATION", "High memory pressure detected; avoid adding heavy I/O/CPU pressure."));
        }
        else
        {
            result.Checks.Add(new SafetyCheck("memory-pressure-for-drive-optimization", "PASS", performance.Assessment, false));
        }
    }

    public static void ApplyInterruptedRunGate(PreflightResult result, bool recoveryMode, string detail)
    {
        if (!recoveryMode)
        {
            result.Checks.Add(new SafetyCheck("previous-run-interruption", "PASS", detail, false));
            return;
        }
        result.Checks.Add(new SafetyCheck("previous-run-interruption", "FAIL", detail, false));
        result.FeatureSkips.Add(new FeatureSkip("DELIVERY_OPTIMIZATION", "Recovery mode after interrupted/untrusted previous run."));
        result.FeatureSkips.Add(new FeatureSkip("COMPONENT_CLEANUP", "Recovery mode after interrupted/untrusted previous run."));
        result.FeatureSkips.Add(new FeatureSkip("DRIVE_OPTIMIZATION", "Recovery mode after interrupted/untrusted previous run."));
    }

    public static void ApplyStateStoreGate(PreflightResult result)
    {
        var ok = StateStoreHealthProbe.Probe(out var detail);
        result.Checks.Add(new SafetyCheck("state-store-durability", ok ? "PASS" : "FAIL", detail, true));
    }

    public static void ApplyCooldownGates(PreflightResult result, string spacePressure)
    {
        if (MaintenanceCooldownJournal.ShouldSkip("DRIVE_OPTIMIZATION", TimeSpan.FromDays(7), false, spacePressure, out var driveDetail))
            result.FeatureSkips.Add(new FeatureSkip("DRIVE_OPTIMIZATION", "Cooldown: " + driveDetail));
        if (MaintenanceCooldownJournal.ShouldSkip("COMPONENT_CLEANUP", TimeSpan.FromDays(14), true, spacePressure, out var componentDetail))
            result.FeatureSkips.Add(new FeatureSkip("COMPONENT_CLEANUP", "Cooldown: " + componentDetail));
        if (MaintenanceCooldownJournal.ShouldSkip("DELIVERY_OPTIMIZATION", TimeSpan.FromDays(1), true, spacePressure, out var deliveryDetail))
            result.FeatureSkips.Add(new FeatureSkip("DELIVERY_OPTIMIZATION", "Cooldown: " + deliveryDetail));
    }

    public static ApprovedRoot[] FilterApprovedRoots(ApprovedRoot[] roots, PreflightResult preflight)
    {
        var blockedCategories = new HashSet<string>(preflight.FeatureSkips.Select(s => s.Feature), StringComparer.OrdinalIgnoreCase);
        return roots.Where(r => !blockedCategories.Contains(r.Category)).ToArray();
    }

    public static ScanResult ApplyFeatureSkips(ScanResult source, PreflightResult preflight)
    {
        if (source.Candidates.Count == 0) return source;
        var blockedCategories = new HashSet<string>(preflight.FeatureSkips.Select(s => s.Feature), StringComparer.OrdinalIgnoreCase);
        source.Candidates.RemoveAll(c => blockedCategories.Contains(c.Category));
        return source;
    }

    private static void Add(PreflightResult r, bool pass, string name, string detail, bool globalBlock)
        => r.Checks.Add(new SafetyCheck(name, pass ? "PASS" : "FAIL", detail, globalBlock));
}

internal sealed record SystemProfile(
    string OsDescription,
    string OsArchitecture,
    string ProcessArchitecture,
    int LogicalProcessors,
    ulong? PhysicalMemoryBytes,
    string SystemDrive,
    string FileSystem,
    long TotalBytes,
    long FreeBytes,
    double FreePercent,
    bool Administrator);

internal static class SystemProfiler
{
    public static SystemProfile Capture()
    {
        var windows = Environment.GetFolderPath(Environment.SpecialFolder.Windows);
        var root = Path.GetPathRoot(windows) ?? "";
        string fs = "UNKNOWN";
        long total = 0, free = 0;
        try
        {
            var d = new DriveInfo(root);
            if (d.IsReady)
            {
                fs = d.DriveFormat;
                total = d.TotalSize;
                free = d.AvailableFreeSpace;
            }
        }
        catch { }

        ulong? memory = null;
        try
        {
            var m = new MemoryStatusEx { Length = (uint)Marshal.SizeOf<MemoryStatusEx>() };
            if (GlobalMemoryStatusEx(ref m)) memory = m.TotalPhys;
        }
        catch { }

        return new SystemProfile(
            RuntimeInformation.OSDescription,
            RuntimeInformation.OSArchitecture.ToString(),
            RuntimeInformation.ProcessArchitecture.ToString(),
            Environment.ProcessorCount,
            memory,
            root,
            fs,
            total,
            free,
            total > 0 ? free * 100.0 / total : 0,
            WindowsMaintenance.IsAdministrator());
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
    private struct MemoryStatusEx
    {
        public uint Length;
        public uint MemoryLoad;
        public ulong TotalPhys;
        public ulong AvailPhys;
        public ulong TotalPageFile;
        public ulong AvailPageFile;
        public ulong TotalVirtual;
        public ulong AvailVirtual;
        public ulong AvailExtendedVirtual;
    }

    [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool GlobalMemoryStatusEx(ref MemoryStatusEx lpBuffer);
}

internal sealed record PcHealthSnapshot(
    DateTime CapturedUtc,
    TimeSpan Uptime,
    int ProcessCount,
    int StartupEntryCount,
    bool PendingServicingReboot,
    string PhysicalDiskHealthProbe,
    string TrimProbe,
    string DirtyBitProbe,
    string RecentStorageErrorProbe,
    string Assessment);

internal static class PcHealthDiagnostics
{
    public static PcHealthSnapshot Capture(SystemProfile? profile)
    {
        int processCount = 0;
        try { processCount = Process.GetProcesses().Length; } catch { }
        var startupCount = CountStartupEntries();
        var pending = WindowsState.HasPendingServicingReboot();
        var physical = RunReadOnlyPowerShell("$dl=$env:SystemDrive.TrimEnd(':'); Get-Partition -DriveLetter $dl -ErrorAction Stop | Get-Disk -ErrorAction Stop | Select-Object Number,FriendlyName,HealthStatus,OperationalStatus,BusType,Size | ConvertTo-Json -Compress");
        var windows = Environment.GetFolderPath(Environment.SpecialFolder.Windows);
        var fsutil = Path.Combine(windows, "System32", "fsutil.exe");
        var trim = RunReadOnlyExe(fsutil, "behavior query DisableDeleteNotify");
        var systemDrive = Path.GetPathRoot(windows)?.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar) ?? "C:";
        var dirty = RunReadOnlyExe(fsutil, $"dirty query {systemDrive}");
        var recentStorageErrors = RunReadOnlyPowerShell("$ids=7,51,55,57,129,153; $providers=@('disk','ntfs','storahci','stornvme','volmgr','partmgr'); $since=(Get-Date).AddHours(-24); $ev=@(Get-WinEvent -FilterHashtable @{LogName='System'; StartTime=$since} -ErrorAction Stop | Where-Object { $ids -contains $_.Id -and $providers -contains $_.ProviderName.ToLowerInvariant() }); Write-Output ('RISK_COUNT=' + $ev.Count)");
        var uptime = TimeSpan.FromMilliseconds(Environment.TickCount64);
        var assessment = profile is not null && profile.FreePercent < 5 ? "CRITICAL_LOW_DISK" :
                         profile is not null && profile.FreePercent < 10 ? "LOW_DISK" : "NORMAL";
        return new PcHealthSnapshot(DateTime.UtcNow, uptime, processCount, startupCount, pending, physical, trim, dirty, recentStorageErrors, assessment);
    }

    private static int CountStartupEntries()
    {
        int count = 0;
        foreach (var spec in new[]
        {
            (Registry.CurrentUser, @"Software\Microsoft\Windows\CurrentVersion\Run"),
            (Registry.LocalMachine, @"Software\Microsoft\Windows\CurrentVersion\Run"),
            (Registry.LocalMachine, @"Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Run")
        })
        {
            try
            {
                using var key = spec.Item1.OpenSubKey(spec.Item2);
                if (key is not null) count += key.GetValueNames().Length;
            }
            catch { }
        }
        return count;
    }

    private static string RunReadOnlyPowerShell(string script)
    {
        try
        {
            var windows = Environment.GetFolderPath(Environment.SpecialFolder.Windows);
            var ps = Path.Combine(windows, "System32", "WindowsPowerShell", "v1.0", "powershell.exe");
            if (!File.Exists(ps)) return "UNAVAILABLE";
            var encoded = Convert.ToBase64String(System.Text.Encoding.Unicode.GetBytes("$ErrorActionPreference='Stop'; " + script));
            return RunReadOnlyExe(ps, $"-NoProfile -NonInteractive -EncodedCommand {encoded}");
        }
        catch (Exception ex) { return "PROBE_FAIL: " + ex.Message; }
    }

    internal static bool IsTrustedExecutablePathForTests(string exe, string windowsRoot)
        => IsTrustedSystemExecutablePath(exe, windowsRoot, requireExists: false);

    private static bool IsTrustedSystemExecutablePath(string exe, string? windowsRoot = null, bool requireExists = true)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(exe) || !Path.IsPathFullyQualified(exe) ||
                !exe.EndsWith(".exe", StringComparison.OrdinalIgnoreCase))
                return false;

            windowsRoot ??= Environment.GetFolderPath(Environment.SpecialFolder.Windows);
            if (string.IsNullOrWhiteSpace(windowsRoot) || !Path.IsPathFullyQualified(windowsRoot)) return false;

            var system32 = Path.GetFullPath(Path.Combine(windowsRoot, "System32"))
                .TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar) + Path.DirectorySeparatorChar;
            var full = Path.GetFullPath(exe);
            if (!full.StartsWith(system32, StringComparison.OrdinalIgnoreCase)) return false;
            return !requireExists || File.Exists(full);
        }
        catch { return false; }
    }

    private static string RunReadOnlyExe(string exe, string args)
    {
        try
        {
            if (!IsTrustedSystemExecutablePath(exe)) return "PROBE_BLOCKED_UNTRUSTED_EXE_PATH";
            var psi = new ProcessStartInfo(exe, args)
            {
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                CreateNoWindow = true
            };
            using var p = Process.Start(psi);
            if (p is null) return "PROBE_FAIL: process start";
            var stdout = p.StandardOutput.ReadToEnd();
            var stderr = p.StandardError.ReadToEnd();
            if (!p.WaitForExit(15_000))
            {
                try { p.Kill(entireProcessTree: true); } catch { }
                return "PROBE_TIMEOUT";
            }
            var text = string.IsNullOrWhiteSpace(stdout) ? stderr : stdout;
            if (text.Length > 8_000) text = text[..8_000] + "...[truncated]";
            return $"exit={p.ExitCode}; {text.Trim()}";
        }
        catch (Exception ex) { return "PROBE_FAIL: " + ex.Message; }
    }
}

internal static class StorageReliabilityPolicy
{
    public static string Classify(string? probe)
    {
        if (string.IsNullOrWhiteSpace(probe)) return "UNKNOWN";
        const string token = "RISK_COUNT=";
        var i = probe.IndexOf(token, StringComparison.OrdinalIgnoreCase);
        if (i < 0) return "UNKNOWN";
        i += token.Length;
        var end = i;
        while (end < probe.Length && char.IsDigit(probe[end])) end++;
        if (end == i || !int.TryParse(probe[i..end], out var count) || count < 0) return "UNKNOWN";
        if (count >= 2) return "BLOCK_WRITES";
        if (count == 1) return "HEAVY_ONLY";
        return "HEALTHY";
    }
}

internal static class StateStoreHealthProbe
{
    private static string StateDirectory => Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "DiskGuardSpace", "State");

    public static bool Probe(out string detail)
    {
        detail = "unknown";
        string? probePath = null;
        try
        {
            Directory.CreateDirectory(StateDirectory);
            if (SafetyPolicy.IsReparsePoint(StateDirectory))
            {
                detail = "state directory is a reparse point";
                return false;
            }
            if (!IsTrustedLocalStateVolume(StateDirectory, out var volumeDetail))
            {
                detail = "state directory volume is not trusted: " + volumeDetail;
                return false;
            }
            if (!SafetyPolicy.IsRuntimeProtectedPath(StateDirectory))
            {
                detail = "state directory is not covered by runtime self-protection";
                return false;
            }

            var expected = RandomNumberGenerator.GetBytes(4096);
            probePath = Path.Combine(StateDirectory, ".durability-probe-" + Guid.NewGuid().ToString("N") + ".bin");
            using (var fs = new FileStream(probePath, FileMode.CreateNew, FileAccess.Write, FileShare.None, 4096, FileOptions.WriteThrough))
            {
                fs.Write(expected);
                fs.Flush(flushToDisk: true);
            }
            var actual = File.ReadAllBytes(probePath);
            if (!EvaluateForTests(reparsePoint: false, trustedLocalVolume: true, selfProtected: true, bytesEqual: expected.AsSpan().SequenceEqual(actual)))
            {
                detail = "state write/read durability probe mismatch";
                return false;
            }
            File.Delete(probePath);
            probePath = null;
            detail = "state directory write/read/fsync/delete durability probe passed";
            return true;
        }
        catch (Exception ex)
        {
            detail = "state durability probe failed: " + ex.Message;
            return false;
        }
        finally
        {
            if (!string.IsNullOrWhiteSpace(probePath))
            {
                try { if (File.Exists(probePath)) File.Delete(probePath); } catch { }
            }
        }
    }

    private static bool IsTrustedLocalStateVolume(string path, out string detail)
    {
        detail = "unknown";
        try
        {
            var root = Path.GetPathRoot(Path.GetFullPath(path));
            if (string.IsNullOrWhiteSpace(root)) { detail = "root unresolved"; return false; }
            var drive = new DriveInfo(root);
            if (!drive.IsReady) { detail = "volume not ready"; return false; }
            if (drive.DriveType != DriveType.Fixed) { detail = "volume is not fixed"; return false; }
            if (!string.Equals(drive.DriveFormat, "NTFS", StringComparison.OrdinalIgnoreCase)) { detail = "volume is not NTFS"; return false; }
            detail = $"fixed NTFS volume {drive.Name}";
            return true;
        }
        catch (Exception ex) { detail = ex.Message; return false; }
    }

    internal static bool EvaluateForTests(bool reparsePoint, bool trustedLocalVolume, bool selfProtected, bool bytesEqual)
        => !reparsePoint && trustedLocalVolume && selfProtected && bytesEqual;
}

internal static class RuntimeFeatureGuard
{
    private static readonly Dictionary<string, string[]> CategoryProcesses = new(StringComparer.OrdinalIgnoreCase)
    {
        ["CHROME_CACHE"] = new[] { "chrome" },
        ["EDGE_CACHE"] = new[] { "msedge" },
        ["BRAVE_CACHE"] = new[] { "brave" },
        ["CHROMIUM_CACHE"] = new[] { "chromium" },
        ["FIREFOX_CACHE"] = new[] { "firefox" },
        ["VSCODE_CACHE"] = new[] { "Code" },
        ["CURSOR_CACHE"] = new[] { "Cursor" },
        ["DISCORD_CACHE"] = new[] { "Discord" },
        ["SLACK_CACHE"] = new[] { "slack" }
    };

    public static bool IsCategorySafeForWrite(string category, out string detail)
    {
        detail = "no live-process guard required";
        if (!CategoryProcesses.TryGetValue(category, out var processNames)) return true;
        try
        {
            foreach (var processName in processNames)
            {
                var matches = Process.GetProcessesByName(processName);
                try
                {
                    if (matches.Length > 0)
                    {
                        detail = $"{processName}.exe is running; cache category {category} is preserved.";
                        return false;
                    }
                }
                finally
                {
                    foreach (var process in matches) process.Dispose();
                }
            }
            detail = $"owning application process is closed for {category}";
            return true;
        }
        catch (Exception ex)
        {
            detail = $"could not re-verify owning process for {category}: {ex.Message}";
            return false;
        }
    }

    internal static string[] OwningProcessesForCategoryForTests(string category)
        => CategoryProcesses.TryGetValue(category, out var names) ? names.ToArray() : Array.Empty<string>();
}

internal static class MaintenanceRuntimeGuards
{
    private const long GiB = 1024L * 1024L * 1024L;

    public static bool HasMinimumSystemFreeSpace(long minimumBytes, out string detail)
    {
        detail = "unknown";
        try
        {
            var snap = DiskSnapshot.CaptureSystemDrive();
            detail = $"free={snap.FreeBytes}; required={minimumBytes}";
            return snap.FreeBytes >= minimumBytes;
        }
        catch (Exception ex)
        {
            detail = "free-space recheck failed: " + ex.Message;
            return false;
        }
    }

    public static bool HeavyStagePowerStillSafe(out string detail) => PowerSafety.IsOnAcPower(out detail);

    internal static long ComponentCleanupMinimumFreeBytes => GiB;
}

internal static class PowerSafety
{
    public static bool IsOnAcPower(out string detail)
    {
        detail = "unknown";
        if (!OperatingSystem.IsWindows()) return false;
        try
        {
            if (!GetSystemPowerStatus(out var status))
            {
                detail = "GetSystemPowerStatus failed";
                return false;
            }
            detail = $"ACLineStatus={status.ACLineStatus}; BatteryFlag={status.BatteryFlag}; BatteryPercent={status.BatteryLifePercent}";
            return status.ACLineStatus == 1;
        }
        catch (Exception ex)
        {
            detail = "power probe failed: " + ex.Message;
            return false;
        }
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct SystemPowerStatus
    {
        public byte ACLineStatus;
        public byte BatteryFlag;
        public byte BatteryLifePercent;
        public byte SystemStatusFlag;
        public uint BatteryLifeTime;
        public uint BatteryFullLifeTime;
    }

    [DllImport("kernel32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool GetSystemPowerStatus(out SystemPowerStatus sps);
}

internal sealed class SingleInstanceGuard : IDisposable
{
    private readonly Mutex mutex;
    private bool owns;

    private SingleInstanceGuard(Mutex mutex, bool owns)
    {
        this.mutex = mutex;
        this.owns = owns;
    }

    public static SingleInstanceGuard Acquire()
    {
        var mutex = new Mutex(false, @"Local\DiskGuardSpace.AutoCare.v6");
        bool owns;
        try { owns = mutex.WaitOne(0); }
        catch (AbandonedMutexException) { owns = true; }
        if (!owns)
        {
            mutex.Dispose();
            throw new IOException("FAIL-CLOSED: another DiskGuardSpace auto-care session is already running.");
        }
        return new SingleInstanceGuard(mutex, true);
    }

    public void Dispose()
    {
        if (owns)
        {
            try { mutex.ReleaseMutex(); } catch { }
            owns = false;
        }
        mutex.Dispose();
    }
}

internal static class WindowsState
{
    public static bool HasPendingServicingReboot()
    {
        if (!OperatingSystem.IsWindows()) return false;
        try
        {
            using var cbs = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending");
            if (cbs is not null) return true;
            using var wu = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired");
            return wu is not null;
        }
        catch
        {
            // Unknown state is handled conservatively by caller only for write-heavy servicing.
            return true;
        }
    }
}

internal sealed record PerformanceExecution(bool Succeeded, int ExitCode, string StdOut, string StdErr, string CommandLine);

internal static class PerformanceMaintenance
{
    public static PerformanceExecution OptimizeSystemDrive()
    {
        var windows = Environment.GetFolderPath(Environment.SpecialFolder.Windows);
        var root = Path.GetPathRoot(windows) ?? throw new IOException("System drive unresolved");
        var defrag = Path.Combine(windows, "System32", "defrag.exe");
        if (!File.Exists(defrag)) throw new FileNotFoundException("defrag.exe bulunamadı.", defrag);
        var driveToken = root.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
        var args = $"{driveToken} /O /H /U /V";
        var e = Run(defrag, args);
        return new PerformanceExecution(e.Succeeded, e.ExitCode, e.StdOut, e.StdErr, e.CommandLine);
    }

    private static MaintenanceExecution Run(string exe, string args)
    {
        var psi = new ProcessStartInfo(exe, args)
        {
            UseShellExecute = false,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            CreateNoWindow = true
        };
        using var p = Process.Start(psi) ?? throw new InvalidOperationException("Bakım işlemi başlatılamadı.");
        var stdoutTask = p.StandardOutput.ReadToEndAsync();
        var stderrTask = p.StandardError.ReadToEndAsync();
        if (!p.WaitForExit(30 * 60 * 1000))
        {
            try { p.Kill(entireProcessTree: true); } catch { }
            throw new TimeoutException("FAIL-CLOSED: drive optimization exceeded 30 minutes.");
        }
        var stdout = stdoutTask.GetAwaiter().GetResult();
        var stderr = stderrTask.GetAwaiter().GetResult();
        return new MaintenanceExecution(p.ExitCode == 0, p.ExitCode, Trim(stdout), Trim(stderr), $"{exe} {args}");
    }

    private static string Trim(string s) => s.Length <= 32_000 ? s : s[..32_000] + "\n...[truncated]";
}

internal static class ExtraSpaceMaintenance
{
    public static bool IsDeliveryOptimizationCleanupSupported(out string detail)
    {
        detail = "unknown";
        try
        {
            var windows = Environment.GetFolderPath(Environment.SpecialFolder.Windows);
            var powershell = Path.Combine(windows, "System32", "WindowsPowerShell", "v1.0", "powershell.exe");
            if (!File.Exists(powershell)) { detail = "powershell.exe missing"; return false; }
            const string script = "$c=Get-Command Delete-DeliveryOptimizationCache -ErrorAction SilentlyContinue; if($null -eq $c){exit 3}else{Write-Output $c.Name; exit 0}";
            var encoded = Convert.ToBase64String(System.Text.Encoding.Unicode.GetBytes(script));
            var psi = new ProcessStartInfo(powershell, $"-NoProfile -NonInteractive -EncodedCommand {encoded}")
            {
                UseShellExecute = false, RedirectStandardOutput = true, RedirectStandardError = true, CreateNoWindow = true
            };
            using var p = Process.Start(psi);
            if (p is null) { detail = "probe start failed"; return false; }
            var outputTask = p.StandardOutput.ReadToEndAsync();
            var errorTask = p.StandardError.ReadToEndAsync();
            if (!p.WaitForExit(10_000))
            {
                try { p.Kill(entireProcessTree: true); } catch { }
                detail = "probe timeout";
                return false;
            }
            var output = outputTask.GetAwaiter().GetResult().Trim();
            var error = errorTask.GetAwaiter().GetResult().Trim();
            detail = p.ExitCode == 0 ? output : error;
            return p.ExitCode == 0;
        }
        catch (Exception ex) { detail = ex.Message; return false; }
    }

    public static MaintenanceExecution RunDeliveryOptimizationCleanup()
    {
        var windows = Environment.GetFolderPath(Environment.SpecialFolder.Windows);
        var powershell = Path.Combine(windows, "System32", "WindowsPowerShell", "v1.0", "powershell.exe");
        if (!File.Exists(powershell)) throw new FileNotFoundException("Windows PowerShell bulunamadı.", powershell);

        const string script = "$ErrorActionPreference='Stop'; if (Get-Command Delete-DeliveryOptimizationCache -ErrorAction SilentlyContinue) { Delete-DeliveryOptimizationCache -Force; exit 0 } else { Write-Error 'Delete-DeliveryOptimizationCache unavailable'; exit 3 }";
        var encoded = Convert.ToBase64String(System.Text.Encoding.Unicode.GetBytes(script));
        var args = $"-NoProfile -NonInteractive -EncodedCommand {encoded}";
        var psi = new ProcessStartInfo(powershell, args)
        {
            UseShellExecute = false,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            CreateNoWindow = true
        };
        using var p = Process.Start(psi) ?? throw new InvalidOperationException("Delivery Optimization cleanup başlatılamadı.");
        var stdoutTask = p.StandardOutput.ReadToEndAsync();
        var stderrTask = p.StandardError.ReadToEndAsync();
        if (!p.WaitForExit(10 * 60 * 1000))
        {
            try { p.Kill(entireProcessTree: true); } catch { }
            throw new TimeoutException("FAIL-CLOSED: Delivery Optimization cleanup exceeded 10 minutes.");
        }
        var stdout = stdoutTask.GetAwaiter().GetResult();
        var stderr = stderrTask.GetAwaiter().GetResult();
        return new MaintenanceExecution(p.ExitCode == 0, p.ExitCode, Trim(stdout), Trim(stderr), "powershell.exe -NoProfile -NonInteractive -EncodedCommand <redacted>");
    }

    private static string Trim(string s) => s.Length <= 32_000 ? s : s[..32_000] + "\n...[truncated]";
}

internal sealed class AutoCareReport
{
    public string SchemaVersion { get; set; } = "10.0";
    public string Mode { get; set; } = "auto-care";
    public DateTime CreatedUtc { get; set; } = DateTime.UtcNow;
    public string PrimaryPriority { get; set; } = "DISK_SPACE";
    public string TriggerMode { get; set; } = "INTERACTIVE_OR_MANUAL";
    public string SpacePressure { get; set; } = "UNKNOWN";
    public bool ApplyRequested { get; set; }
    public string OverallStatus { get; set; } = "NOT_RUN";
    public string ExecutableSha256 { get; set; } = "";
    public string RunId { get; set; } = "";
    public bool RecoveryModeFromInterruptedRun { get; set; }
    public string RecoveryModeReason { get; set; } = "";
    public SystemProfile? SystemProfile { get; set; }
    public PcHealthSnapshot? HealthSnapshot { get; set; }
    public PerformanceSnapshot? PerformanceSnapshot { get; set; }
    public AdvancedSpaceSnapshot? AdvancedSpaceSnapshot { get; set; }
    public MaintenanceDiagnosticsSnapshot? MaintenanceDiagnostics { get; set; }
    public List<SafetyCheck> SafetyChecks { get; set; } = new();
    public List<FeatureSkip> FeatureSkips { get; set; } = new();
    public string? SafeScanReport { get; set; }
    public string? SafeCleanupReport { get; set; }
    public string? DeepAnalysisReport { get; set; }
    public bool DeepAnalysisSkippedByPolicy { get; set; }
    public string? ComponentCleanupReport { get; set; }
    public string? DeliveryOptimizationReport { get; set; }
    public PerformanceExecution? DriveOptimization { get; set; }
    public long FreeBytesBefore { get; set; }
    public long FreeBytesAfter { get; set; }
    public long NetObservedFreeGainBytes { get; set; }
    public long VerifiedSafeCleanupGainBytes { get; set; }
    public long VerifiedComponentCleanupGainBytes { get; set; }
    public long VerifiedDeliveryOptimizationGainBytes { get; set; }
    public long RemainingEstimatedOpportunityBytes { get; set; }
    public string NextCriticalFocus { get; set; } = "UNDETERMINED";
    public List<string> Notes { get; set; } = new();
    public List<string> FailedWriteStages { get; set; } = new();
    public Dictionary<string, string> ArtifactSha256 { get; set; } = new(StringComparer.OrdinalIgnoreCase);
}

internal static class AutoCareRunner
{
    public static int Run(string[] args)
    {
        if (!OperatingSystem.IsWindows()) throw new PlatformNotSupportedException("auto-care only supports Windows.");
        using var instanceGuard = SingleInstanceGuard.Acquire();
        var options = AutoCareOptions.Parse(args);
        var runId = Guid.NewGuid().ToString("N");
        var recoveryMode = MaintenanceRunJournal.ShouldEnterRecoveryMode(out var recoveryReason);
        MaintenanceRunJournal.Begin(runId);
        var report = new AutoCareReport
        {
            ApplyRequested = options.Apply,
            SystemProfile = SystemProfiler.Capture(),
            RunId = runId,
            RecoveryModeFromInterruptedRun = recoveryMode,
            RecoveryModeReason = recoveryMode ? recoveryReason : "",
            TriggerMode = options.StartupBackground ? "STARTUP_BACKGROUND" : "INTERACTIVE_OR_MANUAL"
        };
        if (report.SystemProfile is not null)
            report.SpacePressure = SpacePressurePolicy.Classify(report.SystemProfile.FreeBytes, report.SystemProfile.TotalBytes);
        try
        {
            var exe = Environment.ProcessPath;
            if (!string.IsNullOrWhiteSpace(exe) && File.Exists(exe)) report.ExecutableSha256 = Hashing.Sha256(exe);
        }
        catch { }
        report.HealthSnapshot = PcHealthDiagnostics.Capture(report.SystemProfile);
        try { report.PerformanceSnapshot = PerformanceDiagnostics.Capture(); } catch (Exception ex) { report.Notes.Add("Performance snapshot unavailable: " + ex.Message); }
        try { report.AdvancedSpaceSnapshot = AdvancedSpaceAnalyzer.Capture(); } catch (Exception ex) { report.Notes.Add("Advanced space snapshot unavailable: " + ex.Message); }
        var preflight = AutoCarePreflight.Run();
        AutoCarePreflight.ApplyInterruptedRunGate(preflight, recoveryMode, recoveryReason);
        AutoCarePreflight.ApplyPhysicalDiskHealthGate(preflight, report.HealthSnapshot);
        AutoCarePreflight.ApplyPerformancePressureGate(preflight, report.PerformanceSnapshot);
        AutoCarePreflight.ApplyCooldownGates(preflight, report.SpacePressure);
        if (options.Apply) AutoCarePreflight.ApplyStateStoreGate(preflight);
        report.SafetyChecks = preflight.Checks;
        report.FeatureSkips = preflight.FeatureSkips;

        var sessionDir = ResolveSessionDir(options);
        Directory.CreateDirectory(sessionDir);
        var masterReportPath = string.IsNullOrWhiteSpace(options.ReportPath)
            ? Path.Combine(sessionDir, "auto-care.json")
            : Path.GetFullPath(options.ReportPath);

        var before = DiskSnapshot.CaptureSystemDrive();
        report.FreeBytesBefore = before.FreeBytes;

        try { report.MaintenanceDiagnostics = ReadOnlyMaintenanceDiagnostics.Capture(false); }
        catch (Exception ex) { report.Notes.Add("Read-only maintenance diagnostics incomplete: " + ex.Message); }

        if (preflight.GlobalWriteBlocked)
        {
            report.OverallStatus = "FAIL_CLOSED_PRECHECK";
            report.Notes.Add("One or more global negative controls failed. No write maintenance was executed.");
            // Read-only deep analysis is still useful and safe.
            RunOrSkipDeepAnalysis(options, sessionDir, report);
            FinalizeReport(report, before, masterReportPath);
            Print(report, masterReportPath);
            MaintenanceRunJournal.Complete(runId, success: false);
            return 70;
        }

        var roots = AutoCarePreflight.FilterApprovedRoots(SafetyPolicy.GetApprovedCleanupRoots(), preflight);
        var safeScan = Scanner.ScanApprovedRoots(roots, options.MinAgeDays);
        AutoCarePreflight.ApplyFeatureSkips(safeScan, preflight);
        var scanSnapshot = DiskSnapshot.CaptureSystemDrive();
        var scanReport = EvidenceReport.FromScan("auto-care-safe-scan", before, scanSnapshot, safeScan);
        var scanPath = Path.Combine(sessionDir, "01-safe-scan.json");
        ReportIO.WriteEvidence(scanReport, scanPath);
        report.SafeScanReport = scanPath;
        RecordArtifact(report, "safe-scan", scanPath);

        if (safeScan.FailClosedViolations > 0)
        {
            report.OverallStatus = "FAIL_CLOSED_SCAN";
            report.Notes.Add("Safe scan reported containment/access violations. All write stages were blocked.");
            RunOrSkipDeepAnalysis(options, sessionDir, report);
            FinalizeReport(report, before, masterReportPath);
            Print(report, masterReportPath);
            MaintenanceRunJournal.Complete(runId, success: false);
            return 71;
        }

        if (!options.Apply)
        {
            report.Notes.Add("Dry run: --apply was not supplied; no write maintenance executed.");
        }
        else
        {
            MaintenanceRunJournal.MarkStage(runId, "SAFE_CLEANUP");
            RunSafeCleanup(safeScan, roots, sessionDir, report);
            MaintenanceRunJournal.MarkStage(runId, "DELIVERY_OPTIMIZATION");
            RunDeliveryOptimization(options, preflight, sessionDir, report);
            MaintenanceRunJournal.MarkStage(runId, "COMPONENT_CLEANUP");
            RunComponentCleanup(options, preflight, sessionDir, report);
            MaintenanceRunJournal.MarkStage(runId, "DRIVE_OPTIMIZATION");
            RunPerformanceOptimization(options, preflight, report);
        }

        MaintenanceRunJournal.MarkStage(runId, "DEEP_ANALYSIS");
        RunOrSkipDeepAnalysis(options, sessionDir, report);
        if (options.DeepHealth)
        {
            try { report.MaintenanceDiagnostics = ReadOnlyMaintenanceDiagnostics.Capture(true); }
            catch (Exception ex) { report.Notes.Add("Deep read-only health diagnostics incomplete: " + ex.Message); }
        }
        FinalizeReport(report, before, masterReportPath);

        bool analysisOk = ReadOnlyEvidenceVerified(report);
        bool writeStagesOk = !options.Apply || AllExecutedWriteStagesVerified(report);
        report.OverallStatus = analysisOk && writeStagesOk ? (options.Apply ? "VERIFIED_PASS" : "VERIFIED_DRY_RUN") : "PARTIAL_OR_FAIL_CLOSED";
        AtomicFile.WriteAllText(masterReportPath, JsonSerializer.Serialize(report, Json.Options));
        Print(report, masterReportPath);
        var finalSuccess = report.OverallStatus is "VERIFIED_PASS" or "VERIFIED_DRY_RUN";
        MaintenanceRunJournal.Complete(runId, finalSuccess);
        return finalSuccess ? 0 : 72;
    }

    public static int Verify(string[] args)
    {
        if (args.Length < 1) throw new ArgumentException("Kullanım: verify-auto-care <auto-care.json>");
        var r = JsonSerializer.Deserialize<AutoCareReport>(File.ReadAllText(args[0]), Json.Options)
                ?? throw new InvalidDataException("Auto-care report okunamadı.");
        var checks = new List<string>();
        bool ok = true;
        void Check(bool condition, string name)
        {
            checks.Add((condition ? "PASS: " : "FAIL: ") + name);
            if (!condition) ok = false;
        }

        Check(r.SchemaVersion == "10.0", "master schema version is 10.0");
        Check(r.TriggerMode is "STARTUP_BACKGROUND" or "INTERACTIVE_OR_MANUAL", "trigger mode is bounded");
        Check(Guid.TryParseExact(r.RunId, "N", out _), "run id is canonical GUID-N");
        if (r.RecoveryModeFromInterruptedRun) Check(!string.IsNullOrWhiteSpace(r.RecoveryModeReason), "interrupted-run recovery mode has reason");
        Check(r.PrimaryPriority == "DISK_SPACE", "disk-space remains primary priority");
        Check(r.SpacePressure is "UNKNOWN" or "EMERGENCY" or "CRITICAL" or "LOW" or "WATCH" or "HEALTHY", "space-pressure tier is bounded");
        Check(r.ExecutableSha256.Length == 64, "report contains executable SHA-256");
        try
        {
            var currentExe = Environment.ProcessPath;
            Check(!string.IsNullOrWhiteSpace(currentExe) && File.Exists(currentExe) && r.ExecutableSha256.Equals(Hashing.Sha256(currentExe), StringComparison.OrdinalIgnoreCase), "report executable SHA-256 matches verifier binary");
        }
        catch { Check(false, "report executable SHA-256 matches verifier binary"); }
        Check(r.FreeBytesBefore >= 0 && r.FreeBytesAfter >= 0, "disk snapshots non-negative");
        Check(r.FreeBytesAfter - r.FreeBytesBefore == r.NetObservedFreeGainBytes, "net free-space arithmetic");
        Check(r.SafetyChecks.Count > 0, "negative-control evidence present");
        Check(r.HealthSnapshot is not null, "PC health snapshot present");
        if (r.HealthSnapshot is not null) Check(!string.IsNullOrWhiteSpace(r.HealthSnapshot.RecentStorageErrorProbe), "recent storage I/O event probe present");
        if (r.ApplyRequested) Check(r.SafetyChecks.Any(x => x.Name == "state-store-durability"), "apply run includes state-store durability gate");
        if (r.RecoveryModeFromInterruptedRun)
        {
            Check(string.IsNullOrWhiteSpace(r.DeliveryOptimizationReport), "recovery mode executes no Delivery Optimization cleanup");
            Check(string.IsNullOrWhiteSpace(r.ComponentCleanupReport), "recovery mode executes no component cleanup");
            Check(r.DriveOptimization is null, "recovery mode executes no drive optimization");
        }
        Check(r.PerformanceSnapshot is not null, "performance snapshot present");
        Check(r.AdvancedSpaceSnapshot is not null, "advanced space snapshot present");
        Check(r.MaintenanceDiagnostics is not null, "maintenance diagnostics snapshot present");
        if (r.MaintenanceDiagnostics is not null)
        {
            Check(r.MaintenanceDiagnostics.Commands.All(x => x.ReadOnly && !x.CommandLine.Contains("/RestoreHealth", StringComparison.OrdinalIgnoreCase) && !x.CommandLine.Contains("/scannow", StringComparison.OrdinalIgnoreCase) && !x.CommandLine.Contains(" /f", StringComparison.OrdinalIgnoreCase) && !x.CommandLine.Contains(" /r", StringComparison.OrdinalIgnoreCase) && !x.CommandLine.Contains("delete shadows", StringComparison.OrdinalIgnoreCase) && !x.CommandLine.Contains("resize shadowstorage", StringComparison.OrdinalIgnoreCase)), "diagnostic command set remains read-only");
            var allowedDiagnostics = new HashSet<string>(new[] { "DISM_CHECK_HEALTH", "DISM_ANALYZE_COMPONENT_STORE", "COMPACT_OS_QUERY", "POWER_CAPABILITIES", "POWER_ACTIVE_SCHEME", "VSS_SHADOW_STORAGE", "DEFRAG_ANALYZE", "SFC_VERIFY_ONLY", "CHKDSK_SCAN" }, StringComparer.Ordinal);
            Check(r.MaintenanceDiagnostics.Commands.All(x => allowedDiagnostics.Contains(x.Name)), "diagnostic command names are allow-listed");
            Check(r.MaintenanceDiagnostics.Commands.All(DiagnosticCommandMatchesPolicy), "diagnostic command lines match their read-only allow-list policy");
        }
        if (r.AdvancedSpaceSnapshot is not null)
        {
            var allowedPolicies = new HashSet<string>(new[] { "REVIEW_ONLY_FEATURE_TRADEOFF", "REVIEW_ONLY_DIAGNOSTIC", "WINDOWS_SUPPORTED_CLEANUP_ONLY", "REVIEW_ONLY_USER_RECOVERY", "REBUILDABLE_REVIEW", "VIRTUAL_DISK_REVIEW_ONLY", "DO_NOT_TOUCH" }, StringComparer.Ordinal);
            Check(r.AdvancedSpaceSnapshot.Opportunities.All(x => x.ObservedBytes >= 0 && allowedPolicies.Contains(x.Policy)), "advanced-space policies are bounded and non-negative");
            Check(r.AdvancedSpaceSnapshot.Opportunities.Where(x => x.Name is "WINDOWS_UPDATE_DOWNLOAD" or "WINDOWS_INSTALLER").All(x => x.Policy == "DO_NOT_TOUCH"), "Windows Update/Installer stores remain do-not-touch");
            Check(r.AdvancedSpaceSnapshot.Opportunities.Where(x => x.Name.Contains("VHDX", StringComparison.OrdinalIgnoreCase)).All(x => x.Policy == "VIRTUAL_DISK_REVIEW_ONLY"), "virtual disks remain review-only");
        }
        Check(r.SafetyChecks.All(x => x.Status is "PASS" or "FAIL"), "negative-control statuses bounded");
        if (r.OverallStatus == "VERIFIED_PASS")
        {
            Check(r.ApplyRequested, "verified pass implies apply requested");
            Check(r.SafetyChecks.All(x => !x.GlobalBlock || x.Status == "PASS"), "all global write gates passed");
        }
        Check(r.RemainingEstimatedOpportunityBytes >= 0, "remaining opportunity non-negative");
        Check(!string.IsNullOrWhiteSpace(r.SafeScanReport) && EvidenceFileVerified(r.SafeScanReport), "linked safe-scan evidence verifies");
        if (r.DeepAnalysisSkippedByPolicy)
        {
            Check(string.IsNullOrWhiteSpace(r.DeepAnalysisReport), "policy-skipped deep analysis has no linked analysis artifact");
            Check(!r.ArtifactSha256.ContainsKey("deep-analysis"), "policy-skipped deep analysis has no analysis artifact hash");
        }
        else
        {
            Check(!string.IsNullOrWhiteSpace(r.DeepAnalysisReport) && AnalysisFileVerified(r.DeepAnalysisReport), "linked deep-analysis evidence verifies");
        }
        if (r.ApplyRequested)
            Check(!string.IsNullOrWhiteSpace(r.SafeCleanupReport) && EvidenceFileVerified(r.SafeCleanupReport), "linked safe-cleanup evidence verifies");
        if (!string.IsNullOrWhiteSpace(r.ComponentCleanupReport)) Check(EvidenceFileVerified(r.ComponentCleanupReport), "linked component-cleanup evidence verifies");
        if (!string.IsNullOrWhiteSpace(r.DeliveryOptimizationReport)) Check(EvidenceFileVerified(r.DeliveryOptimizationReport), "linked Delivery Optimization evidence verifies");
        if (r.DriveOptimization is not null) Check(r.DriveOptimization.Succeeded, "drive optimization exit code successful");
        if (r.OverallStatus == "VERIFIED_PASS") Check(r.FailedWriteStages.Count == 0, "no failed write stages in verified pass");
        Check(r.ArtifactSha256.Count > 0, "linked artifact hashes present");
        if (!string.IsNullOrWhiteSpace(r.SafeScanReport)) Check(ArtifactHashMatches(r, "safe-scan", r.SafeScanReport), "safe-scan artifact hash matches");
        if (!string.IsNullOrWhiteSpace(r.SafeCleanupReport)) Check(ArtifactHashMatches(r, "safe-cleanup", r.SafeCleanupReport), "safe-cleanup artifact hash matches");
        if (!string.IsNullOrWhiteSpace(r.DeliveryOptimizationReport)) Check(ArtifactHashMatches(r, "delivery-optimization", r.DeliveryOptimizationReport), "delivery-optimization artifact hash matches");
        if (!string.IsNullOrWhiteSpace(r.ComponentCleanupReport)) Check(ArtifactHashMatches(r, "component-cleanup", r.ComponentCleanupReport), "component-cleanup artifact hash matches");
        if (!string.IsNullOrWhiteSpace(r.DeepAnalysisReport)) Check(ArtifactHashMatches(r, "deep-analysis", r.DeepAnalysisReport), "deep-analysis artifact hash matches");
        Check(r.OverallStatus is "VERIFIED_PASS" or "VERIFIED_DRY_RUN" or "PARTIAL_OR_FAIL_CLOSED" or "FAIL_CLOSED_PRECHECK" or "FAIL_CLOSED_SCAN", "master status is bounded");
        if (r.OverallStatus is "VERIFIED_PASS" or "VERIFIED_DRY_RUN")
            Check(r.OverallStatus == (r.ApplyRequested ? "VERIFIED_PASS" : "VERIFIED_DRY_RUN"), "verified master status matches apply mode");

        var result = new VerificationResult(ok ? "VERIFIED_PASS" : "VERIFY_FAIL", checks);
        Console.WriteLine(JsonSerializer.Serialize(result, Json.Options));
        return ok ? 0 : 73;
    }

    private static void RecordArtifact(AutoCareReport report, string key, string path)
    {
        report.ArtifactSha256[key] = Hashing.Sha256(path);
    }

    internal static bool DiagnosticCommandMatchesPolicyForTests(DiagnosticCommandResult x) => DiagnosticCommandMatchesPolicy(x);

    private static bool DiagnosticCommandMatchesPolicy(DiagnosticCommandResult x)
    {
        if (!x.ReadOnly) return false;
        var c = x.CommandLine;
        if (c.Contains("/RestoreHealth", StringComparison.OrdinalIgnoreCase) || c.Contains("/scannow", StringComparison.OrdinalIgnoreCase) || c.Contains(" /f", StringComparison.OrdinalIgnoreCase) || c.Contains(" /r", StringComparison.OrdinalIgnoreCase) || c.Contains("/offlinescanandfix", StringComparison.OrdinalIgnoreCase) || c.Contains("delete shadows", StringComparison.OrdinalIgnoreCase) || c.Contains("resize shadowstorage", StringComparison.OrdinalIgnoreCase)) return false;
        return x.Name switch
        {
            "DISM_CHECK_HEALTH" => c.Contains("dism.exe", StringComparison.OrdinalIgnoreCase) && c.Contains("/CheckHealth", StringComparison.OrdinalIgnoreCase),
            "DISM_ANALYZE_COMPONENT_STORE" => c.Contains("dism.exe", StringComparison.OrdinalIgnoreCase) && c.Contains("/AnalyzeComponentStore", StringComparison.OrdinalIgnoreCase),
            "COMPACT_OS_QUERY" => c.Contains("compact.exe", StringComparison.OrdinalIgnoreCase) && c.Contains("/CompactOS:query", StringComparison.OrdinalIgnoreCase),
            "POWER_CAPABILITIES" => c.Contains("powercfg.exe", StringComparison.OrdinalIgnoreCase) && c.EndsWith(" /a", StringComparison.OrdinalIgnoreCase),
            "POWER_ACTIVE_SCHEME" => c.Contains("powercfg.exe", StringComparison.OrdinalIgnoreCase) && c.EndsWith(" /getactivescheme", StringComparison.OrdinalIgnoreCase),
            "VSS_SHADOW_STORAGE" => c.Contains("vssadmin.exe", StringComparison.OrdinalIgnoreCase) && c.EndsWith(" list shadowstorage", StringComparison.OrdinalIgnoreCase),
            "DEFRAG_ANALYZE" => c.Contains("defrag.exe", StringComparison.OrdinalIgnoreCase) && c.Contains(" /A", StringComparison.OrdinalIgnoreCase) && !c.Contains(" /O", StringComparison.OrdinalIgnoreCase),
            "SFC_VERIFY_ONLY" => c.Contains("sfc.exe", StringComparison.OrdinalIgnoreCase) && c.Contains("/verifyonly", StringComparison.OrdinalIgnoreCase),
            "CHKDSK_SCAN" => c.Contains("chkdsk.exe", StringComparison.OrdinalIgnoreCase) && c.Contains(" /scan", StringComparison.OrdinalIgnoreCase),
            _ => false
        };
    }

    private static bool ArtifactHashMatches(AutoCareReport report, string key, string path)
    {
        try
        {
            return report.ArtifactSha256.TryGetValue(key, out var expected)
                && expected.Length == 64
                && expected.Equals(Hashing.Sha256(path), StringComparison.OrdinalIgnoreCase);
        }
        catch { return false; }
    }

    private static void RunSafeCleanup(ScanResult scan, ApprovedRoot[] roots, string sessionDir, AutoCareReport report)
    {
        var b = DiskSnapshot.CaptureSystemDrive();
        var exec = Cleaner.ExecuteSafeCandidates(scan.Candidates, roots, quarantinePath: null);
        var a = DiskSnapshot.CaptureSystemDrive();
        var evidence = EvidenceReport.FromExecution("auto-care-safe-cleanup", b, a, scan, exec);
        var path = Path.Combine(sessionDir, "02-safe-cleanup.json");
        ReportIO.WriteEvidence(evidence, path);
        report.SafeCleanupReport = path;
        RecordArtifact(report, "safe-cleanup", path);
        report.VerifiedSafeCleanupGainBytes = Math.Max(0, evidence.VerifiedFreeGainBytes);
        if (!evidence.VerificationStatus.StartsWith("VERIFIED_PASS", StringComparison.Ordinal))
            report.Notes.Add("Safe cleanup was partial/fail-closed; failed or changed/in-use files were left untouched.");
        else if (evidence.VerificationStatus == "VERIFIED_PASS_BOUNDED")
            report.Notes.Add("Safe cleanup succeeded for verified candidates; one or more unreadable subtrees were skipped and coverage is explicitly bounded.");
    }

    private static void RunDeliveryOptimization(AutoCareOptions options, PreflightResult preflight, string sessionDir, AutoCareReport report)
    {
        if (options.SkipDeliveryOptimization || preflight.IsFeatureSkipped("DELIVERY_OPTIMIZATION")) return;
        try
        {
            var b = DiskSnapshot.CaptureSystemDrive();
            var exec = ExtraSpaceMaintenance.RunDeliveryOptimizationCleanup();
            var a = DiskSnapshot.CaptureSystemDrive();
            var evidence = EvidenceReport.FromMaintenance("delivery-optimization-cache", b, a, exec);
            var path = Path.Combine(sessionDir, "03-delivery-optimization.json");
            ReportIO.WriteEvidence(evidence, path);
            report.DeliveryOptimizationReport = path;
            RecordArtifact(report, "delivery-optimization", path);
            report.VerifiedDeliveryOptimizationGainBytes = Math.Max(0, evidence.VerifiedFreeGainBytes);
            if (evidence.VerificationStatus.StartsWith("VERIFIED_PASS", StringComparison.Ordinal)) MaintenanceCooldownJournal.MarkSuccess("DELIVERY_OPTIMIZATION");
        }
        catch (Exception ex)
        {
            report.FailedWriteStages.Add("DELIVERY_OPTIMIZATION");
            report.Notes.Add("Delivery Optimization cleanup skipped/fail-closed: " + ex.Message);
        }
    }

    private static void RunComponentCleanup(AutoCareOptions options, PreflightResult preflight, string sessionDir, AutoCareReport report)
    {
        if (options.SkipComponentCleanup || preflight.IsFeatureSkipped("COMPONENT_CLEANUP")) return;
        if (WindowsState.HasPendingServicingReboot())
        {
            preflight.FeatureSkips.Add(new FeatureSkip("COMPONENT_CLEANUP", "Runtime recheck detected pending servicing reboot."));
            report.Notes.Add("Component cleanup deferred: pending servicing reboot appeared after preflight.");
            return;
        }
        if (!MaintenanceRuntimeGuards.HeavyStagePowerStillSafe(out var powerDetail))
        {
            preflight.FeatureSkips.Add(new FeatureSkip("COMPONENT_CLEANUP", "Runtime AC-power recheck failed: " + powerDetail));
            report.Notes.Add("Component cleanup deferred because AC power could not be confirmed immediately before execution.");
            return;
        }
        if (!MaintenanceRuntimeGuards.HasMinimumSystemFreeSpace(MaintenanceRuntimeGuards.ComponentCleanupMinimumFreeBytes, out var freeDetail))
        {
            preflight.FeatureSkips.Add(new FeatureSkip("COMPONENT_CLEANUP", "Insufficient verified free-space margin: " + freeDetail));
            report.Notes.Add("Component cleanup deferred because the live free-space safety margin is too small.");
            return;
        }
        try
        {
            var b = DiskSnapshot.CaptureSystemDrive();
            var exec = WindowsMaintenance.RunStartComponentCleanup();
            var a = DiskSnapshot.CaptureSystemDrive();
            var evidence = EvidenceReport.FromMaintenance("windows-component-cleanup", b, a, exec);
            var path = Path.Combine(sessionDir, "04-component-cleanup.json");
            ReportIO.WriteEvidence(evidence, path);
            report.ComponentCleanupReport = path;
            RecordArtifact(report, "component-cleanup", path);
            report.VerifiedComponentCleanupGainBytes = Math.Max(0, evidence.VerifiedFreeGainBytes);
            if (evidence.VerificationStatus.StartsWith("VERIFIED_PASS", StringComparison.Ordinal)) MaintenanceCooldownJournal.MarkSuccess("COMPONENT_CLEANUP");
        }
        catch (Exception ex)
        {
            report.FailedWriteStages.Add("COMPONENT_CLEANUP");
            report.Notes.Add("Component cleanup skipped/fail-closed: " + ex.Message);
        }
    }

    private static void RunPerformanceOptimization(AutoCareOptions options, PreflightResult preflight, AutoCareReport report)
    {
        if (options.SkipPerformance || preflight.IsFeatureSkipped("DRIVE_OPTIMIZATION")) return;
        if (WindowsState.HasPendingServicingReboot())
        {
            preflight.FeatureSkips.Add(new FeatureSkip("DRIVE_OPTIMIZATION", "Runtime recheck detected pending servicing reboot."));
            report.Notes.Add("Drive optimization deferred until the pending servicing reboot is completed.");
            return;
        }
        if (!MaintenanceRuntimeGuards.HeavyStagePowerStillSafe(out var powerDetail))
        {
            preflight.FeatureSkips.Add(new FeatureSkip("DRIVE_OPTIMIZATION", "Runtime AC-power recheck failed: " + powerDetail));
            report.Notes.Add("Drive optimization deferred because AC power could not be confirmed immediately before execution.");
            return;
        }
        try
        {
            report.DriveOptimization = PerformanceMaintenance.OptimizeSystemDrive();
            if (report.DriveOptimization.Succeeded) MaintenanceCooldownJournal.MarkSuccess("DRIVE_OPTIMIZATION");
            if (report.DriveOptimization.Succeeded == false)
                report.Notes.Add("Drive optimization returned a non-zero exit code; no registry/service tweaks were attempted.");
        }
        catch (Exception ex)
        {
            report.FailedWriteStages.Add("DRIVE_OPTIMIZATION");
            report.Notes.Add("Drive optimization skipped/fail-closed: " + ex.Message);
        }
    }

    private static void RunOrSkipDeepAnalysis(AutoCareOptions options, string sessionDir, AutoCareReport report)
    {
        if (options.SkipDeepAnalysis)
        {
            report.DeepAnalysisSkippedByPolicy = true;
            report.DeepAnalysisReport = null;
            report.Notes.Add("Deep analysis deferred by maintenance cadence policy; safe cleanup/health work remains independently evidenced.");
            if (report.NextCriticalFocus == "UNDETERMINED") report.NextCriticalFocus = "DEEP_ANALYSIS_DEFERRED_BY_POLICY";
            return;
        }
        TryDeepAnalysis(options, sessionDir, report);
    }

    private static void TryDeepAnalysis(AutoCareOptions options, string sessionDir, AutoCareReport report)
    {
        try
        {
            var b = DiskSnapshot.CaptureSystemDrive();
            var analysis = OpportunityAnalyzer.Analyze(options.ToCliOptions());
            var a = DiskSnapshot.CaptureSystemDrive();
            var ar = AnalysisReport.Create(b, a, analysis, options.ToCliOptions());
            var path = Path.Combine(sessionDir, "05-deep-analysis.json");
            ReportIO.WriteAnalysis(ar, path);
            report.DeepAnalysisReport = path;
            RecordArtifact(report, "deep-analysis", path);
            report.RemainingEstimatedOpportunityBytes = Math.Max(0, ar.TotalEstimatedOpportunityBytes);
            report.NextCriticalFocus = PriorityPlanner.Choose(report.SystemProfile, ar, report.AdvancedSpaceSnapshot, report.MaintenanceDiagnostics, report.PerformanceSnapshot);
        }
        catch (Exception ex)
        {
            report.Notes.Add("Deep analysis incomplete/fail-closed: " + ex.Message);
            report.NextCriticalFocus = "DEEP_ANALYSIS_RETRY";
        }
    }

    private static string ResolveSessionDir(AutoCareOptions options)
    {
        if (!string.IsNullOrWhiteSpace(options.WorkDir)) return Path.GetFullPath(options.WorkDir);
        var baseDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "DiskGuardSpace", "AutoCare");
        return Path.Combine(baseDir, DateTime.Now.ToString("yyyyMMdd-HHmmss"));
    }

    private static bool ReadOnlyEvidenceVerified(AutoCareReport report)
    {
        if (string.IsNullOrWhiteSpace(report.SafeScanReport) || !EvidenceFileVerified(report.SafeScanReport)) return false;
        if (report.DeepAnalysisSkippedByPolicy) return string.IsNullOrWhiteSpace(report.DeepAnalysisReport);
        if (string.IsNullOrWhiteSpace(report.DeepAnalysisReport) || !AnalysisFileVerified(report.DeepAnalysisReport)) return false;
        return true;
    }

    private static bool AnalysisFileVerified(string path)
    {
        try
        {
            var analysis = JsonSerializer.Deserialize<AnalysisReport>(File.ReadAllText(path), Json.Options);
            if (analysis is null || !analysis.VerificationStatus.StartsWith("VERIFIED_ANALYSIS", StringComparison.Ordinal)) return false;
            return AnalysisVerifier.Verify(analysis).Status == "VERIFIED_PASS";
        }
        catch { return false; }
    }

    private static bool AllExecutedWriteStagesVerified(AutoCareReport report)
    {
        if (report.FailedWriteStages.Count > 0) return false;
        if (string.IsNullOrWhiteSpace(report.SafeCleanupReport) || !EvidenceFileVerified(report.SafeCleanupReport)) return false;
        if (!string.IsNullOrWhiteSpace(report.DeliveryOptimizationReport) && !EvidenceFileVerified(report.DeliveryOptimizationReport)) return false;
        if (!string.IsNullOrWhiteSpace(report.ComponentCleanupReport) && !EvidenceFileVerified(report.ComponentCleanupReport)) return false;
        if (report.DriveOptimization is { Succeeded: false }) return false;
        return true;
    }

    internal static bool VerifyLinkedEvidenceFileForTests(string path) => EvidenceFileVerified(path);

    private static bool EvidenceFileVerified(string path)
    {
        try
        {
            var evidence = JsonSerializer.Deserialize<EvidenceReport>(File.ReadAllText(path), Json.Options);
            if (evidence is null) return false;
            var statusOk = evidence.Mode.Contains("scan", StringComparison.OrdinalIgnoreCase)
                ? evidence.VerificationStatus.StartsWith("VERIFIED_SCAN", StringComparison.Ordinal)
                : evidence.VerificationStatus.StartsWith("VERIFIED_PASS", StringComparison.Ordinal);
            if (!statusOk) return false;
            return EvidenceVerifier.Verify(evidence).Status == "VERIFIED_PASS";
        }
        catch { return false; }
    }

    private static void FinalizeReport(AutoCareReport report, DiskSnapshot before, string masterReportPath)
    {
        var after = DiskSnapshot.CaptureSystemDrive();
        report.FreeBytesAfter = after.FreeBytes;
        report.NetObservedFreeGainBytes = after.FreeBytes - before.FreeBytes;
        Directory.CreateDirectory(Path.GetDirectoryName(masterReportPath) ?? ".");
        AtomicFile.WriteAllText(masterReportPath, JsonSerializer.Serialize(report, Json.Options));
    }

    private static void Print(AutoCareReport r, string path)
    {
        Console.WriteLine();
        Console.WriteLine("=== DiskGuardSpace Auto-Care v1.4 ===");
        Console.WriteLine($"Primary priority       : {r.PrimaryPriority}");
        Console.WriteLine($"Trigger mode           : {r.TriggerMode}");
        Console.WriteLine($"Space pressure         : {r.SpacePressure}");
        Console.WriteLine($"Apply requested        : {r.ApplyRequested}");
        Console.WriteLine($"Safety checks          : {r.SafetyChecks.Count(x => x.Status == "PASS")} PASS / {r.SafetyChecks.Count(x => x.Status != "PASS")} FAIL");
        Console.WriteLine($"Feature skips          : {r.FeatureSkips.Count}");
        Console.WriteLine($"Memory assessment      : {r.PerformanceSnapshot?.Assessment ?? "UNKNOWN"}");
        Console.WriteLine($"Advanced space signals : {r.AdvancedSpaceSnapshot?.Opportunities.Count ?? 0}");
        Console.WriteLine($"Read-only diagnostics  : {r.MaintenanceDiagnostics?.Commands.Count ?? 0}");
        Console.WriteLine($"Safe cleanup gain      : {Format(r.VerifiedSafeCleanupGainBytes)}");
        Console.WriteLine($"Component cleanup gain : {Format(r.VerifiedComponentCleanupGainBytes)}");
        Console.WriteLine($"Delivery Opt gain      : {Format(r.VerifiedDeliveryOptimizationGainBytes)}");
        Console.WriteLine($"Net observed gain      : {FormatSigned(r.NetObservedFreeGainBytes)}");
        Console.WriteLine($"Remaining opportunity  : {Format(r.RemainingEstimatedOpportunityBytes)}");
        Console.WriteLine($"Next critical focus    : {r.NextCriticalFocus}");
        Console.WriteLine($"Status                 : {r.OverallStatus}");
        Console.WriteLine($"Master report          : {path}");
    }

    private static string Format(long b) => b >= 1024L * 1024 * 1024 ? $"{b / (double)(1024L * 1024 * 1024):0.00} GiB" : $"{b / (double)(1024L * 1024):0.00} MiB";
    private static string FormatSigned(long b) => (b < 0 ? "-" : "+") + Format(Math.Abs(b));
}

internal static class PriorityPlanner
{
    public static string Choose(SystemProfile? profile, AnalysisReport r, AdvancedSpaceSnapshot? advanced, MaintenanceDiagnosticsSnapshot? diagnostics, PerformanceSnapshot? performance)
    {
        if (profile is not null && profile.TotalBytes > 0)
        {
            var currentFreePercent = r.FreeBytesAfter * 100.0 / profile.TotalBytes;
            if (currentFreePercent < 5.0) return "EMERGENCY_SPACE_RECOVERY";
            if (currentFreePercent < 10.0 && r.TotalEstimatedOpportunityBytes > 0) return "LOW_SPACE_RECOVERY_HARDENING";
        }

        if (advanced is not null)
        {
            var hiber = advanced.Opportunities.FirstOrDefault(x => x.Name == "HIBERNATION_FILE")?.ObservedBytes ?? 0;
            if (profile is not null && profile.FreePercent < 10 && hiber >= 4L * 1024 * 1024 * 1024)
                return "HIBERNATION_SPACE_REVIEW";
            var winOld = advanced.Opportunities.FirstOrDefault(x => x.Name == "WINDOWS_OLD")?.ObservedBytes ?? 0;
            if (winOld >= 4L * 1024 * 1024 * 1024)
                return "WINDOWS_OLD_SUPPORTED_CLEANUP";

            var virtualDisk = advanced.Opportunities
                .Where(x => x.Policy == "VIRTUAL_DISK_REVIEW_ONLY")
                .OrderByDescending(x => x.ObservedBytes)
                .FirstOrDefault();
            if (virtualDisk is not null && virtualDisk.ObservedBytes >= 8L * 1024 * 1024 * 1024)
                return "VIRTUAL_DISK_NATIVE_CLEANUP_REVIEW";

            var developerCaches = advanced.Opportunities
                .Where(x => x.Policy == "REBUILDABLE_REVIEW")
                .Sum(x => Math.Max(0, x.ObservedBytes));
            if (developerCaches >= 4L * 1024 * 1024 * 1024)
                return "PACKAGE_CACHE_NATIVE_PRUNE_REVIEW";
        }

        if (diagnostics is not null && diagnostics.Commands.Any(x => (x.Name == "DISM_CHECK_HEALTH" || x.Name == "SFC_VERIFY_ONLY" || x.Name == "CHKDSK_SCAN") && !x.Succeeded))
            return "WINDOWS_INTEGRITY_REPAIR_REVIEW";
        if (performance is not null && performance.Assessment is "CRITICAL_MEMORY_PRESSURE" or "HIGH_MEMORY_PRESSURE")
            return "STARTUP_AND_MEMORY_PRESSURE_REVIEW";

        var hotspotBytes = r.DirectoryHotspots.FirstOrDefault()?.TotalBytes ?? 0;
        var candidates = new Dictionary<string, long>(StringComparer.OrdinalIgnoreCase)
        {
            ["DUPLICATE_REVIEW_AUTOMATION"] = r.DuplicatePhysicalPotentialSavingsBytes,
            ["COMPRESSION_ENGINE"] = r.CompressionEstimatedSavingsBytes,
            ["LARGE_FILE_AND_INSTALLER_REVIEW"] = r.ReviewOnlyPotentialBytes,
            // Hotspot size is not claimed as recoverable; a reduced weight merely chooses
            // where the next safe adapter/classifier should investigate.
            ["APPDATA_HOTSPOT_CLASSIFICATION"] = hotspotBytes / 4
        };
        var best = candidates.OrderByDescending(x => x.Value).First();
        if (best.Value > 0) return best.Key;
        if (r.AnalysisTruncated || r.ReadErrors > 0) return "DEEP_ANALYSIS_COVERAGE_HARDENING";
        return "SYSTEM_HEALTH_AND_PERFORMANCE";
    }
}
