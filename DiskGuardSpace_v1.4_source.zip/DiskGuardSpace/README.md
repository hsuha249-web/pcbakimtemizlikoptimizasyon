# DiskGuardSpace v1.4

DiskGuardSpace is a **fail-closed Windows disk-space recovery, maintenance and performance-diagnostics utility**.

Permanent priority order:

1. **Recover disk space**
2. Maintain Windows/storage health
3. Improve performance only with supported, low-risk operations
4. Escalate uncertain or feature-tradeoff opportunities to review instead of forcing them

The program deliberately avoids random registry tweaks, service disabling, RAM-cleaner tricks, arbitrary-path deletion, direct deletion of Windows servicing stores, and destructive user-data cleanup.

## v1.2 space plans and Update Guard

`plan-space --target-gib 50` creates a physical-allocation-aware, hash-bound allowlist manifest. `apply-space-plan` requires the unchanged manifest plus `--yes --confirm SPACE_PLAN_APPLY`; it never promotes large personal files, Desktop/Documents/Downloads content, Codex sessions, virtual disks, archives, installers, databases, or ambiguous findings to automatic deletion.

`update-guard` is disabled by default. `update-guard enable --interval-hours 12 --yes --confirm UPDATE_GUARD_RISK` installs an administrator-only boot and twice-daily Task Scheduler check. It records owned service/policy state, stops the Windows Update services, removes only old files under `SoftwareDistribution\Download`, and restores the owned state with `update-guard disable`. It does not touch WinSxS, Windows Installer, update history, Codex history, or arbitrary user files.

## One-command first run

On the target Windows 10/11 PC, install the **.NET 8 SDK**, extract this folder, then run PowerShell in the folder:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\FIRST_RUN.ps1
```

`FIRST_RUN.ps1` automatically performs:

`source manifest -> build -> positive self-test -> negative/regression tests -> read-only PC proof -> native controller window/button proof -> atomic release -> final controller + release-proof identity -> PC profile -> fail-closed preflight -> safe cache/temp cleanup -> supported Delivery Optimization cleanup -> DISM component cleanup -> media-aware drive optimization -> bounded deep space analysis -> deep read-only health checks -> independent master-report verification`

The first run may request UAC once. The heavy read-only `SFC /verifyonly` and `CHKDSK /scan` checks are intentionally run **after space-recovery work**, so disk-space recovery remains the first priority.



## v1.0 verified background startup maintenance

After the first verified installation, DiskGuardSpace installs the certified release under `%ProgramFiles%\DiskGuardSpace` and registers a hidden Task Scheduler task for the installing Windows user. The task runs at **user logon with a 5-minute delay**, not as SYSTEM, so per-user caches and LocalAppData are analyzed under the correct identity.

Every boot/logon run performs these gates before any write maintenance:

1. installed-file manifest SHA-256/size verification,
2. exact scheduled-task action/trigger/principal verification,
3. release EXE + `RELEASE_PROOF.json` verification,
4. once-per-Windows-boot guard,
5. weekly-or-EXE-change packaged self-test + negative/regression test,
6. `auto-care --apply --startup-background`,
7. independent `verify-auto-care`.

The background task is hidden and uses the canonical `%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe` path. It never resolves `powershell.exe` through `PATH`. The task uses `IgnoreNew`, so duplicate startup instances are not allowed. Existing auto-care mutex protection remains in force.

Heavy maintenance is **not forced on every boot**. Existing AC-power, disk-health, reboot-pending, recovery-mode and cooldown gates still decide whether DISM, Delivery Optimization and drive optimization are safe. This avoids turning automatic maintenance into a boot-time performance penalty. Deep SFC/CHKDSK verification runs only when the EXE changes or the 7-day full-verification interval expires.

Background evidence and run state are stored under `%LOCALAPPDATA%\DiskGuardSpace\Background`. Only the newest 30 bounded session directories are retained. User files are never included in this retention cleanup.

Use `VERIFY_STARTUP_AUTOMATION.ps1` to re-check the installed task and file hashes. Use `UNINSTALL_STARTUP_AUTOMATION.ps1` to disable automatic startup maintenance; reports are preserved by default.

## v0.9 volume-identity + bounded-I/O hardening

v0.9 keeps the permanent priority order **disk space -> health/maintenance -> performance**, and adds:

- Windows volume-GUID binding for cleanup authority and quarantine separation.
- Per-category blast-radius limits in addition to the whole-run budget.
- Free-space proof drift classification so concurrent system activity cannot inflate or hide a reclaim claim.
- A protected state-store durability probe before apply-mode maintenance.
- Read-only recent storage/filesystem error-event gating for heavy/write maintenance.
- Bounded duplicate full hashing (64 GiB / 512 files) so deep analysis cannot monopolize storage I/O indefinitely.

A bounded result is intentionally different from a failure: verified safe work may have completed, but coverage or free-space attribution was limited by concurrent activity, inaccessible items, or an analysis budget. Global safety failures still block write maintenance.

## v0.8 interruption recovery + runtime race hardening

v0.8 keeps disk-space recovery as the permanent first priority, but adds three new safety/efficiency layers:

- **delete-time process recheck:** browser/Electron cache ownership is rechecked immediately before deletion, so an application that starts after preflight cannot have its live cache modified;
- **bounded blast radius:** automatic cleanup is ordered by physical allocated bytes and constrained by a dynamic per-run byte budget plus a finite file-count cap; emergency/critical low-space pressure expands the budget without making it unbounded;
- **interrupted-run recovery:** an atomic run journal records run ID and stage. A killed/power-lost run leaves `IN_PROGRESS`; the next run allows handle-bound safe cache/temp cleanup but defers Delivery Optimization, DISM component cleanup and drive optimization for one recovery run.

Automatic cleanup roots are also bound to the **system volume whose free-space change is being evidenced**. Relocated data on another volume remains available to read-only analysis/review rather than producing misleading C:-drive gain claims. Candidate category and minimum-age policy are rebound to the owning approved root immediately before deletion. Heavy component/drive maintenance rechecks AC power at execution time, pending reboot defers drive optimization, and component cleanup requires a fresh minimum free-space margin.

The master auto-care evidence schema is now `8.0` and records the run ID and interrupted-run recovery state. The independent verifier proves that recovery mode did not execute heavy write stages.

## v0.7 controlled verified EXE release

DiskGuardSpace now follows the same controlled packaged-binary standard used for Game Recorder: a compiled binary is first created in an **unreleased staging directory**. It is not treated as a distributable EXE until the exact staged bytes pass packaged self-test, adversarial/negative tests, a read-only real-PC proof run, independent JSON report verification, a second pending-binary regression pass, and SHA-256 byte-identity checks. Only then is it atomically promoted to `dist\DiskGuardSpace.exe`.

For an EXE-only build/proof run, double-click `BUILD_VERIFIED_EXE.cmd` or run:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\BUILD_VERIFIED_EXE.ps1
```

Successful output is:

- `dist\DiskGuardSpace.exe` — the only controlled releasable binary
- `dist\RELEASE_PROOF.json` — machine-readable release evidence

Re-open the evidence at any time with:

```powershell
.\VERIFY_RELEASE.ps1 -RunSelfTest
```

A failed gate never leaves an unverified new release in place. v0.8 additionally promotes the EXE and release-proof with same-volume replacement semantics when prior artifacts exist; the previous verified EXE/proof are preserved as rollback backups until the independent final verifier passes. If final verification fails, rollback is attempted and hash-checked before the pipeline reports restoration. The low-level `build-win-x64.ps1` remains available for development, but its output is explicitly **UNVERIFIED FOR RELEASE**. `FIRST_RUN.ps1` uses the verified release pipeline before any write maintenance is allowed.

The release proof binds the exact EXE SHA-256, byte size, strict source-manifest SHA-256, target RID/framework, packaged test gates and real-PC proof summary. Authenticode status is recorded, but an unsigned local build is never represented as code-signed.

## v0.6 high-leverage changes

### 1. Physical-allocation-aware space accounting

Logical file length is no longer assumed to equal recoverable disk space. v0.6 measures NTFS allocated bytes (`GetCompressedFileSizeW`) during read-only inventory and rechecks allocation on the **same verified kernel file handle** before automatic deletion.

This prevents sparse/NTFS-compressed files from inflating duplicate, hotspot or cleanup opportunity estimates. Evidence now keeps logical and allocated-byte counters separately.

### 2. Physical duplicate savings and safer compression estimates

Duplicate groups still require full SHA-256 confirmation, but their conservative opportunity score is now based on physical allocation when available. Compression analysis skips files already marked `Compressed`, `SparseFile` or `Encrypted` and caps estimated savings by allocated bytes.

### 3. Adaptive space-pressure tiers

The PC is classified as `EMERGENCY`, `CRITICAL`, `LOW`, `WATCH` or `HEALTHY`. Disk-space recovery remains the permanent primary priority. Critical space can bypass cooldown for reclaim-capable supported cleanup, while drive optimization remains deferred until sufficient headroom exists.

### 4. Heavy-maintenance cooldowns

Repeated runs no longer hammer the same expensive maintenance unnecessarily. Successful Drive Optimization, Component Cleanup and Delivery Optimization maintenance are journaled. Corrupt or future-dated cooldown state cannot authorize work; the affected heavy stage is skipped fail-closed.

### 5. New high-yield review-only space signals

v0.6 measures additional large but potentially workflow-critical storage without deleting it automatically:

- WSL `ext4.vhdx` virtual disks
- Docker Desktop WSL/data virtual disks
- Maven `.m2` repository
- Cargo registry/cache
- Go build cache
- Yarn cache
- pnpm store

Virtual disks are always `VIRTUAL_DISK_REVIEW_ONLY`; direct VHDX deletion/compression is forbidden.

### 6. More read-only maintenance diagnostics

The diagnostics layer additionally permits only the read-only forms of:

- `powercfg /getactivescheme`
- `vssadmin list shadowstorage`
- `defrag <system-drive> /A /V`

Mutating VSS commands and defrag write modes are explicitly rejected by policy tests.

### 7. Additional path/evidence negative controls

Automatic cleanup now rejects NTFS Alternate Data Stream syntax, Win32 device paths and UNC/device-style path forms. `%LOCALAPPDATA%\DiskGuardSpace` is self-protected so evidence, state and cooldown journals cannot become cleanup candidates.

### 8. Canonical executable provenance for maintenance probes

Read-only health/maintenance probes no longer accept PATH-searched executable names. `fsutil`, DISM, CHKDSK, SFC, defrag, VSS and power diagnostics are launched only from canonical Windows `System32` locations. A lookalike sibling such as `System32_evil` is rejected. v0.6 also records a read-only system-volume dirty-bit probe alongside TRIM state.

## v0.5 high-leverage changes

### 1. Handle-bound deletion instead of path re-resolution

v0.5 no longer uses the weaker pattern:

`hash(path) -> File.Delete(path)`

For automatic cleanup on Windows it opens the exact file object with `READ + DELETE` access, denies write/delete sharing, validates metadata and SHA-256 on that same kernel handle, and marks **that same file object** for deletion with `SetFileInformationByHandle`.

This materially reduces path-replacement/TOCTOU risk.

Automatic cleanup also rejects:

- hard-linked files (`linkCount != 1`)
- reparse-point files
- read-only files
- system-attributed files
- files changed since the scan
- files currently written/locked by another process
- noncanonical roots
- files inside the DiskGuardSpace runtime directory

A file-level rejection is normally a safe bounded skip rather than a reason to destroy the rest of the maintenance run.

### 2. Bounded success instead of false all-or-nothing behavior

A cache subtree that cannot be read no longer masquerades as a global containment failure.

- **Containment/policy violation:** global fail-closed block.
- **Unreadable/locked/changed individual item or subtree:** skip it and preserve it.
- Successful work can therefore be reported as `VERIFIED_SCAN_BOUNDED` or `VERIFIED_PASS_BOUNDED`.

The report explicitly records read errors, skipped actions and global safety violations separately.

### 3. More safe rebuildable cache adapters

Automatic cleanup is still restricted to explicit, rebuildable locations. In addition to v0.4 categories, v0.5 can discover cache-only directories for:

- Visual Studio Code
- Cursor
- Discord
- Slack

Only cache directories such as `Cache`, `Code Cache`, `GPUCache` and `DawnCache` are admitted. Application profiles, settings, databases, workspaces, messages and user content are not cleanup roots.

If the owning application is running, that cache category is skipped.

### 4. Advanced space-opportunity probes

The program also measures potentially large locations that are **not automatically deleted**:

- `hiberfil.sys`
- `Windows.old`
- `MEMORY.DMP`
- Recycle Bin
- pip cache
- npm cache
- NuGet global packages
- Gradle caches
- Windows Update download store
- Windows Installer cache

Policies are explicit:

- `REVIEW_ONLY_FEATURE_TRADEOFF`
- `REVIEW_ONLY_DIAGNOSTIC`
- `WINDOWS_SUPPORTED_CLEANUP_ONLY`
- `REVIEW_ONLY_USER_RECOVERY`
- `REBUILDABLE_REVIEW`
- `DO_NOT_TOUCH`

`SoftwareDistribution\Download` and `Windows\Installer` are measured only and remain `DO_NOT_TOUCH`; they never become direct deletion roots.

Directory measurements are bounded to prevent runaway traversal and disclose when measurement coverage was incomplete.

### 5. Multi-technique maintenance diagnostics

Quick read-only diagnostics include:

- `DISM /Online /Cleanup-Image /CheckHealth`
- `DISM /Online /Cleanup-Image /AnalyzeComponentStore`
- `compact.exe /CompactOS:query`
- `powercfg.exe /a`

With `--deep-health`, after disk-space work:

- `sfc.exe /verifyonly`
- `chkdsk.exe <system-drive> /scan`

The read-only diagnostics layer contains an explicit forbidden repair-flag gate. It refuses to run diagnostic commands containing repair flags such as `/RestoreHealth`, `/scannow`, `/f`, `/r`, or `/offlinescanandfix`.

### 6. Performance diagnostics without fake “optimizer” tricks

The master report records:

- memory load percentage
- total/available physical memory
- uptime
- process count
- top memory-consuming processes
- startup entry count
- pending servicing reboot
- system-volume disk health
- TRIM probe
- disk free percentage/filesystem

No process is killed automatically and no startup item, service, power plan or registry value is disabled merely to make benchmark numbers look better.

### 7. Supported Windows write maintenance

When preflight gates pass, automatic maintenance may use:

- verified per-file cache/temp cleanup
- `Delete-DeliveryOptimizationCache -Force` **only if the cmdlet is detected first**
- `DISM /Online /Cleanup-Image /StartComponentCleanup /NoRestart`
- `defrag.exe <system-drive> /O /H /U /V`

`/ResetBase` is forbidden.

Drive optimization is skipped when physical-disk health is warning/unhealthy/ambiguous, AC power is not confirmed, administrator rights are absent, free-space headroom is critically low, or the required Windows binary is unavailable.

## Automatic SAFE cleanup categories

Built-in automatic categories include:

- `%LOCALAPPDATA%\Temp`
- `%LOCALAPPDATA%\CrashDumps`
- `%WINDIR%\Temp`
- DirectX shader cache
- NVIDIA DX/GL/Compute/NV caches under `%LOCALAPPDATA%`
- AMD DX/GL/Vulkan caches under `%LOCALAPPDATA%`
- Chrome / Edge / Brave / Chromium cache roots
- Firefox `cache2` / `startupCache`
- old Windows Error Reporting `ReportArchive` / `ReportQueue` / `Temp`
- VS Code / Cursor / Discord / Slack cache-only roots (including `CachedData`) when their process is closed

The application never accepts `TEMP` or `TMP` environment variables as deletion authority.

## High-yield read-only deep analysis

The bounded deep analyzer scans user-owned data plus `%LOCALAPPDATA%` for:

- large files
- old installers/archives
- exact duplicates using `size -> quick fingerprint -> full SHA-256`
- representative compression opportunities using first/middle/last sampling
- aggregate directory hotspots

Default inventory budget: **300,000 files or 120 seconds**.

Large files, duplicates, installers, archives, compression candidates and directory hotspots remain **REVIEW_ONLY**. Their presence alone never authorizes deletion.

## Adaptive next-focus policy

`PrimaryPriority` is always `DISK_SPACE`.

The planner can choose future focus areas such as:

- `EMERGENCY_SPACE_RECOVERY`
- `LOW_SPACE_RECOVERY_HARDENING`
- `HIBERNATION_SPACE_REVIEW`
- `WINDOWS_OLD_SUPPORTED_CLEANUP`
- `VIRTUAL_DISK_NATIVE_CLEANUP_REVIEW`
- `PACKAGE_CACHE_NATIVE_PRUNE_REVIEW`
- `DUPLICATE_REVIEW_AUTOMATION`
- `COMPRESSION_ENGINE`
- `LARGE_FILE_AND_INSTALLER_REVIEW`
- `APPDATA_HOTSPOT_CLASSIFICATION`
- `DEEP_ANALYSIS_COVERAGE_HARDENING`
- `WINDOWS_INTEGRITY_REPAIR_REVIEW`
- `STARTUP_AND_MEMORY_PRESSURE_REVIEW`
- `SYSTEM_HEALTH_AND_PERFORMANCE`

Disk-space emergencies outrank performance work.

## Important commands

Read-only PC-specific dry run:

```powershell
.\bin\Release\net8.0\win-x64\publish\DiskGuardSpace.exe auto-care
```

Apply default automatic maintenance:

```powershell
.\bin\Release\net8.0\win-x64\publish\DiskGuardSpace.exe auto-care --apply
```

Apply maintenance plus deep read-only health verification:

```powershell
.\bin\Release\net8.0\win-x64\publish\DiskGuardSpace.exe auto-care --apply --deep-health
```

Run negative/regression tests:

```powershell
.\bin\Release\net8.0\win-x64\publish\DiskGuardSpace.exe negative-tests
```

Verify a master report independently:

```powershell
.\bin\Release\net8.0\win-x64\publish\DiskGuardSpace.exe verify-auto-care <auto-care.json>
```

## Acceptance rule

A target Windows PC is considered proven only when:

1. source-manifest verification passes
2. local build ends with `BUILD VERIFIED`
3. positive self-test returns `SELF_TEST: VERIFIED_PASS`
4. negative/regression tests return `NEGATIVE_TESTS: VERIFIED_PASS`
5. read-only proof ends with `PROOF RUN: PASS`
6. every executed write stage has evidence
7. skipped/locked/unreadable work is explicitly bounded rather than hidden
8. linked evidence SHA-256 hashes match the master report
9. independent verification recomputes report consistency
10. an unverifiable or unsafe stage is skipped/fail-closed rather than forced

## Honesty note

This source package is statically audited in the current workspace, but this workspace is not Windows and does not contain the .NET SDK. Therefore **Windows runtime/build success is not fabricated**. The included Windows proof chain is what establishes target-machine runtime proof.

## v1.2: double-click Runtime Controller + native proof

The packaged `DiskGuardSpace.exe` is now directly usable from Explorer. With **no arguments**, it opens the native **DiskGuardSpace Runtime Controller** instead of printing CLI help and exiting.

The controller's `Run Read-Only Verification` button proves the exact packaged EXE by running self-test, negative tests, a real-PC read-only scan, independent report verification, and an `auto-care` dry run. It writes `CONTROLLER_PROOF.json` under a fail-closed canonical LocalAppData proof directory.

This controller verification is intentionally non-destructive: it does not run cleanup/write maintenance. Its isolated test harness may create/delete temporary sandbox files and it writes its own proof artifacts.

The release pipeline also runs `VERIFY_CONTROLLER.ps1`, which uses native Windows UI Automation to prove that the real controller window opens, the real verification button can be invoked, the proof file appears, and the window reaches `STATUS: PASS`. The final promoted EXE is tested again with `RELEASE_PROOF.json` identity required.

After a successful `BUILD_VERIFIED_EXE.cmd`, the only controlled release remains:

```text
dist\DiskGuardSpace.exe
dist\RELEASE_PROOF.json
```

Double-clicking `dist\DiskGuardSpace.exe` opens the controller. For a CSV-Cleaner-style independent GUI proof, double-click `VERIFY_CONTROLLER.cmd`; it launches the final EXE, invokes the real controller button through Windows UI Automation, verifies `CONTROLLER_PROOF.json`, checks the final release-proof identity, and reports `CONTROLLER VERIFY: VERIFIED_PASS` only when all gates pass. CLI commands remain available from PowerShell/Command Prompt.

## v1.2: hata penceresi artık kaybolmaz

v1.1'de `BUILD_VERIFIED_EXE.cmd` hata halinde doğrudan kapanabiliyordu ve controller, miras aldığı CMD/PowerShell konsolunu `SW_HIDE` ile gizleyebiliyordu. v1.2 bu iki davranışı kaldırır.

Önerilen ilk kullanım:

1. `BUILD_VERIFIED_EXE.cmd` dosyasına çift tıklayın. PASS veya FAIL sonucunda pencere kapanmaz; tam kayıt `logs\BUILD_LAST.log` dosyasına yazılır.
2. Build PASS ise `dist\DiskGuardSpace.exe` dosyasına çift tıklayın.
3. Controller başlamadan çökerse `%LOCALAPPDATA%\DiskGuardSpace\Logs\crash-*.json` kalıcı hata kaydı üretilir ve hata iletişim kutusu bu yolu gösterir.
4. Ek teşhis için `RUN_CONTROLLER_DIAGNOSTIC.cmd` kullanın. Bu launcher hata halinde terminali açık tutar.
5. CSV Cleaner benzeri bağımsız UI kanıtı için `VERIFY_CONTROLLER.cmd` kullanın.

`FIRST_RUN.cmd`, PowerShell komutunu elle yazmak istemeyen kullanıcılar için fail-closed, loglu ve kapanmayan ilk-kurulum launcher'ıdır.


## v1.4: controller button activation compatibility

v1.4 fixes a real v1.2 release-gate failure on Windows where the native controller window and button were visible but the accessibility provider returned `Unsupported Pattern` for UI Automation `InvokePattern`. The verifier now discovers the exact control with UI Automation, proves it has a native Win32 `Button` HWND, sends `BM_CLICK` to that exact handle, and then requires an observed controller state transition plus the normal controller proof and PASS title. No coordinate/mouse click is used.

## v1.4 maintenance dashboard and automatic cadence

The native verified controller is now the normal maintenance dashboard. The original `Run Read-Only Verification` release-proof button remains unchanged for the controller automation gate. Additional buttons provide read-only PC analysis, allowlisted safe cleanup, full auto-care, performance-focused care, a 40 GiB fail-closed space-plan workflow, proof/run-folder access, and verified startup-maintenance installation.

Write buttons do not trust the GUI by itself: the running EXE must have an adjacent `RELEASE_PROOF.json` whose v1.4 identity, SHA-256 and byte size match the exact running binary. Write actions then elevate through UAC. The 40 GiB target is not a deletion promise; only hash-bound `SAFE_AUTO` allowlist candidates enter the manifest, and `Apply Space Plan` re-verifies every candidate before acting.

Automatic startup policy after installation:

- every Windows logon/boot: start after 5 minutes, safe allowlisted cleanup + lightweight health/performance diagnostics;
- Delivery Optimization cleanup: at most once per 24 hours;
- deep disk-space analysis: at most once per 3 days;
- media-aware system-drive `/O` optimization: at most once per 7 days;
- DISM `StartComponentCleanup`: at most once per 14 days;
- deep read-only SFC `/verifyonly` + CHKDSK `/scan`: at most once per 14 days;
- packaged self-test + negative/regression tests: every 7 days or whenever the EXE hash changes.

All existing AC-power, reboot-pending, physical-disk health, storage-event, memory-pressure, cooldown, containment, volume-identity and interrupted-run gates remain in force. A cadence becoming due does not override a failed safety gate.
