using System.Security.Cryptography;
using System.Text.Json;

namespace DiskGuardSpace;

internal static class SpacePlanRunner
{
    private const long GiB = 1024L * 1024L * 1024L;

    public static int Plan(CliOptions options)
    {
        Program.EnsureWindowsForInternal();
        var roots = SpacePlanPolicy.GetRoots();
        var before = DiskSnapshot.CaptureSystemDrive();
        var scan = Scanner.ScanApprovedRoots(roots, options.MinAgeDays);
        var entries = scan.Candidates
            .Where(SpacePlanPolicy.IsSafeCandidate)
            .Select(PlanEntry.FromCandidate)
            .ToList();

        var report = new SpacePlanReport
        {
            Mode = "plan-space",
            CreatedUtc = DateTime.UtcNow,
            DriveRoot = before.DriveRoot,
            FreeBytesBefore = before.FreeBytes,
            TargetBytes = options.TargetGiB * GiB,
            Candidates = entries,
            ProtectedRoots = SpacePlanPolicy.ProtectedRoots()
        };
        report.SafeAllocatedBytes = entries.Sum(x => x.AllocatedBytes >= 0 ? x.AllocatedBytes : x.SizeBytes);
        report.SafeLogicalBytes = entries.Sum(x => x.SizeBytes);
        report.Status = report.SafeAllocatedBytes >= report.TargetBytes ? "TARGET_CANDIDATES_FOUND" : "TARGET_NOT_PROVEN";
        var path = ReportIO.WriteSpacePlan(report, options.ReportPath);
        Console.WriteLine($"SPACE PLAN: {report.Status}");
        Console.WriteLine($"Safe candidates: {entries.Count:N0}");
        Console.WriteLine($"Safe allocated: {report.SafeAllocatedBytes / (double)GiB:0.00} GiB");
        Console.WriteLine($"Target: {options.TargetGiB:0.00} GiB");
        Console.WriteLine($"Protected roots: {report.ProtectedRoots.Count}");
        Console.WriteLine($"Manifest: {path}");
        return scan.FailClosedViolations == 0 ? 0 : 31;
    }

    public static int Apply(CliOptions options)
    {
        Program.EnsureWindowsForInternal();
        if (!options.Yes || !string.Equals(options.Confirm, "SPACE_PLAN_APPLY", StringComparison.Ordinal))
            return Fail("FAIL-CLOSED: apply-space-plan requires --yes --confirm SPACE_PLAN_APPLY");
        if (string.IsNullOrWhiteSpace(options.ManifestPath) || !File.Exists(options.ManifestPath))
            return Fail("FAIL-CLOSED: valid --manifest is required.");

        var plan = JsonSerializer.Deserialize<SpacePlanReport>(File.ReadAllText(options.ManifestPath), Json.Options)
                   ?? throw new InvalidDataException("Space plan manifest could not be read.");
        if (!string.Equals(plan.Mode, "plan-space", StringComparison.Ordinal) || plan.Candidates.Count == 0)
            return Fail("FAIL-CLOSED: manifest is not a valid non-empty space plan.");

        var roots = SpacePlanPolicy.GetRoots();
        var current = new List<Candidate>();
        foreach (var entry in plan.Candidates)
        {
            if (!SpacePlanPolicy.IsSafeCandidate(entry) || !SpacePlanPolicy.VerifyEntry(entry, roots))
                return Fail($"FAIL-CLOSED: manifest candidate changed or is outside the allowlist: {entry.Path}");
            current.Add(entry.ToCandidate());
        }

        var scan = new ScanResult();
        scan.Candidates.AddRange(current);
        var before = DiskSnapshot.CaptureSystemDrive();
        Action restoreServices = static () => { };
        if (current.Any(x => x.Category == "WINDOWS_UPDATE_DOWNLOAD") &&
            !UpdateGuardRunner.TryPauseServicesForCleanup(out restoreServices))
        {
            restoreServices();
            return Fail("FAIL-CLOSED: Windows Update adayları için servis durdurma doğrulanamadı.");
        }
        ExecutionResult execution;
        try { execution = Cleaner.ExecuteSafeCandidates(current, roots, options.QuarantinePath); }
        finally { restoreServices(); }
        var after = DiskSnapshot.CaptureSystemDrive();
        var report = EvidenceReport.FromExecution("apply-space-plan", before, after, scan, execution);
        var path = ReportIO.WriteEvidence(report, options.ReportPath);
        Program.PrintSummaryForInternal(report, path);
        return report.VerificationStatus.StartsWith("VERIFIED_PASS", StringComparison.Ordinal) ? 0 : 40;
    }

    private static int Fail(string message) { Console.Error.WriteLine(message); return 2; }
}

internal static class SpacePlanPolicy
{
    public static ApprovedRoot[] GetRoots()
    {
        var roots = SafetyPolicy.GetApprovedCleanupRoots().ToList();
        var windows = Environment.GetFolderPath(Environment.SpecialFolder.Windows);
        var update = Path.Combine(windows, "SoftwareDistribution", "Download");
        if (Directory.Exists(update)) roots.Add(new ApprovedRoot(update, "WINDOWS_UPDATE_DOWNLOAD", 1));
        return roots.ToArray();
    }

    public static bool IsSafeCandidate(PlanEntry entry)
        => entry.Category is "TEMP" or "CRASH_DUMP" or "DIRECTX_SHADER_CACHE" or "NVIDIA_SHADER_CACHE"
            or "AMD_SHADER_CACHE" or "WINDOWS_TEMP" or "WINDOWS_ERROR_REPORT" or "CHROMIUM_CACHE"
            or "ELECTRON_CACHE" or "FIREFOX_CACHE" or "WINDOWS_UPDATE_DOWNLOAD";

    public static bool IsSafeCandidate(Candidate candidate)
        => IsSafeCandidate(new PlanEntry { Path = candidate.Path, Category = candidate.Category, ApprovedRoot = candidate.ApprovedRoot });

    public static bool VerifyEntry(PlanEntry entry, IReadOnlyCollection<ApprovedRoot> roots)
    {
        var root = roots.FirstOrDefault(x => string.Equals(SafetyPolicy.Normalize(x.Path), SafetyPolicy.Normalize(entry.ApprovedRoot), StringComparison.OrdinalIgnoreCase));
        if (root is null || !SafetyPolicy.IsApprovedFile(entry.Path, roots) || !SafetyPolicy.IsUnderRoot(entry.Path, root.Path)) return false;
        if (!File.Exists(entry.Path) || SafetyPolicy.IsReparsePoint(entry.Path)) return false;
        var info = new FileInfo(entry.Path);
        if (info.Length != entry.SizeBytes || info.LastWriteTimeUtc != entry.LastWriteUtc) return false;
        return string.Equals(Hashing.Sha256(entry.Path), entry.Sha256, StringComparison.OrdinalIgnoreCase);
    }

    public static List<string> ProtectedRoots() => new()
    {
        Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), ".codex", "sessions"),
        Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), ".codex", "archived_sessions"),
        Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "replıt", "bugbounty-platform"),
        Environment.GetFolderPath(Environment.SpecialFolder.Desktop),
        Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
        Environment.GetFolderPath(Environment.SpecialFolder.UserProfile) + "\\Downloads"
    };
}

internal sealed class SpacePlanReport
{
    public string Schema { get; set; } = "DiskGuardSpace.SpacePlan.v1";
    public string Mode { get; set; } = "";
    public DateTime CreatedUtc { get; set; }
    public string DriveRoot { get; set; } = "";
    public long FreeBytesBefore { get; set; }
    public long TargetBytes { get; set; }
    public long SafeLogicalBytes { get; set; }
    public long SafeAllocatedBytes { get; set; }
    public string Status { get; set; } = "";
    public List<PlanEntry> Candidates { get; set; } = new();
    public List<string> ProtectedRoots { get; set; } = new();
}

internal sealed class PlanEntry
{
    public string Path { get; set; } = "";
    public string ApprovedRoot { get; set; } = "";
    public string Category { get; set; } = "";
    public string Risk { get; set; } = "SAFE_AUTO";
    public long SizeBytes { get; set; }
    public long AllocatedBytes { get; set; }
    public DateTime LastWriteUtc { get; set; }
    public string Sha256 { get; set; } = "";

    public static PlanEntry FromCandidate(Candidate c) => new()
    {
        Path = c.Path, ApprovedRoot = c.ApprovedRoot, Category = c.Category, SizeBytes = c.SizeBytes,
        AllocatedBytes = c.AllocatedBytes, LastWriteUtc = c.LastWriteUtc, Sha256 = Hashing.Sha256(c.Path)
    };

    public Candidate ToCandidate() => new(Path, SizeBytes, LastWriteUtc, Category, Risk, ApprovedRoot, AllocatedBytes);
}
