# DiskGuardSpace v0.8 Changes

## Primary goal
Disk-space recovery remains the permanent first priority. v0.8 increases recovery efficiency while reducing the blast radius of any single automatic run and hardens the maintenance lifecycle against races and interrupted executions.

## New optimization controls
- Safe cleanup candidates are ordered by **physical allocated bytes**, so the highest verified space-return candidates are attempted first.
- Added a dynamic per-run automatic-cleanup blast-radius budget. The budget expands under EMERGENCY/CRITICAL/LOW free-space pressure but remains bounded.
- Added a finite per-run file-count cap so a bad classification cannot produce an unbounded delete wave.
- The owning approved-root category and minimum-age policy are revalidated immediately before deletion.
- Browser/Electron process state is rechecked at delete time, closing the race where an application starts after preflight/scan.
- Pending servicing reboot now defers drive optimization as well as component servicing.
- AC-power state is rechecked immediately before heavy component cleanup and drive optimization.
- Component cleanup requires a fresh minimum system-drive free-space margin immediately before launch.

## Interrupted-run recovery
- Added an atomic persistent auto-care run journal under `%LOCALAPPDATA%\DiskGuardSpace\State`.
- Every auto-care run receives a unique run ID and stage markers.
- A killed/power-lost run leaves `IN_PROGRESS`; the next run enters one-pass recovery mode.
- Recovery mode still permits handle-bound safe cache/temp cleanup, but defers Delivery Optimization, DISM component cleanup and drive optimization.
- Corrupt, malformed or future-dated run-journal state also triggers recovery mode rather than authorizing heavy writes.
- Master evidence records the run ID and whether recovery mode was active; the independent verifier proves that no heavy stage ran in recovery mode.

## New negative/regression controls
- forged candidate category versus owning approved root
- forged candidate age / delete-time age-policy bypass
- runtime application-start race guard mapping
- finite cleanup file-count blast radius
- dynamic physical-space blast radius remains capped
- interrupted prior run detection
- future-dated run journal
- malformed run identity
- recovery-mode heavy-stage suppression

## Controlled EXE release rollback
- Release proof product version advanced to `0.8`.
- Prior `DiskGuardSpace.exe` and `RELEASE_PROOF.json` are retained as rollback artifacts until the independent final verifier passes.
- Existing EXE/proof promotion uses same-volume replacement semantics when prior artifacts exist.
- Rollback restoration is SHA-256 rechecked; the release pipeline does not claim successful restoration if the restored bytes do not match the backup.
- `VERIFY_RELEASE.ps1 -RunSelfTest` now reruns both the positive self-test and negative/regression suite.

## Evidence status
- Master auto-care schema advanced to `8.0`.
- Negative/regression scenarios in source: 66.
- Static architecture/safety audit is regenerated during packaging.
- Windows build/runtime claims still require the target-PC controlled release pipeline; Linux-side packaging does not claim Windows execution.
