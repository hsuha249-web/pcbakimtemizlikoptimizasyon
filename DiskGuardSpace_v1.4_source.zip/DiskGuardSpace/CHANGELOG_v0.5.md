# DiskGuardSpace v0.5 Changes

## Space recovery

- Added cache-only adapters for VS Code, Cursor, Discord and Slack.
- Added advanced bounded measurement of hiberfil, Windows.old, MEMORY.DMP, Recycle Bin, pip/npm/NuGet/Gradle caches, Windows Update downloads and Windows Installer cache.
- Windows Update and Installer stores remain `DO_NOT_TOUCH` and are never direct deletion roots.
- Added capability preflight for the supported Delivery Optimization cleanup cmdlet.
- Read errors in cache subtrees now create bounded coverage instead of falsely becoming global containment failures.

## Delete safety

- Replaced path-based final source deletion with Windows handle-bound deletion using `CreateFileW` + `SetFileInformationByHandle`.
- The verified handle requests READ+DELETE, denies write/delete sharing and uses `FILE_FLAG_OPEN_REPARSE_POINT`.
- Added hard-link rejection (`NumberOfLinks != 1`).
- Added ReadOnly/System attribute rejection.
- Existing writer/lock conflicts are preserved as local fail-closed skips.
- Added separate `BlockedActions` evidence instead of conflating safe item skips with global policy violations.

## Maintenance and health

- Added DISM CheckHealth and AnalyzeComponentStore diagnostics.
- Added CompactOS query and power capability query.
- Added optional deep read-only health mode: SFC `/verifyonly` + CHKDSK `/scan`.
- Diagnostic layer explicitly rejects repair flags.
- Heavy health checks are sequenced after disk-space recovery.
- System physical-disk health probe now targets the disk backing the system drive rather than all physical disks.

## Performance

- Added physical-memory load/availability snapshot.
- Added top memory-consuming process inventory without process termination.
- Adaptive focus can escalate to Windows integrity review or startup/memory-pressure review after disk-space priorities are satisfied.

## Verification / negative controls

- Added hard-link preservation test.
- Added read-only-file preservation test.
- Added Windows Update direct-cleanup rejection test.
- Added Windows Installer direct-cleanup rejection test.
- Added bounded scan/cleanup evidence states.
- Static source audit expanded to 98 checks.
