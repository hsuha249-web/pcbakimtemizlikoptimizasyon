# DiskGuardSpace v1.4 Safety Contract

DiskGuardSpace is intentionally fail-closed. **Disk-space recovery is priority #1**, but potential space gain never overrides evidence or safety policy.

## v1.2 space-plan and Update Guard boundary

The `plan-space`/`apply-space-plan` pair uses an explicit, hash-bound allowlist. A plan is read-only until the user supplies `--yes --confirm SPACE_PLAN_APPLY`; every candidate is rechecked for containment, volume identity, age, metadata, hash, reparse state, lock/process state, and blast radius immediately before deletion. A 40–50 GiB target is an analysis target, not a promise to delete that amount.

`update-guard` is opt-in and administrator-only. It may run at boot and at most every twelve hours, owns and records the service/policy values it changes, and can restore them on disable. It only considers old files below `SoftwareDistribution\Download`; WinSxS, Windows Installer, update history, system files, Codex sessions, user content, and `bugbounty-platform` source/evidence remain protected. Tamper Protection, enterprise policy, service failures, and ambiguous state fail closed rather than being bypassed.

## 1. Global gates vs local bounded skips

Global failures block all write maintenance when core assumptions are unsafe, including invalid system-drive resolution, unsupported filesystem/drive type, noncanonical cleanup-root policy, containment violations, or explicit unhealthy physical-disk evidence.

Local uncertainty blocks only the affected item/category when isolation is safe. Examples:

- open Chrome -> Chrome cache category skipped
- open VS Code -> VS Code cache category skipped
- one locked temp file -> that file preserved
- one unreadable cache subtree -> subtree skipped and coverage marked bounded
- ambiguous disk-health probe -> heavy drive optimization skipped

This distinction prevents both unsafe forcing and unnecessary all-or-nothing failure.

## 2. Cleanup-root authority

`TEMP` / `TMP` environment variables are **not** deletion authority.

Automatic cleanup roots must be generated from known Windows folders and match a category-specific canonical-location rule.

The application's own runtime directory and `%LOCALAPPDATA%\DiskGuardSpace` evidence/state tree are always protected even when DiskGuardSpace itself was extracted inside a temp/cache tree.

NTFS Alternate Data Stream syntax, Win32 device-path syntax and UNC/device-style paths are rejected from automatic cleanup.

No CLI argument exists that grants arbitrary path-deletion authority.

## 3. Per-file automatic delete gate

Before automatic deletion:

1. candidate still exists
2. candidate risk class is `SAFE`
3. candidate remains under the exact approved root on the evidenced system volume
4. approved-root identity has not changed
5. candidate category still matches the owning approved-root category
6. minimum-age policy is rechecked at delete time
7. owning browser/Electron process state is rechecked at delete time when applicable
8. path is not a reparse point
9. path is not under DiskGuardSpace runtime files
10. file is not ReadOnly/System attributed
11. size and last-write timestamp still match the scan
12. Windows handle is opened with `GENERIC_READ | DELETE`
13. write/delete sharing is denied while verification occurs
14. handle metadata is rechecked
15. hard-link count must equal 1
16. physical allocation is queried from the same verified handle when available
17. SHA-256 is computed from that exact open file object
18. deletion is requested through `SetFileInformationByHandle` on that same handle

This removes the normal path re-resolution between hash verification and deletion.

Sharing/access conflicts before mutation are classified as safe local skips and preserve the file.

## 4. Quarantine gate

Quarantine must be on another volume.

The destination must:

- be ready
- not be a reparse-point root
- have source size plus a reserve of at least 256 MiB or 2%
- receive a fully flushed copy
- match the source SHA-256 before source deletion is marked through the verified source handle

Same-volume quarantine is rejected because it does not recover source-volume capacity.

## 5. Read-only / review-only opportunity protection

The following never become automatic deletion authority merely because they are large:

- Desktop/Documents/Downloads user content
- large files
- exact duplicates
- old installers/archives/ISOs
- compression opportunities
- AppData directory hotspots
- Recycle Bin
- `hiberfil.sys`
- `MEMORY.DMP`
- `Windows.old`
- pip/npm/NuGet/Gradle/Maven/Cargo/Go/Yarn/pnpm caches
- WSL/Docker virtual-disk files (`*.vhdx`)

Special protected measurements:

- `Windows\SoftwareDistribution\Download` -> `DO_NOT_TOUCH`
- `Windows\Installer` -> `DO_NOT_TOUCH`

They may be measured for diagnosis but are never direct cleanup roots.

## 6. Windows maintenance restrictions

Allowed automatic write-maintenance paths are restricted to supported Windows mechanisms:

- `DISM /Online /Cleanup-Image /StartComponentCleanup /NoRestart`
- `Delete-DeliveryOptimizationCache -Force`, only after capability detection
- `defrag.exe <system-drive> /O /H /U /V`

`DISM /ResetBase` is forbidden.

Direct deletion of SoftwareDistribution or Installer data is forbidden.


Maintenance and diagnostic executables are not resolved through `PATH`. DiskGuardSpace requires fully-qualified canonical Windows `System32` executable paths for these probes; bare executable names and lookalike sibling directories are rejected fail-closed. `fsutil dirty query <system-drive>` is diagnostic-only and never clears the dirty bit.

## 7. Read-only health diagnostics restrictions

Allowed diagnostic commands include:

- `DISM ... /CheckHealth`
- `DISM ... /AnalyzeComponentStore`
- `compact.exe /CompactOS:query`
- `powercfg.exe /a`
- `powercfg.exe /getactivescheme`
- `vssadmin.exe list shadowstorage`
- `defrag.exe <system-drive> /A /V`
- optional `sfc.exe /verifyonly`
- optional `chkdsk.exe <system-drive> /scan`

The diagnostic executor contains an explicit denylist for repair flags:

- `/RestoreHealth`
- `/scannow`
- `/f`
- `/r`
- `/offlinescanandfix`
- mutating VSS operations such as `delete shadows` / `resize shadowstorage`
- defrag write modes inside the diagnostics layer

Deep health diagnostics are sequenced after disk-space recovery work.

## 8. Performance restrictions

DiskGuardSpace may observe memory pressure, process working sets, startup-entry count, uptime, physical disk health and TRIM state.

It does **not** automatically:

- kill processes
- disable startup apps
- disable services
- edit performance registry keys
- change power plans
- purge Prefetch
- clear RAM/standby lists

Windows `/O` volume optimization is preferred over guessing SSD/HDD-specific commands.

## 9. Bounded evidence states

`VERIFIED_*_BOUNDED` means operations/measurements that were completed and verified for the covered subset while one or more safely skipped areas were explicitly recorded.

It must never be presented as complete coverage.

Global containment violations remain fail-closed and cannot be downgraded to bounded success.

## 10. Negative/regression-test contract

The Windows proof must demonstrate rejection or safe handling of at least:

- sibling-prefix escape
- `..` traversal
- poisoned `TEMP/TMP`
- runtime-directory cleanup attempts
- noncanonical cleanup roots
- young files
- zero-byte ineffective candidates
- changed-since-scan files
- exclusive locks
- existing writer handles
- read-only files
- hard-linked files
- same-volume quarantine
- quick-fingerprint collisions resolved by full SHA-256
- compressed media excluded from compression estimates
- System32 as cleanup authority
- Windows Update direct-cleanup authority
- Windows Installer direct-cleanup authority
- invalid/non-hex SHA-256 evidence
- tampered free-space arithmetic
- tampered duplicate arithmetic
- atomic-report replacement invariant
- linked `VERIFIED_SCAN` regression
- bounded read-only analysis
- NTFS ADS/device-path cleanup attempts
- tampered physical-allocation evidence
- tampered physical duplicate-savings arithmetic
- future/corrupt heavy-maintenance cooldown state
- direct VHDX cleanup authority
- mutating VSS/defrag commands inside read-only diagnostics

## 11. Evidence contract

Reports are written atomically and linked artifacts are SHA-256 hashed into the master report.

Write-capable stages record before/after free space, candidates, successful actions, blocked/skipped actions, failures and global safety violations.

An unverifiable stage is never silently promoted to `VERIFIED_PASS`.


## 12. Physical-allocation evidence

v0.6 distinguishes logical file length from allocated NTFS bytes. Sparse/compressed files therefore cannot claim their full logical length as verified recoverable space. Automatic cleanup evidence records both logical and handle-bound allocated bytes; deep-analysis opportunity totals prefer physical allocation when available. Allocation-probe fallback is explicitly bounded rather than silently treated as exact.

## 13. Heavy-maintenance repetition policy

Drive optimization is normally cooled down for seven days. Component cleanup is normally cooled down for seven days and Delivery Optimization cleanup for one day. Critical/low space may bypass cooldown only for reclaim-capable maintenance; drive optimization does not receive this bypass. A corrupt or future-dated cooldown journal never grants permission to run a heavy stage.




## v0.9 additional safety contract

1. **Volume identity, not drive-letter trust.** Automatic cleanup must resolve to the same Windows volume GUID as the system volume. Failure to resolve the identity denies authorization. Quarantine requires two resolvable, different volume identities.
2. **Category blast radius.** One cache family cannot consume the entire automatic-cleanup budget; byte and file caps exist at both run and category levels.
3. **Truthful reclaim attribution.** Handle-bound allocated bytes removed are compared with observed free-space change. Large disagreement is reported as concurrent volume activity and forces bounded proof.
4. **Durable state before apply.** The protected state store must pass reparse, fixed-local-NTFS, self-protection, write/read/fsync/delete checks before apply-mode write maintenance is authorized.
5. **Storage-event negative gate.** Targeted recent Disk/Ntfs/storage I/O events are read from the System event log without mutation. One event suppresses heavy maintenance; repeated events globally block write maintenance.
6. **Bounded duplicate I/O.** Full duplicate SHA-256 hashing cannot exceed 64 GiB or 512 files in one deep-analysis run. Exhaustion is disclosed as bounded analysis.
7. **No relaxation of existing protections.** Reparse, ADS/device paths, hard links, live-owner process gates, age/category revalidation, read-only/system attributes, interrupted-run recovery, power/reboot gates, and controlled EXE promotion remain mandatory.

## v0.8 Interrupted-run and blast-radius contract

Auto-care writes an atomic run journal in the self-protected DiskGuardSpace state tree. An unexpected process termination or power loss leaves the run as `IN_PROGRESS`. The next run enters recovery mode: per-file handle-bound safe cleanup remains available, while Delivery Optimization cleanup, DISM component cleanup and drive optimization are deferred for that recovery run. Invalid, malformed or future-dated journal state is treated the same way; it never grants permission for heavy maintenance.

Automatic cleanup is also bounded per run by a finite file-count limit and a dynamic physical-allocation byte budget. Low-space pressure may enlarge the budget, but never removes the cap. Candidates are attempted largest-allocation-first to maximize recovered bytes within the bounded blast radius.

The system-volume binding is part of the evidence contract: automatic cleanup only modifies approved roots on the same volume whose free-space snapshots are used by the evidence report. Other volumes remain read-only analysis/review targets until per-volume evidence is implemented.

Heavy operations do not trust only the initial preflight. AC power and relevant servicing state are rechecked immediately before execution; component cleanup also requires a fresh minimum free-space margin.

## v0.7 Release-artifact safety contract

A developer publish output is not a release artifact. The release pipeline is fail-closed and uses a staging -> pending -> promoted state transition. The exact staged EXE must pass packaged positive and negative tests plus the read-only PC proof. SHA-256 identity must remain unchanged through pending and final promotion. If the independent release verifier fails after promotion, the new EXE and its proof are withdrawn.

`VERIFY_SOURCE.ps1` uses strict coverage: every top-level `.cs`, `.csproj`, `.ps1`, `.py`, and `.md` control/source file must be present in the source manifest. An unmanifested tracked file blocks release. The manifest itself is separately SHA-256-bound into `RELEASE_PROOF.json`.

The controlled release output is only `dist\DiskGuardSpace.exe` paired with `dist\RELEASE_PROOF.json`. The proof does not imply Authenticode signing unless Windows reports a valid signature; unsigned local builds rely on the explicit SHA-256 identity and verification chain.

v0.8 release promotion preserves the previous EXE/proof as rollback artifacts until the final independent verifier succeeds. Existing artifacts are replaced with same-volume file replacement semantics where available. A failed final gate attempts restoration and re-hashes the restored backup; the pipeline does not claim rollback success when that verification fails.


## v1.0 startup-automation safety contract

- Startup automation is installed only after the controlled release EXE and proof verify.
- The verified runtime is copied under `%ProgramFiles%\DiskGuardSpace`; the extracted ZIP/source folder is not a runtime dependency.
- The scheduled task is per-user, hidden, `AtLogOn`, delayed by 5 minutes, `IgnoreNew`, and `Highest` run level. It is intentionally **not** a SYSTEM task.
- The task action uses the canonical Windows PowerShell executable, never a `PATH` lookup.
- Installed EXE/proof/verifier/background scripts are SHA-256 + size bound by `INSTALL_MANIFEST.json`.
- Each background run re-verifies both the installed task identity and the certified release before write maintenance.
- A durable boot identifier prevents more than one maintenance attempt in the same Windows boot. Malformed startup state causes fail-closed skipping rather than duplicate execution.
- Full packaged self-test + negative/regression tests are repeated whenever the EXE changes and at least every 7 days.
- Every startup run performs safe cleanup/preflight, but heavy maintenance remains behind existing cooldown, AC-power, disk-health, reboot-pending, recovery and runtime-pressure gates.
- Background logs are bounded to 30 known-format session directories under DiskGuardSpace's own LocalAppData tree.
- If the installed task or files are tampered, background write maintenance does not run.
- Uninstall refuses to terminate an in-progress maintenance run and preserves user maintenance reports by default.

## v1.2 runtime-controller safety contract

- No-argument EXE launch opens a native Win32 controller; it does not start destructive maintenance automatically.
- Controller verification is read-only with respect to PC cleanup/maintenance. It never calls `clean-safe`, `windows-maintenance`, or `auto-care --apply`.
- Isolated self/negative tests may create and delete their own TEMP sandbox files. Controller evidence files are expected writes and are never counted as reclaimed disk space.
- Controller proof output is accepted only under canonical LocalAppData tree (including its normal Temp subtree).
- Unsafe path syntax, ADS/device paths and reparse-point redirection are fail-closed.
- A final release controller checks adjacent `RELEASE_PROOF.json` against the running EXE SHA-256 and size.
- Release certification requires native Windows UI Automation to observe the controller window, invoke the real verification button and observe `STATUS: PASS`.
- Controller GUI certification failure blocks or rolls back release promotion.

## v1.2 controller-startup evidence contract

A GUI startup failure must never become an unreadable transient console error. The application writes a persistent crash proof under canonical LocalAppData and then displays the failure. Launcher scripts retain their logs and pause before exit.

Controller mode must not hide a console window that may belong to a parent shell. It detaches its own console association instead. This is a usability and evidence-integrity requirement: verification output from a parent CMD/PowerShell must remain observable.


## v1.4 native-controller activation safety

Controller verification must not depend on an optional accessibility pattern. UI Automation is used for process/window/control discovery; activation is allowed only after the discovered control exposes a non-zero native HWND whose Win32 class is exactly `Button`. The verifier may then send `BM_CLICK` to that exact HWND. Synthetic screen-coordinate clicks are forbidden. A send without an observed controller state transition is not accepted as proof.

## v1.4 GUI write authority and startup cadence

The maintenance dashboard is not a new cleanup authority. Before any GUI write action, the running EXE must reopen the adjacent controlled release proof and match product/version, verified result, exact SHA-256 and exact byte size. UAC elevation is then requested for the child write process. Missing, stale, changed or mismatched release evidence blocks the write action.

The automatic startup task remains per-user, hidden, `Highest`, `IgnoreNew`, and once-per-boot guarded. It starts five minutes after logon. Safe allowlisted cleanup may be attempted each boot, but heavy work is cadence-gated: Delivery Optimization 1 day, deep analysis 3 days, drive optimization 7 days, component cleanup 14 days, deep read-only health 14 days, and full packaged self/negative verification 7 days or EXE change. These are maximum frequencies, not guarantees; any safety gate can defer or block a stage.

`--skip-deep-analysis` is a cadence-only optimization. A report may claim a policy-skipped deep analysis only when the analysis path and analysis artifact hash are both absent; the independent verifier checks this explicitly.
