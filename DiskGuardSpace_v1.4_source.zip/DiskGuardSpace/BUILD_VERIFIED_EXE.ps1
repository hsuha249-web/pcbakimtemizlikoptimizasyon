param(
    [switch]$KeepStaging,
    [switch]$SkipDependencyBootstrap
)

$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $Root

function Fail-Closed([string]$Message, [string]$StageDir = "") {
    Write-Host "BUILD VERIFIED EXE: FAIL-CLOSED - $Message" -ForegroundColor Red
    if ($StageDir -and (Test-Path $StageDir)) {
        Write-Host "Unreleased staging evidence retained at: $StageDir" -ForegroundColor Yellow
    }
    exit 2
}

Write-Host "DiskGuardSpace v1.4 - controlled verified EXE + native controller release pipeline" -ForegroundColor Cyan
Write-Host "A binary is NOT promoted to dist\\DiskGuardSpace.exe unless every release gate passes." -ForegroundColor Yellow

function Get-DotNetSdk8 {
    $dotnet = Get-Command dotnet -ErrorAction SilentlyContinue
    $dotnetPath = if ($dotnet) { $dotnet.Source } else { $null }
    if (-not $dotnetPath) {
        foreach ($candidate in @(
            (Join-Path ${env:ProgramFiles} 'dotnet\dotnet.exe'),
            (Join-Path ${env:ProgramFiles(x86)} 'dotnet\dotnet.exe'),
            (Join-Path $env:LOCALAPPDATA 'Microsoft\dotnet\dotnet.exe')
        )) {
            if ($candidate -and (Test-Path $candidate -PathType Leaf)) { $dotnetPath = $candidate; break }
        }
    }
    if (-not $dotnetPath) { return $null }
    $sdkLines = & $dotnetPath --list-sdks 2>$null
    if ($LASTEXITCODE -ne 0 -or -not ($sdkLines -match '^8\.')) { return $null }
    return $dotnetPath
}

function Invoke-PackageInstall([string]$Tool, [string[]]$Arguments) {
    Write-Host "Dependency bootstrap: $Tool $($Arguments -join ' ')" -ForegroundColor Yellow
    try {
        $p = Start-Process -FilePath $Tool -ArgumentList $Arguments -Wait -PassThru -WindowStyle Hidden
        return $p.ExitCode
    } catch {
        Write-Host "Dependency bootstrap failed to start: $($_.Exception.Message)" -ForegroundColor Yellow
        return 1
    }
}

function Install-DotNetUserLocal {
    $installDir = Join-Path $env:LOCALAPPDATA 'Microsoft\dotnet'
    $bootstrap = Join-Path $env:TEMP 'DiskGuardSpace-dotnet-install.ps1'
    try {
        Write-Host "Dependency bootstrap: official Microsoft dotnet-install.ps1 -> $installDir" -ForegroundColor Yellow
        Invoke-WebRequest -UseBasicParsing -Uri 'https://dot.net/v1/dotnet-install.ps1' -OutFile $bootstrap
        & powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File $bootstrap -Channel 8.0 -InstallDir $installDir -NoPath
        return $LASTEXITCODE
    } catch {
        Write-Host "Official .NET SDK bootstrap failed: $($_.Exception.Message)" -ForegroundColor Yellow
        return 1
    } finally {
        Remove-Item $bootstrap -Force -ErrorAction SilentlyContinue
    }
}

function Ensure-DotNetSdk8 {
    if ($SkipDependencyBootstrap) { return Get-DotNetSdk8 }
    $existing = Get-DotNetSdk8
    if ($existing) {
        Write-Host ".NET 8 SDK found: $existing" -ForegroundColor Green
        return $existing
    }

    Write-Host ".NET 8 SDK not found; attempting approved package-manager bootstrap." -ForegroundColor Yellow
    $winget = Get-Command winget.exe -ErrorAction SilentlyContinue
    if ($winget) {
        [void](Invoke-PackageInstall $winget.Source @(
            'install','--id','Microsoft.DotNet.SDK.8','--exact','--silent',
            '--accept-source-agreements','--accept-package-agreements','--disable-interactivity'
        ))
    }
    $existing = Get-DotNetSdk8
    if (-not $existing) {
        $choco = Get-Command choco.exe -ErrorAction SilentlyContinue
        if ($choco) {
            [void](Invoke-PackageInstall $choco.Source @('install','dotnet-8.0-sdk','-y','--no-progress'))
        }
    }
    $existing = Get-DotNetSdk8
    if (-not $existing) { [void](Install-DotNetUserLocal) }
    $existing = Get-DotNetSdk8
    if ($existing) {
        Write-Host ".NET 8 SDK bootstrap verified: $existing" -ForegroundColor Green
    }
    return $existing
}

$DotNet = Ensure-DotNetSdk8
if (-not $DotNet) {
    Fail-Closed ".NET 8 SDK not found and dependency bootstrap failed. Install .NET 8 SDK or rerun as Administrator; no release EXE was created."
}

$dotnetDir = Split-Path -Parent $DotNet
$env:PATH = "$dotnetDir;$env:PATH"

$stamp = Get-Date -Format "yyyyMMdd-HHmmss"
$Artifacts = Join-Path $Root "artifacts"
$Stage = Join-Path $Artifacts "release-staging-$stamp"
$Publish = Join-Path $Stage "publish"
$ProofDir = Join-Path $Stage "pc-proof"
$ControllerProofBase = Join-Path ([Environment]::GetFolderPath([Environment+SpecialFolder]::LocalApplicationData)) "DiskGuardSpace\ControllerReleaseProof"
$ControllerProofDir = Join-Path $ControllerProofBase ("release-$stamp-" + [guid]::NewGuid().ToString('N'))
$ControllerEvidence = Join-Path $Stage "controller-proof"
$Dist = Join-Path $Root "dist"
$Pending = Join-Path $Dist "DiskGuardSpace.pending.exe"
$FinalExe = Join-Path $Dist "DiskGuardSpace.exe"
$FinalProof = Join-Path $Dist "RELEASE_PROOF.json"
$ProofPending = Join-Path $Dist "RELEASE_PROOF.pending.json"
$OldExe = Join-Path $Dist "DiskGuardSpace.previous.exe"
$OldProof = Join-Path $Dist "RELEASE_PROOF.previous.json"
$Promoted = $false
$ProofPromoted = $false
$HadPreviousExe = $false
$HadPreviousProof = $false
New-Item -ItemType Directory -Force -Path $Stage,$Publish,$Dist | Out-Null

function Restore-PreviousRelease {
    $ok = $true
    try {
        if ($HadPreviousExe) {
            if (-not (Test-Path $OldExe -PathType Leaf)) { $ok = $false }
            else {
                Copy-Item $OldExe $FinalExe -Force
                $oldExeHash = (Get-FileHash $OldExe -Algorithm SHA256).Hash
                $restoredExeHash = (Get-FileHash $FinalExe -Algorithm SHA256).Hash
                if ($oldExeHash -ne $restoredExeHash) { $ok = $false }
            }
        } else {
            Remove-Item $FinalExe -Force -ErrorAction SilentlyContinue
        }

        if ($ProofPromoted) {
            if ($HadPreviousProof) {
                if (-not (Test-Path $OldProof -PathType Leaf)) { $ok = $false }
                else {
                    Copy-Item $OldProof $FinalProof -Force
                    $oldProofHash = (Get-FileHash $OldProof -Algorithm SHA256).Hash
                    $restoredProofHash = (Get-FileHash $FinalProof -Algorithm SHA256).Hash
                    if ($oldProofHash -ne $restoredProofHash) { $ok = $false }
                }
            } else {
                Remove-Item $FinalProof -Force -ErrorAction SilentlyContinue
            }
        }
    }
    catch {
        $ok = $false
        Write-Host "ROLLBACK ERROR: $($_.Exception.Message)" -ForegroundColor Red
    }
    return $ok
}

try {
    Write-Host "`n[GATE 1/11] Strict source manifest" -ForegroundColor Cyan
    & .\VERIFY_SOURCE.ps1
    if ($LASTEXITCODE -ne 0) { Fail-Closed "Source manifest verification failed." $Stage }

    $manifestHash = (Get-FileHash (Join-Path $Root "SOURCE_MANIFEST.sha256") -Algorithm SHA256).Hash.ToLowerInvariant()

    Write-Host "`n[GATE 2/11] Static safety architecture audit" -ForegroundColor Cyan
    python .\static-audit.py
    if ($LASTEXITCODE -ne 0) { Fail-Closed "Static safety audit failed." $Stage }

    Write-Host "`n[GATE 3/11] Deterministic isolated win-x64 publish" -ForegroundColor Cyan
    dotnet restore .\DiskGuardSpace.csproj --nologo
    if ($LASTEXITCODE -ne 0) { Fail-Closed "dotnet restore failed." $Stage }

    dotnet publish .\DiskGuardSpace.csproj -c Release -r win-x64 --self-contained true --nologo --no-restore `
        -p:PublishSingleFile=true `
        -p:IncludeNativeLibrariesForSelfExtract=true `
        -p:DebugType=None `
        -p:DebugSymbols=false `
        -p:Deterministic=true `
        -p:ContinuousIntegrationBuild=true `
        -p:PublishReadyToRun=false `
        -o $Publish
    if ($LASTEXITCODE -ne 0) { Fail-Closed "dotnet publish failed." $Stage }

    $StageExe = Join-Path $Publish "DiskGuardSpace.exe"
    if (-not (Test-Path $StageExe -PathType Leaf)) { Fail-Closed "Published EXE is missing." $Stage }

    $unexpected = @(Get-ChildItem $Publish -File | Where-Object { $_.Name -ne "DiskGuardSpace.exe" })
    if ($unexpected.Count -ne 0) {
        $names = ($unexpected.Name -join ", ")
        Fail-Closed "Single-file contract failed; unexpected publish files: $names" $Stage
    }

    $stageItem = Get-Item $StageExe
    if ($stageItem.Length -lt 1MB) { Fail-Closed "Published EXE is implausibly small." $Stage }
    $stageHash = (Get-FileHash $StageExe -Algorithm SHA256).Hash.ToLowerInvariant()

    Write-Host "`n[GATE 4/11] Packaged EXE positive self-test" -ForegroundColor Cyan
    & $StageExe self-test
    if ($LASTEXITCODE -ne 0) { Fail-Closed "Packaged EXE self-test failed." $Stage }

    Write-Host "`n[GATE 5/11] Packaged EXE adversarial/negative tests" -ForegroundColor Cyan
    & $StageExe negative-tests
    if ($LASTEXITCODE -ne 0) { Fail-Closed "Packaged EXE negative tests failed." $Stage }

    Write-Host "`n[GATE 6/11] Read-only real-PC proof and independent report verification" -ForegroundColor Cyan
    & .\prove-on-windows.ps1 -SkipBuild -ExePath $StageExe -ProofDir $ProofDir
    if ($LASTEXITCODE -ne 0) { Fail-Closed "Read-only PC proof failed." $Stage }
    $proofSummary = Join-Path $ProofDir "PROOF_SUMMARY.json"
    if (-not (Test-Path $proofSummary)) { Fail-Closed "PC proof summary missing." $Stage }
    $proofSummaryHash = (Get-FileHash $proofSummary -Algorithm SHA256).Hash.ToLowerInvariant()

    Write-Host "`n[GATE 7/11] Native controller GUI + real button automation proof" -ForegroundColor Cyan
    & .\VERIFY_CONTROLLER.ps1 -ExePath $StageExe -ProofDir $ControllerProofDir
    if ($LASTEXITCODE -ne 0) { Fail-Closed "Native controller GUI verification failed." $Stage }
    $controllerAutomationProof = Join-Path $ControllerProofDir "CONTROLLER_AUTOMATION_PROOF.json"
    if (-not (Test-Path $controllerAutomationProof -PathType Leaf)) { Fail-Closed "Controller automation proof missing." $Stage }
    $controllerAutomationHash = (Get-FileHash $controllerAutomationProof -Algorithm SHA256).Hash.ToLowerInvariant()
    if (Test-Path $ControllerEvidence) { Remove-Item $ControllerEvidence -Recurse -Force }
    Copy-Item $ControllerProofDir $ControllerEvidence -Recurse -Force

    Write-Host "`n[GATE 8/11] Pending-release byte identity" -ForegroundColor Cyan
    if (Test-Path $Pending) { Remove-Item $Pending -Force }
    Copy-Item $StageExe $Pending -Force
    $pendingHash = (Get-FileHash $Pending -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($pendingHash -ne $stageHash) { Fail-Closed "Pending EXE hash differs from tested staging EXE." $Stage }

    Write-Host "`n[GATE 9/11] Pending packaged-EXE regression tests" -ForegroundColor Cyan
    & $Pending self-test
    if ($LASTEXITCODE -ne 0) { Fail-Closed "Pending packaged EXE self-test failed." $Stage }
    & $Pending negative-tests
    if ($LASTEXITCODE -ne 0) { Fail-Closed "Pending packaged EXE negative tests failed." $Stage }

    Write-Host "`n[GATE 10/11] Atomic promotion + release evidence" -ForegroundColor Cyan
    if (Test-Path $OldExe) { Remove-Item $OldExe -Force }
    if (Test-Path $OldProof) { Remove-Item $OldProof -Force }
    if (Test-Path $ProofPending) { Remove-Item $ProofPending -Force }
    $HadPreviousExe = Test-Path $FinalExe -PathType Leaf
    $HadPreviousProof = Test-Path $FinalProof -PathType Leaf
    $Promoted = $true
    if ($HadPreviousExe) {
        [System.IO.File]::Replace($Pending, $FinalExe, $OldExe, $true)
    } else {
        Move-Item $Pending $FinalExe -Force
    }
    $finalHash = (Get-FileHash $FinalExe -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($finalHash -ne $stageHash) {
        $rollbackOk = Restore-PreviousRelease
        $Promoted = $false
        $rollbackText = if ($rollbackOk) { "previous verified release restored when available" } else { "rollback verification FAILED; previous backup retained" }
        Fail-Closed "Promoted EXE hash differs from the tested binary; $rollbackText." $Stage
    }

    $auth = Get-AuthenticodeSignature $FinalExe
    $dotnetInfoPath = Join-Path $Stage "dotnet-info.txt"
    (& dotnet --info | Out-String) | Set-Content -Encoding UTF8 $dotnetInfoPath

    $proof = [ordered]@{
        schema = "DiskGuardSpace.ReleaseProof.v1"
        product = "DiskGuardSpace"
        version = "1.4"
        result = "VERIFIED_PASS"
        createdUtc = (Get-Date).ToUniversalTime().ToString("o")
        targetRid = "win-x64"
        framework = "net8.0"
        selfContained = $true
        singleFile = $true
        releaseExe = "DiskGuardSpace.exe"
        exeSha256 = $finalHash
        exeSizeBytes = (Get-Item $FinalExe).Length
        sourceManifestSha256 = $manifestHash
        pcProofSummarySha256 = $proofSummaryHash
        controllerAutomationProofSha256 = $controllerAutomationHash
        gates = [ordered]@{
            strictSourceManifest = "PASS"
            staticAudit = "PASS"
            isolatedPublish = "PASS"
            packagedSelfTest = "PASS"
            packagedNegativeTests = "PASS"
            readOnlyPcProof = "PASS"
            controllerNativeGui = "PASS"
            pendingByteIdentity = "PASS"
            pendingRegression = "PASS"
            atomicPromotion = "PASS"
        }
        authenticode = [ordered]@{
            status = [string]$auth.Status
            signer = if ($auth.SignerCertificate) { $auth.SignerCertificate.Subject } else { $null }
            note = if ($auth.Status -eq 'Valid') { "Signature verified by Windows." } else { "No claim of code-signing is made; SHA-256 release identity remains mandatory." }
        }
    }
    $proof | ConvertTo-Json -Depth 8 | Set-Content -Encoding UTF8 $ProofPending
    if ($HadPreviousProof) {
        [System.IO.File]::Replace($ProofPending, $FinalProof, $OldProof, $true)
    } else {
        Move-Item $ProofPending $FinalProof -Force
    }
    $ProofPromoted = $true

    Write-Host "`n[GATE 11/11] Independent release + native controller verifier" -ForegroundColor Cyan
    & .\VERIFY_RELEASE.ps1 -ExePath $FinalExe -ProofPath $FinalProof -RunSelfTest
    if ($LASTEXITCODE -ne 0) {
        $rollbackOk = Restore-PreviousRelease
        $Promoted = $false
        $rollbackText = if ($rollbackOk) { "previous verified release restored when available" } else { "rollback verification FAILED; previous backup retained" }
        Fail-Closed "Independent release verification failed; promoted artifact was withdrawn and $rollbackText." $Stage
    }
    $finalControllerDir = Join-Path $ControllerProofBase ("final-$stamp-" + [guid]::NewGuid().ToString('N'))
    & .\VERIFY_CONTROLLER.ps1 -ExePath $FinalExe -ProofDir $finalControllerDir -RequireReleaseProof
    if ($LASTEXITCODE -ne 0) {
        $rollbackOk = Restore-PreviousRelease
        $Promoted = $false
        $rollbackText = if ($rollbackOk) { "previous verified release restored when available" } else { "rollback verification FAILED; previous backup retained" }
        Fail-Closed "Final native controller verification failed; promoted artifact was withdrawn and $rollbackText." $Stage
    }
    $finalControllerEvidence = Join-Path $Stage "final-controller-proof"
    if (Test-Path $finalControllerEvidence) { Remove-Item $finalControllerEvidence -Recurse -Force }
    Copy-Item $finalControllerDir $finalControllerEvidence -Recurse -Force

    $Promoted = $false
    $ProofPromoted = $false
    Remove-Item $ProofPending -Force -ErrorAction SilentlyContinue
    Remove-Item $OldExe -Force -ErrorAction SilentlyContinue
    Remove-Item $OldProof -Force -ErrorAction SilentlyContinue

    Write-Host "`nBUILD VERIFIED EXE: PASS" -ForegroundColor Green
    Write-Host "EXE: $FinalExe" -ForegroundColor Green
    Write-Host "SHA256: $finalHash" -ForegroundColor Green
    Write-Host "PROOF: $FinalProof" -ForegroundColor Green
    Write-Host "Only this dist EXE is the controlled release artifact." -ForegroundColor Yellow

    if (-not $KeepStaging) {
        Remove-Item $Stage -Recurse -Force -ErrorAction SilentlyContinue
        Remove-Item $ControllerProofDir -Recurse -Force -ErrorAction SilentlyContinue
        Remove-Item $finalControllerDir -Recurse -Force -ErrorAction SilentlyContinue
    }
    exit 0
}
catch {
    if (Test-Path $Pending) { Remove-Item $Pending -Force -ErrorAction SilentlyContinue }
    if (Test-Path $ProofPending) { Remove-Item $ProofPending -Force -ErrorAction SilentlyContinue }
    $rollbackText = "no promotion had started"
    if ($Promoted) {
        $rollbackOk = Restore-PreviousRelease
        $Promoted = $false
        $rollbackText = if ($rollbackOk) { "previous verified release restored when available" } else { "rollback verification FAILED; previous backup retained" }
    }
    Write-Host $_.Exception.Message -ForegroundColor Red
    Fail-Closed "Unhandled release-pipeline failure; $rollbackText." $Stage
}
