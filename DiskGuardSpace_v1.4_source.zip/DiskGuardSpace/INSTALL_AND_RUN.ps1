param([switch]$Elevated)
$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $Root

function Test-Administrator {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    $p = New-Object Security.Principal.WindowsPrincipal($id)
    return $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

Write-Host "DiskGuardSpace v1.4 - verified release + fail-closed auto-care + background startup automation" -ForegroundColor Cyan
Write-Host "Priority #1: disk-space recovery; then health/maintenance and performance." -ForegroundColor Yellow
Write-Host "After verification, a hidden per-user startup task is installed with a 5-minute logon delay." -ForegroundColor Yellow

if (-not (Get-Command dotnet -ErrorAction SilentlyContinue)) {
    throw ".NET 8 SDK was not found. FAIL-CLOSED: nothing was changed."
}

if (-not (Test-Administrator)) {
    if ($Elevated) { throw "Elevation was requested but Administrator token is unavailable." }
    Write-Host "Administrator permission is needed for Windows maintenance after the proof gates." -ForegroundColor Yellow
    $canonicalPs = Join-Path $env:SystemRoot "System32\WindowsPowerShell\v1.0\powershell.exe"
    if (-not (Test-Path $canonicalPs -PathType Leaf)) { throw "Canonical Windows PowerShell was not found; refusing PATH-based elevation." }
    $arg = "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`" -Elevated"
    Start-Process -FilePath $canonicalPs -Verb RunAs -ArgumentList $arg
    exit 0
}

Write-Host "`n[1/5] Building and certifying the exact releasable EXE" -ForegroundColor Cyan
& .\BUILD_VERIFIED_EXE.ps1
if ($LASTEXITCODE -ne 0) { throw "Verified EXE release gate failed. Auto-care was not started." }

$Exe = Join-Path $Root "dist\DiskGuardSpace.exe"
$releaseProof = Join-Path $Root "dist\RELEASE_PROOF.json"
Write-Host "`n[2/5] Re-verifying release identity before any write maintenance" -ForegroundColor Cyan
& .\VERIFY_RELEASE.ps1 -ExePath $Exe -ProofPath $releaseProof -RunSelfTest
if ($LASTEXITCODE -ne 0) { throw "Release identity verification failed. Auto-care was not started." }

Write-Host "`n[3/5] Installing and verifying hidden startup maintenance" -ForegroundColor Cyan
& .\INSTALL_STARTUP_AUTOMATION.ps1 -ExePath $Exe -ProofPath $releaseProof -SourceManifestPath (Join-Path $Root "SOURCE_MANIFEST.sha256") -VerifyReleasePath (Join-Path $Root "VERIFY_RELEASE.ps1")
if ($LASTEXITCODE -ne 0) { throw "Verified startup automation install failed. Background maintenance was not enabled." }

$stamp = Get-Date -Format "yyyyMMdd-HHmmss"
$session = Join-Path $Root "AutoCare-$stamp"
New-Item -ItemType Directory -Force -Path $session | Out-Null
$master = Join-Path $session "auto-care.json"

Write-Host "`n[4/5] Applying first fail-closed PC-specific maintenance using VERIFIED release EXE" -ForegroundColor Cyan
& $Exe auto-care --apply --deep-health --report $master --work-dir $session --min-age-days 7 --min-size-mib 500 --duplicate-min-mib 10 --top 150
$autoExit = $LASTEXITCODE
if ($autoExit -ne 0) {
    Write-Host "Auto-care ended PARTIAL/FAIL-CLOSED. Unsafe or unverifiable stages were not forced." -ForegroundColor Yellow
}

Write-Host "`n[5/5] Independent maintenance evidence + release identity + startup-task verification" -ForegroundColor Cyan
& $Exe verify-auto-care $master
$verifyExit = $LASTEXITCODE
& .\VERIFY_RELEASE.ps1 -ExePath $Exe -ProofPath $releaseProof
$releaseExit = $LASTEXITCODE
& .\VERIFY_STARTUP_AUTOMATION.ps1
$startupExit = $LASTEXITCODE

Write-Host "`nRelease EXE SHA-256:" -ForegroundColor Cyan
Get-FileHash $Exe -Algorithm SHA256 | Format-Table -AutoSize
Write-Host "Release proof: $releaseProof"
Write-Host "Master maintenance report: $master"

if ($autoExit -eq 0 -and $verifyExit -eq 0 -and $releaseExit -eq 0 -and $startupExit -eq 0) {
    Write-Host "AUTOMATIC PC CARE + STARTUP AUTOMATION: VERIFIED PASS" -ForegroundColor Green
    exit 0
}
Write-Host "AUTOMATIC PC CARE: PARTIAL OR FAIL-CLOSED" -ForegroundColor Yellow
exit 2
